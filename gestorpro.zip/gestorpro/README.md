# GestorPro

Sistema web para pequenas empresas controlarem produtos, estoque, vendas, clientes e financeiro em um único lugar.

## Stack
- Front-end: React + TypeScript (Vite)
- Back-end: Node.js + TypeScript + Express
- Banco: PostgreSQL
- Autenticação: JWT
- Estilo: Tailwind CSS

## Estrutura
```
gestorpro/
├── frontend/       # React + TypeScript
├── backend/        # Node.js + TypeScript API REST
└── database/
    └── schema.sql  # schema PostgreSQL
```

## Fases implementadas nesta primeira entrega (Fases 1 a 5)
- [x] Estrutura do projeto (frontend + backend + banco)
- [x] Schema PostgreSQL completo (usuarios, produtos, categorias, clientes, vendas, itens_venda, movimentacoes_estoque, contas)
- [x] Backend: servidor Express + TypeScript, conexão com PostgreSQL, middleware de erro
- [x] Autenticação com JWT (login, middleware de proteção de rotas, permissões admin/funcionario)
- [x] CRUD completo de Produtos (API REST)
- [x] CRUD de Clientes (API REST)
- [x] Registro de Vendas com baixa automática de estoque
- [x] Frontend: layout com sidebar, tela de Login, Dashboard, tela de Produtos com CRUD consumindo a API

## Próximas fases (ainda não implementadas)
- Controle de estoque com alertas de estoque mínimo (endpoint já retorna o dado; falta tela dedicada)
- Módulo financeiro completo (entradas/saídas/saldo)
- Relatórios (PDF/Excel)
- Telas de Clientes e Vendas no frontend
- Deploy (Vercel + Render/Railway)

## Como rodar localmente

### 1. Banco de dados
Crie um banco PostgreSQL e rode o schema:
```bash
createdb gestorpro
psql -d gestorpro -f database/schema.sql
```

### 2. Backend
```bash
cd backend
cp .env.example .env   # ajuste as variáveis (DB, JWT_SECRET)
npm install
npm run dev             # http://localhost:3333
```

### 3. Frontend
```bash
cd frontend
npm install
npm run dev              # http://localhost:5173
```

O frontend espera a API em `http://localhost:3333/api` (configurável em `src/services/api.ts`).

### Login inicial
Insira um usuário direto no banco (senha já em hash bcrypt) ou use o endpoint `POST /api/auth/registrar` (liberado só para o primeiro usuário/admin — ver `auth.controller.ts`) para criar o admin inicial.
