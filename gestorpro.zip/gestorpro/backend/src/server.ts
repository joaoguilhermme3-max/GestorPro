import { app } from './app';
import { config } from './config';
import { pool } from './database/pool';

const server = app.listen(config.port, () => {
  console.log(`GestorPro API rodando na porta ${config.port}`);
});

async function encerrar() {
  server.close(() => pool.end().finally(() => process.exit(0)));
}
process.on('SIGINT', encerrar);
process.on('SIGTERM', encerrar);
