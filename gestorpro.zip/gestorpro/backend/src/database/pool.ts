import { Pool, PoolClient, QueryResult, QueryResultRow, types } from 'pg';
import { config } from '../config';

// NUMERIC e BIGINT (COUNT) chegam como número; DATE chega como texto AAAA-MM-DD.
types.setTypeParser(1700, (v) => parseFloat(v));
types.setTypeParser(20, (v) => parseInt(v, 10));
types.setTypeParser(1082, (v) => v);

export const pool = new Pool({
  connectionString: config.databaseUrl,
  ssl: config.databaseSsl ? { rejectUnauthorized: false } : undefined,
  max: 10,
});

export function query<T extends QueryResultRow = any>(
  text: string,
  params?: unknown[],
): Promise<QueryResult<T>> {
  return pool.query<T>(text, params);
}

export async function withTransaction<T>(fn: (client: PoolClient) => Promise<T>): Promise<T> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}

/** Monta "campo = $1, campo2 = $2" só com os campos informados (atualização parcial). */
export function montarUpdate(campos: Record<string, unknown>) {
  const chaves = Object.keys(campos).filter((k) => campos[k] !== undefined);
  return {
    vazio: chaves.length === 0,
    set: chaves.map((k, i) => `${k} = $${i + 1}`).join(', '),
    valores: chaves.map((k) => campos[k]),
  };
}
