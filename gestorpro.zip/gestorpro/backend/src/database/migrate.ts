import fs from 'node:fs';
import path from 'node:path';
import { config } from '../config';
import { pool } from './pool';

async function main() {
  const arquivo = path.resolve(__dirname, '../../../database/schema.sql');
  const sql = fs.readFileSync(arquivo, 'utf8');
  await pool.query(sql);
  console.log('✔ Tabelas criadas/atualizadas com sucesso.');

  // "Hoje", "este mês" e agrupamentos por dia dependem do fuso do banco.
  // Gravar no próprio banco funciona em qualquer hospedagem (inclusive com pooler).
  try {
    const { rows } = await pool.query(
      "SELECT format('ALTER DATABASE %I SET timezone TO %L', current_database(), $1::text) AS cmd",
      [config.timezone],
    );
    await pool.query(rows[0].cmd);
    console.log(`✔ Fuso horário do banco: ${config.timezone}`);
  } catch (err: any) {
    console.warn(`! Não foi possível definir o fuso do banco (${err.message}).`);
    console.warn(`  Rode manualmente: ALTER DATABASE <nome_do_banco> SET timezone TO '${config.timezone}';`);
  }
}

main()
  .catch((err) => {
    console.error('Falha ao criar tabelas:', err.message);
    process.exitCode = 1;
  })
  .finally(() => pool.end());
