/**
 * Uso:
 *   npm run db:seed        → cria só o usuário administrador (seguro para produção)
 *   npm run db:seed:demo   → cria também dados de exemplo (produtos, clientes, 30 dias de vendas)
 */
import bcrypt from 'bcryptjs';
import { PoolClient } from 'pg';
import { pool, withTransaction } from './pool';
import { movimentarEstoque } from '../services/estoque.service';
import { criarVenda, FormaPagamento } from '../services/vendas.service';
import { hojeISO } from '../utils/datas';

const demo = process.argv.includes('--demo');

const ADMIN_EMAIL = (process.env.SEED_ADMIN_EMAIL ?? 'admin@gestorpro.com').toLowerCase();
const ADMIN_SENHA = process.env.SEED_ADMIN_PASSWORD ?? 'admin123';

// Gerador pseudoaleatório com semente: o mesmo demo sempre fica igual.
function mulberry32(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rnd = mulberry32(2026);
const inteiro = (min: number, max: number) => Math.floor(rnd() * (max - min + 1)) + min;
const sortear = <T>(lista: T[]) => lista[inteiro(0, lista.length - 1)];

function cpfValido(base: string): string {
  const dv = (s: string, peso: number) => {
    let soma = 0;
    for (let i = 0; i < s.length; i++) soma += Number(s[i]) * (peso - i);
    const r = (soma * 10) % 11;
    return r === 10 ? 0 : r;
  };
  const d1 = dv(base, 10);
  const d2 = dv(base + d1, 11);
  const c = base + d1 + d2;
  return `${c.slice(0, 3)}.${c.slice(3, 6)}.${c.slice(6, 9)}-${c.slice(9)}`;
}

async function garantirUsuario(nome: string, email: string, senha: string, perfil: string) {
  const { rows } = await pool.query(
    `INSERT INTO usuarios (nome, email, senha_hash, perfil) VALUES ($1,$2,$3,$4)
     ON CONFLICT (email) DO NOTHING RETURNING id`,
    [nome, email, await bcrypt.hash(senha, 10), perfil],
  );
  if (rows[0]) return rows[0].id as number;
  return (await pool.query('SELECT id FROM usuarios WHERE email = $1', [email])).rows[0].id as number;
}

const CATEGORIAS = ['Eletrodomésticos', 'Utilidades domésticas', 'Organização e plásticos', 'Cama, mesa e banho', 'Limpeza'];

// [nome, código, categoria, preço, custo, estoque, mínimo]
const PRODUTOS: [string, string, number, number, number, number, number][] = [
  ['Ventilador Mondial 40cm', 'VEN001', 0, 189.9, 128, 15, 5],
  ['Liquidificador 900W', 'LIQ001', 0, 149.9, 98, 12, 4],
  ['Ferro a Vapor', 'FER001', 0, 119.9, 79, 8, 3],
  ['Cafeteira Elétrica 30 xícaras', 'CAF001', 0, 89.9, 58, 10, 3],
  ['Sanduicheira', 'SAN001', 0, 69.9, 44, 9, 3],
  ['Jogo de Panelas 5 peças', 'PAN001', 1, 229.9, 150, 6, 2],
  ['Conjunto de Facas', 'COZ001', 1, 59.9, 34, 14, 4],
  ['Garrafa Térmica 1L', 'GAR001', 1, 64.9, 38, 18, 5],
  ['Escorredor de Louça', 'ESC001', 1, 49.9, 28, 12, 4],
  ['Tábua de Corte de Bambu', 'TAB001', 1, 34.9, 18, 20, 6],
  ['Caixa Organizadora 30L', 'ORG001', 2, 39.9, 21, 25, 8],
  ['Balde 12L', 'BAL001', 2, 14.9, 7.5, 40, 10],
  ['Bacia Plástica 20L', 'BAC001', 2, 12.9, 6.2, 35, 10],
  ['Kit Potes Herméticos (5 un.)', 'POT001', 2, 44.9, 24, 22, 6],
  ['Cesto de Roupa', 'CES001', 2, 29.9, 15, 18, 5],
  ['Lixeira 15L com Pedal', 'LIX001', 2, 42.9, 23, 16, 5],
  ['Toalha de Banho Felpuda', 'TOA001', 3, 39.9, 22, 30, 10],
  ['Jogo de Lençol Casal', 'LEN001', 3, 89.9, 52, 14, 4],
  ['Cobertor de Microfibra', 'COB001', 3, 119.9, 70, 9, 3],
  ['Travesseiro de Fibra', 'TRA001', 3, 34.9, 18, 20, 6],
  ['Vassoura Multiuso', 'VAS001', 4, 19.9, 9.5, 28, 8],
  ['Rodo 40cm', 'ROD001', 4, 17.9, 8.7, 24, 8],
  ['Mop Giratório', 'MOP001', 4, 99.9, 61, 7, 3],
];

const NOMES_CLIENTES = [
  'Ana Beatriz Lima', 'Carlos Eduardo Rocha', 'Fernanda Alves', 'José Ricardo Nogueira',
  'Luciana Ferreira', 'Marcos Vinícius Costa', 'Patrícia Gomes', 'Rafael Monteiro',
  'Sandra Oliveira', 'Thiago Barbosa', 'Vanessa Pereira', 'Wagner Almeida',
];

function isoDiasAtras(dias: number): string {
  const [a, m, d] = hojeISO().split('-').map(Number);
  const dt = new Date(Date.UTC(a, m - 1, d - dias));
  return dt.toISOString().slice(0, 10);
}

async function carregarDemo(adminId: number, funcId: number) {
  const { rows } = await pool.query('SELECT COUNT(*) AS n FROM produtos');
  if (Number(rows[0].n) > 0) {
    console.log('• Já existem produtos: dados de demonstração não foram recriados.');
    return;
  }

  // Categorias
  const catIds: number[] = [];
  for (const nome of CATEGORIAS) {
    const r = await pool.query('INSERT INTO categorias (nome) VALUES ($1) RETURNING id', [nome]);
    catIds.push(r.rows[0].id);
  }

  // Produtos (estoque inicial registrado no histórico, 31 dias atrás)
  const inicioHistorico = new Date(`${isoDiasAtras(31)}T08:00:00-03:00`);
  const produtoIds: number[] = [];
  await withTransaction(async (c: PoolClient) => {
    for (const [nome, codigo, cat, preco, custo, estoque, minimo] of PRODUTOS) {
      const r = await c.query(
        `INSERT INTO produtos (nome, codigo, preco, custo, estoque, estoque_minimo, categoria_id)
         VALUES ($1,$2,$3,$4,0,$5,$6) RETURNING id`,
        [nome, codigo, preco, custo, minimo, catIds[cat]],
      );
      produtoIds.push(r.rows[0].id);
      await movimentarEstoque(c, {
        produtoId: r.rows[0].id, delta: estoque * 3, tipo: 'entrada',
        motivo: 'Estoque inicial', usuarioId: adminId, data: inicioHistorico,
      });
    }
  });

  // Clientes
  const clienteIds: number[] = [];
  for (let i = 0; i < NOMES_CLIENTES.length; i++) {
    const base = String(100000000 + inteiro(0, 899999999) + i * 7919).slice(0, 9);
    const r = await pool.query(
      `INSERT INTO clientes (nome, cpf, telefone, email) VALUES ($1,$2,$3,$4) RETURNING id`,
      [
        NOMES_CLIENTES[i],
        cpfValido(base),
        `(85) 9${inteiro(1000, 9999)}-${inteiro(1000, 9999)}`,
        `${NOMES_CLIENTES[i].split(' ')[0].toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')}@exemplo.com`,
      ],
    );
    clienteIds.push(r.rows[0].id);
  }

  // 30 dias de vendas, passando pela mesma regra de negócio da API
  const formas: FormaPagamento[] = ['pix', 'pix', 'dinheiro', 'debito', 'credito'];
  let vendas = 0;
  for (let dia = 30; dia >= 0; dia--) {
    const iso = isoDiasAtras(dia);
    const diaSemana = new Date(`${iso}T12:00:00Z`).getUTCDay();
    const quantas = dia === 0 ? inteiro(2, 4) : diaSemana === 0 ? inteiro(0, 2) : diaSemana === 6 ? inteiro(3, 6) : inteiro(2, 5);
    for (let n = 0; n < quantas; n++) {
      const hora = String(inteiro(8, 17)).padStart(2, '0');
      const minuto = String(inteiro(0, 59)).padStart(2, '0');
      let quando = new Date(`${iso}T${hora}:${minuto}:00-03:00`);
      if (quando.getTime() > Date.now()) quando = new Date(Date.now() - inteiro(5, 240) * 60_000);

      const escolhidos = new Set<number>();
      const qtdItens = inteiro(1, 3);
      while (escolhidos.size < qtdItens) escolhidos.add(sortear(produtoIds));
      try {
        await criarVenda({
          clienteId: rnd() < 0.4 ? sortear(clienteIds) : null,
          usuarioId: rnd() < 0.7 ? funcId : adminId,
          formaPagamento: sortear(formas),
          desconto: rnd() < 0.1 ? 5 : 0,
          itens: [...escolhidos].map((produtoId) => ({ produtoId, quantidade: inteiro(1, 3) })),
          dataVenda: quando,
        });
        vendas++;
      } catch {
        /* estoque insuficiente em algum item: ignora esta venda */
      }
    }
  }

  // Deixa alguns produtos abaixo do mínimo para o alerta aparecer no painel
  for (const codigo of ['VEN001', 'CAF001', 'BAL001', 'TOA001']) {
    await withTransaction(async (c) => {
      const p = (await c.query('SELECT id, estoque, estoque_minimo FROM produtos WHERE codigo = $1', [codigo])).rows[0];
      const alvo = Math.max(0, p.estoque_minimo - 1);
      if (p.estoque > alvo) {
        await movimentarEstoque(c, {
          produtoId: p.id, delta: alvo - p.estoque, tipo: 'ajuste',
          motivo: 'Contagem física', usuarioId: adminId,
        });
      }
    });
  }

  // Despesas fixas dos últimos dois meses
  const hoje = hojeISO();
  const mesAtual = hoje.slice(0, 8) + '01';
  const [a, m] = hoje.split('-').map(Number);
  const mesAnterior = new Date(Date.UTC(a, m - 2, 1)).toISOString().slice(0, 10);
  const despesas: [string, string, number, number][] = [
    ['Aluguel', 'Aluguel da loja', 1800, 5],
    ['Salários', 'Folha de pagamento', 2400, 5],
    ['Energia', 'Conta de energia', 380 + inteiro(0, 90), 12],
    ['Água', 'Conta de água', 95, 12],
    ['Compra de mercadoria', 'Reposição de estoque (fornecedor)', 3500, 10],
  ];
  for (const base of [mesAnterior, mesAtual]) {
    for (const [categoria, descricao, valor, diaMes] of despesas) {
      const data = base.slice(0, 8) + String(diaMes).padStart(2, '0');
      if (data > hoje) continue;
      await pool.query(
        `INSERT INTO contas (tipo, categoria, descricao, valor, data, usuario_id) VALUES ('saida',$1,$2,$3,$4,$5)`,
        [categoria, descricao, valor, data, adminId],
      );
    }
  }

  console.log(`✔ Dados de demonstração criados: ${PRODUTOS.length} produtos, ${clienteIds.length} clientes, ${vendas} vendas.`);
}

async function main() {
  const adminId = await garantirUsuario('Administrador', ADMIN_EMAIL, ADMIN_SENHA, 'admin');
  console.log(`✔ Administrador pronto: ${ADMIN_EMAIL}`);
  if (demo) {
    const funcId = await garantirUsuario('Maria Souza', 'funcionario@gestorpro.com', 'func123', 'funcionario');
    console.log('✔ Funcionário de exemplo: funcionario@gestorpro.com');
    await carregarDemo(adminId, funcId);
  }
}

main()
  .catch((err) => {
    console.error('Falha no seed:', err);
    process.exitCode = 1;
  })
  .finally(() => pool.end());
