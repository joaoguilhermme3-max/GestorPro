import 'dotenv/config';

const isProd = process.env.NODE_ENV === 'production';

if (isProd && !process.env.JWT_SECRET) {
  throw new Error('Defina JWT_SECRET no ambiente de produção.');
}

export const config = {
  isProd,
  port: Number(process.env.PORT ?? 3333),
  databaseUrl:
    process.env.DATABASE_URL ?? 'postgres://gestorpro:gestorpro@localhost:5432/gestorpro',
  // Render, Railway, Neon e similares exigem SSL: DATABASE_SSL=true
  databaseSsl: process.env.DATABASE_SSL === 'true',
  jwtSecret: process.env.JWT_SECRET ?? 'segredo-somente-para-desenvolvimento',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN ?? '8h',
  corsOrigins: (process.env.CORS_ORIGIN ?? 'http://localhost:5173')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean),
  // Fuso usado para "hoje", "este mês" e agrupamentos por dia.
  timezone: process.env.TIMEZONE ?? 'America/Sao_Paulo',
};
