import { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { config } from '../config';
import { query } from '../database/pool';
import { HttpError } from '../utils/errors';

export type Perfil = 'admin' | 'funcionario';

export interface UsuarioLogado {
  id: number;
  nome: string;
  email: string;
  perfil: Perfil;
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      usuario?: UsuarioLogado;
    }
  }
}

export function gerarToken(u: UsuarioLogado): string {
  return jwt.sign({ perfil: u.perfil }, config.jwtSecret, {
    subject: String(u.id),
    expiresIn: config.jwtExpiresIn as jwt.SignOptions['expiresIn'],
  });
}

/** Valida o JWT e confere no banco que o usuário continua ativo (perfil sempre atual). */
export async function autenticar(req: Request, _res: Response, next: NextFunction) {
  try {
    const header = req.headers.authorization ?? '';
    const [tipo, token] = header.split(' ');
    if (tipo !== 'Bearer' || !token) throw new HttpError(401, 'Faça login para continuar.');

    let id: number;
    try {
      const payload = jwt.verify(token, config.jwtSecret) as jwt.JwtPayload;
      id = Number(payload.sub);
    } catch {
      throw new HttpError(401, 'Sessão expirada. Entre novamente.');
    }

    const { rows } = await query<UsuarioLogado & { ativo: boolean }>(
      'SELECT id, nome, email, perfil, ativo FROM usuarios WHERE id = $1',
      [id],
    );
    const u = rows[0];
    if (!u || !u.ativo) throw new HttpError(401, 'Usuário inativo ou inexistente.');

    req.usuario = { id: u.id, nome: u.nome, email: u.email, perfil: u.perfil };
    next();
  } catch (err) {
    next(err);
  }
}

export const exigirPerfil =
  (...perfis: Perfil[]) =>
  (req: Request, _res: Response, next: NextFunction) => {
    if (!req.usuario || !perfis.includes(req.usuario.perfil)) {
      return next(new HttpError(403, 'Você não tem permissão para acessar este recurso.'));
    }
    next();
  };
