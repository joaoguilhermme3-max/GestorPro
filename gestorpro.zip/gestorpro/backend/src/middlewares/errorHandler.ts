import { NextFunction, Request, Response } from 'express';
import { HttpError } from '../utils/errors';
import { config } from '../config';

const MENSAGENS_UNICAS: Record<string, string> = {
  produtos_codigo_key: 'Já existe um produto com este código.',
  usuarios_email_key: 'Já existe um usuário com este e-mail.',
  categorias_nome_key: 'Já existe uma categoria com este nome.',
  uq_clientes_cpf: 'Já existe um cliente com este CPF.',
};

export function rotaNaoEncontrada(req: Request, _res: Response, next: NextFunction) {
  next(new HttpError(404, `Rota não encontrada: ${req.method} ${req.originalUrl}`));
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function tratarErros(err: any, _req: Request, res: Response, _next: NextFunction) {
  if (err instanceof HttpError) {
    return res.status(err.status).json({ erro: err.message, detalhes: err.detalhes });
  }
  if (err?.type === 'entity.parse.failed') {
    return res.status(400).json({ erro: 'JSON inválido no corpo da requisição.' });
  }
  // Erros do PostgreSQL
  if (err?.code === '23505') {
    return res.status(409).json({ erro: MENSAGENS_UNICAS[err.constraint] ?? 'Registro duplicado.' });
  }
  if (err?.code === '23503') {
    return res
      .status(409)
      .json({ erro: 'Este registro está vinculado a outros dados e não pode ser removido.' });
  }
  if (err?.code === '23514') {
    return res.status(400).json({ erro: 'Um dos valores informados não é permitido.' });
  }
  console.error(err);
  res.status(500).json({
    erro: 'Erro interno do servidor.',
    ...(config.isProd ? {} : { detalhe: String(err?.message ?? err) }),
  });
}
