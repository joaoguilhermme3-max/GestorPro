import { PoolClient } from 'pg';
import { HttpError } from '../utils/errors';

export type TipoMovimentacao = 'entrada' | 'venda' | 'ajuste' | 'cancelamento';

interface Movimento {
  produtoId: number;
  /** positivo = entra no estoque, negativo = sai */
  delta: number;
  tipo: TipoMovimentacao;
  motivo?: string | null;
  vendaId?: number | null;
  usuarioId?: number | null;
  data?: Date;
}

/**
 * Único ponto do sistema que altera o estoque. Trava a linha do produto,
 * impede saldo negativo e grava o histórico na mesma transação.
 */
export async function movimentarEstoque(client: PoolClient, m: Movimento): Promise<number> {
  const { rows } = await client.query(
    'SELECT nome, estoque FROM produtos WHERE id = $1 FOR UPDATE',
    [m.produtoId],
  );
  const produto = rows[0];
  if (!produto) throw new HttpError(404, 'Produto não encontrado.');

  const novoSaldo = produto.estoque + m.delta;
  if (novoSaldo < 0) {
    throw new HttpError(
      409,
      `Estoque insuficiente para "${produto.nome}" (disponível: ${produto.estoque}).`,
    );
  }

  await client.query('UPDATE produtos SET estoque = $1, atualizado_em = NOW() WHERE id = $2', [
    novoSaldo,
    m.produtoId,
  ]);
  await client.query(
    `INSERT INTO movimentacoes_estoque
       (produto_id, tipo, quantidade, saldo_apos, motivo, venda_id, usuario_id, criado_em)
     VALUES ($1,$2,$3,$4,$5,$6,$7,COALESCE($8, NOW()))`,
    [
      m.produtoId,
      m.tipo,
      m.delta,
      novoSaldo,
      m.motivo ?? null,
      m.vendaId ?? null,
      m.usuarioId ?? null,
      m.data ?? null,
    ],
  );
  return novoSaldo;
}
