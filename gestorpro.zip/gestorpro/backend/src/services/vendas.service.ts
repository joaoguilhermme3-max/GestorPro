import { PoolClient } from 'pg';
import { query, withTransaction } from '../database/pool';
import { HttpError } from '../utils/errors';
import { movimentarEstoque } from './estoque.service';

export type FormaPagamento = 'dinheiro' | 'pix' | 'debito' | 'credito';

export interface NovaVenda {
  clienteId?: number | null;
  usuarioId: number;
  formaPagamento: FormaPagamento;
  desconto: number;
  itens: { produtoId: number; quantidade: number }[];
  /** Somente uso interno (carga de dados de demonstração). */
  dataVenda?: Date;
}

const arredondar = (v: number) => Math.round(v * 100) / 100;

/**
 * Registra a venda inteira numa única transação:
 * venda + itens → baixa de estoque → histórico → entrada no financeiro.
 * Se qualquer passo falhar (ex.: estoque insuficiente), nada é gravado.
 * Os preços vêm SEMPRE do banco, nunca do navegador.
 */
export async function criarVenda(v: NovaVenda): Promise<number> {
  // Junta linhas repetidas do mesmo produto
  const qtdPorProduto = new Map<number, number>();
  for (const i of v.itens) {
    qtdPorProduto.set(i.produtoId, (qtdPorProduto.get(i.produtoId) ?? 0) + i.quantidade);
  }
  // Ordem fixa de travamento evita deadlock entre vendas simultâneas
  const ids = [...qtdPorProduto.keys()].sort((a, b) => a - b);

  return withTransaction(async (client) => {
    if (v.clienteId) {
      const c = await client.query('SELECT 1 FROM clientes WHERE id = $1 AND ativo', [v.clienteId]);
      if (!c.rowCount) throw new HttpError(400, 'Cliente não encontrado.');
    }

    const { rows: produtos } = await client.query(
      `SELECT id, nome, preco, custo, ativo FROM produtos WHERE id = ANY($1::int[]) ORDER BY id FOR UPDATE`,
      [ids],
    );
    if (produtos.length !== ids.length) throw new HttpError(400, 'Algum produto da venda não existe.');
    const inativo = produtos.find((p) => !p.ativo);
    if (inativo) throw new HttpError(400, `O produto "${inativo.nome}" está desativado.`);

    const linhas = produtos.map((p) => {
      const quantidade = qtdPorProduto.get(p.id)!;
      return { ...p, quantidade, subtotal: arredondar(p.preco * quantidade) };
    });
    const subtotal = arredondar(linhas.reduce((s, l) => s + l.subtotal, 0));
    if (v.desconto > subtotal) throw new HttpError(400, 'O desconto não pode ser maior que o subtotal.');
    const total = arredondar(subtotal - v.desconto);

    const venda = await client.query(
      `INSERT INTO vendas (cliente_id, usuario_id, subtotal, desconto, valor_total, forma_pagamento, data_venda)
       VALUES ($1,$2,$3,$4,$5,$6,COALESCE($7, NOW())) RETURNING id`,
      [v.clienteId ?? null, v.usuarioId, subtotal, v.desconto, total, v.formaPagamento, v.dataVenda ?? null],
    );
    const vendaId: number = venda.rows[0].id;

    for (const l of linhas) {
      await client.query(
        `INSERT INTO itens_venda (venda_id, produto_id, quantidade, preco_unitario, custo_unitario, subtotal)
         VALUES ($1,$2,$3,$4,$5,$6)`,
        [vendaId, l.id, l.quantidade, l.preco, l.custo, l.subtotal],
      );
      await movimentarEstoque(client, {
        produtoId: l.id,
        delta: -l.quantidade,
        tipo: 'venda',
        motivo: `Venda #${vendaId}`,
        vendaId,
        usuarioId: v.usuarioId,
        data: v.dataVenda,
      });
    }

    if (total > 0) {
      await client.query(
        `INSERT INTO contas (tipo, categoria, descricao, valor, data, venda_id, usuario_id)
         SELECT 'entrada', 'Venda', 'Venda #' || id, valor_total, data_venda::date, id, usuario_id
           FROM vendas WHERE id = $1`,
        [vendaId],
      );
    }
    return vendaId;
  });
}

export async function cancelarVenda(vendaId: number, usuarioId: number): Promise<void> {
  await withTransaction(async (client: PoolClient) => {
    const { rows } = await client.query(
      'SELECT id, status, valor_total FROM vendas WHERE id = $1 FOR UPDATE',
      [vendaId],
    );
    const venda = rows[0];
    if (!venda) throw new HttpError(404, 'Venda não encontrada.');
    if (venda.status === 'cancelada') throw new HttpError(409, 'Esta venda já foi cancelada.');

    const { rows: itens } = await client.query(
      'SELECT produto_id, quantidade FROM itens_venda WHERE venda_id = $1 ORDER BY produto_id',
      [vendaId],
    );
    for (const i of itens) {
      await movimentarEstoque(client, {
        produtoId: i.produto_id,
        delta: i.quantidade,
        tipo: 'cancelamento',
        motivo: `Cancelamento da venda #${vendaId}`,
        vendaId,
        usuarioId,
      });
    }
    await client.query("UPDATE vendas SET status = 'cancelada' WHERE id = $1", [vendaId]);

    if (venda.valor_total > 0) {
      // Estorno: mantém o histórico do dinheiro que entrou e depois saiu.
      await client.query(
        `INSERT INTO contas (tipo, categoria, descricao, valor, data, venda_id, usuario_id)
         VALUES ('saida','Estorno',$1,$2,CURRENT_DATE,$3,$4)`,
        [`Cancelamento da venda #${vendaId}`, venda.valor_total, vendaId, usuarioId],
      );
    }
  });
}

export async function obterVenda(id: number) {
  const { rows } = await query(
    `SELECT v.id, v.cliente_id, c.nome AS cliente, v.usuario_id, u.nome AS vendedor,
            v.subtotal, v.desconto, v.valor_total, v.forma_pagamento, v.status, v.data_venda
       FROM vendas v
       LEFT JOIN clientes c ON c.id = v.cliente_id
       JOIN usuarios u ON u.id = v.usuario_id
      WHERE v.id = $1`,
    [id],
  );
  if (!rows[0]) return null;
  const itens = await query(
    `SELECT i.id, i.produto_id, p.nome AS produto, p.codigo, i.quantidade, i.preco_unitario, i.subtotal
       FROM itens_venda i JOIN produtos p ON p.id = i.produto_id
      WHERE i.venda_id = $1 ORDER BY i.id`,
    [id],
  );
  return { ...rows[0], itens: itens.rows };
}
