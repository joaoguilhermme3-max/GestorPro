import { z } from 'zod';
import { HttpError } from './errors';

z.config(z.locales.pt());

export function validar<T extends z.ZodType>(schema: T, dados: unknown): z.output<T> {
  const r = schema.safeParse(dados);
  if (!r.success) {
    const detalhes = r.error.issues.map((i) => ({
      campo: i.path.join('.'),
      mensagem: i.message,
    }));
    const primeira = detalhes[0];
    const msg = primeira?.campo ? `${primeira.campo}: ${primeira.mensagem}` : 'Dados inválidos';
    throw new HttpError(400, msg, detalhes);
  }
  return r.data;
}

export const emailSchema = z
  .string()
  .trim()
  .toLowerCase()
  .pipe(z.email('E-mail inválido'));

export const dinheiro = z
  .number()
  .min(0, 'Não pode ser negativo')
  .max(99999999.99, 'Valor muito alto')
  .transform((v) => Math.round(v * 100) / 100);

export const inteiroNaoNegativo = z.number().int('Use um número inteiro').min(0).max(1_000_000);

/** Texto opcional: "" vira null; undefined continua undefined (não altera no PUT). */
export const textoOpcional = (max: number) =>
  z
    .string()
    .trim()
    .max(max)
    .nullish()
    .transform((v) => (v === undefined ? undefined : v === null || v === '' ? null : v));

export const dataISO = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Use o formato AAAA-MM-DD');

export const paginacaoSchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20),
});

export function paginar(query: unknown) {
  const { page, limit } = validar(paginacaoSchema, query);
  return { page, limit, offset: (page - 1) * limit };
}

/** Escapa % e _ para uso em ILIKE. */
export const escapeLike = (s: string) => s.replace(/[\\%_]/g, (c) => `\\${c}`);

export const boolQuery = z
  .enum(['true', 'false'])
  .optional()
  .transform((v) => (v === undefined ? undefined : v === 'true'));
