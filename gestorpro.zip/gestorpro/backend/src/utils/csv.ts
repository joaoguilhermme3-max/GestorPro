export interface Coluna {
  chave: string;
  rotulo: string;
  tipo: 'texto' | 'moeda' | 'inteiro';
  somar?: boolean;
}

const escapar = (s: string) => (/[";\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s);

function formatar(coluna: Coluna, valor: unknown): string {
  if (valor === null || valor === undefined) return '';
  if (coluna.tipo === 'moeda') return Number(valor).toFixed(2).replace('.', ',');
  return String(valor);
}

/** CSV para Excel em português: separador ";", vírgula decimal e BOM UTF-8. */
export function paraCsv(colunas: Coluna[], linhas: Record<string, unknown>[]): string {
  const cabecalho = colunas.map((c) => escapar(c.rotulo)).join(';');
  const corpo = linhas.map((l) => colunas.map((c) => escapar(formatar(c, l[c.chave]))).join(';'));
  return '\uFEFF' + [cabecalho, ...corpo].join('\r\n');
}
