import { config } from '../config';

const fmt = new Intl.DateTimeFormat('en-CA', {
  timeZone: config.timezone,
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
});

/** Data de hoje (AAAA-MM-DD) no fuso do negócio. */
export const hojeISO = () => fmt.format(new Date());
export const inicioDoMesISO = () => hojeISO().slice(0, 8) + '01';

export function periodoPadrao(inicio?: string, fim?: string) {
  return { inicio: inicio ?? inicioDoMesISO(), fim: fim ?? hojeISO() };
}
