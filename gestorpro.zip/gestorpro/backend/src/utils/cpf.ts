/** Valida CPF pelos dígitos verificadores e devolve formatado (000.000.000-00) ou null. */
export function normalizarCpf(valor: string): string | null {
  const d = valor.replace(/\D/g, '');
  if (d.length !== 11 || /^(\d)\1{10}$/.test(d)) return null;
  const digito = (base: string, pesoInicial: number) => {
    let soma = 0;
    for (let i = 0; i < base.length; i++) soma += Number(base[i]) * (pesoInicial - i);
    const resto = (soma * 10) % 11;
    return resto === 10 ? 0 : resto;
  };
  if (digito(d.slice(0, 9), 10) !== Number(d[9])) return null;
  if (digito(d.slice(0, 10), 11) !== Number(d[10])) return null;
  return `${d.slice(0, 3)}.${d.slice(3, 6)}.${d.slice(6, 9)}-${d.slice(9)}`;
}
