import cors from 'cors';
import express from 'express';
import helmet from 'helmet';
import { config } from './config';
import { rotaNaoEncontrada, tratarErros } from './middlewares/errorHandler';
import routes from './routes';

export const app = express();

// Atrás de proxy (Render/Railway) o IP real vem de X-Forwarded-For — necessário p/ o rate limit.
app.set('trust proxy', 1);

app.use(helmet());
app.use(
  cors({
    origin: (origin, cb) => {
      // sem Origin = curl/Postman/health checks
      if (!origin || config.corsOrigins.includes(origin)) return cb(null, true);
      cb(new Error('Origem não permitida pelo CORS'));
    },
  }),
);
app.use(express.json({ limit: '200kb' }));

app.get('/', (_req, res) => res.json({ nome: 'GestorPro API', status: 'ok' }));
app.use('/api', routes);

app.use(rotaNaoEncontrada);
app.use(tratarErros);
