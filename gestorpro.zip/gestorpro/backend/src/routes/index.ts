import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { autenticar, exigirPerfil } from '../middlewares/auth';
import { asyncHandler as h } from '../utils/errors';
import * as auth from '../controllers/auth.controller';
import * as categorias from '../controllers/categorias.controller';
import * as clientes from '../controllers/clientes.controller';
import { dashboard } from '../controllers/dashboard.controller';
import * as estoque from '../controllers/estoque.controller';
import * as financeiro from '../controllers/financeiro.controller';
import * as produtos from '../controllers/produtos.controller';
import * as relatorios from '../controllers/relatorios.controller';
import * as usuarios from '../controllers/usuarios.controller';
import * as vendas from '../controllers/vendas.controller';

const admin = exigirPerfil('admin');
const router = Router();

router.get('/health', (_req, res) => res.json({ status: 'ok' }));

// ---------- Público ----------
const limitarLogin = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  message: { erro: 'Muitas tentativas de login. Aguarde alguns minutos.' },
});
router.post('/login', limitarLogin, h(auth.login));

// ---------- Tudo abaixo exige login (JWT) ----------
router.use(autenticar);
router.get('/me', h(auth.me));
router.put('/me/senha', h(auth.alterarSenha));
router.get('/dashboard', h(dashboard));

// Produtos: funcionário cadastra e edita; só o administrador desativa.
router.get('/produtos', h(produtos.listar));
router.post('/produtos', h(produtos.criar));
router.get('/produtos/:id', h(produtos.obter));
router.put('/produtos/:id', h(produtos.atualizar));
router.delete('/produtos/:id', admin, h(produtos.remover));

router.get('/categorias', h(categorias.listar));
router.post('/categorias', h(categorias.criar));
router.put('/categorias/:id', h(categorias.atualizar));
router.delete('/categorias/:id', admin, h(categorias.remover));

router.get('/clientes', h(clientes.listar));
router.post('/clientes', h(clientes.criar));
router.get('/clientes/:id', h(clientes.obter));
router.put('/clientes/:id', h(clientes.atualizar));
router.delete('/clientes/:id', admin, h(clientes.remover));

router.get('/vendas', h(vendas.listar));
router.post('/vendas', h(vendas.criar));
router.get('/vendas/:id', h(vendas.obter));
router.post('/vendas/:id/cancelar', admin, h(vendas.cancelar));

// ---------- Somente administrador ----------
router.get('/estoque/movimentacoes', admin, h(estoque.listarMovimentacoes));
router.post('/estoque/movimentacoes', admin, h(estoque.registrarMovimentacao));
router.get('/estoque/alertas', admin, h(estoque.alertas));
router.get('/estoque/resumo', admin, h(estoque.resumo));

router.get('/financeiro/categorias', admin, financeiro.categorias);
router.get('/financeiro/resumo', admin, h(financeiro.resumo));
router.get('/financeiro/contas', admin, h(financeiro.listar));
router.post('/financeiro/contas', admin, h(financeiro.criar));
router.put('/financeiro/contas/:id', admin, h(financeiro.atualizar));
router.delete('/financeiro/contas/:id', admin, h(financeiro.remover));

router.get('/relatorios', admin, relatorios.indice);
router.get('/relatorios/:tipo', admin, h(relatorios.gerar));

router.get('/usuarios', admin, h(usuarios.listar));
router.post('/usuarios', admin, h(usuarios.criar));
router.put('/usuarios/:id', admin, h(usuarios.atualizar));

export default router;
