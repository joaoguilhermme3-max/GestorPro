import { Request, Response } from 'express';
import { z } from 'zod';
import { query } from '../database/pool';
import { Coluna, paraCsv } from '../utils/csv';
import { periodoPadrao } from '../utils/datas';
import { HttpError } from '../utils/errors';
import { dataISO, validar } from '../utils/validate';

interface Relatorio {
  titulo: string;
  periodo?: { inicio: string; fim: string };
  colunas: Coluna[];
  linhas: Record<string, unknown>[];
}

const FORMAS: Record<string, string> = {
  dinheiro: 'Dinheiro',
  pix: 'PIX',
  debito: 'Cartão de débito',
  credito: 'Cartão de crédito',
};

const filtroSchema = z.object({
  inicio: dataISO.optional(),
  fim: dataISO.optional(),
  formato: z.enum(['json', 'csv']).default('json'),
});

type Gerador = (p: { inicio: string; fim: string }) => Promise<Relatorio>;

// Filtro por data usado nas consultas: [inicio, fim] inclusive, no fuso do negócio.
const VENDA_NO_PERIODO = `v.status = 'concluida' AND v.data_venda >= $1::date AND v.data_venda < ($2::date + 1)`;

const geradores: Record<string, Gerador> = {
  vendas: async ({ inicio, fim }) => {
    const { rows } = await query(
      `SELECT v.id AS numero, to_char(v.data_venda, 'DD/MM/YYYY HH24:MI') AS data,
              COALESCE(c.nome, 'Consumidor') AS cliente, u.nome AS vendedor,
              v.forma_pagamento, v.subtotal, v.desconto, v.valor_total
         FROM vendas v LEFT JOIN clientes c ON c.id = v.cliente_id JOIN usuarios u ON u.id = v.usuario_id
        WHERE ${VENDA_NO_PERIODO} ORDER BY v.data_venda DESC, v.id DESC`,
      [inicio, fim],
    );
    return {
      titulo: 'Relatório de vendas',
      periodo: { inicio, fim },
      colunas: [
        { chave: 'numero', rotulo: 'Nº', tipo: 'inteiro' },
        { chave: 'data', rotulo: 'Data', tipo: 'texto' },
        { chave: 'cliente', rotulo: 'Cliente', tipo: 'texto' },
        { chave: 'vendedor', rotulo: 'Vendedor', tipo: 'texto' },
        { chave: 'forma_pagamento', rotulo: 'Pagamento', tipo: 'texto' },
        { chave: 'subtotal', rotulo: 'Subtotal', tipo: 'moeda', somar: true },
        { chave: 'desconto', rotulo: 'Desconto', tipo: 'moeda', somar: true },
        { chave: 'valor_total', rotulo: 'Total', tipo: 'moeda', somar: true },
      ],
      linhas: rows.map((r) => ({ ...r, forma_pagamento: FORMAS[r.forma_pagamento] ?? r.forma_pagamento })),
    };
  },

  'vendas-por-dia': async ({ inicio, fim }) => {
    const { rows } = await query(
      `SELECT to_char(v.data_venda::date, 'DD/MM/YYYY') AS dia, COUNT(*) AS vendas,
              SUM(v.valor_total) AS total, ROUND(AVG(v.valor_total), 2) AS ticket_medio
         FROM vendas v WHERE ${VENDA_NO_PERIODO}
        GROUP BY v.data_venda::date ORDER BY v.data_venda::date`,
      [inicio, fim],
    );
    return {
      titulo: 'Vendas por período',
      periodo: { inicio, fim },
      colunas: [
        { chave: 'dia', rotulo: 'Dia', tipo: 'texto' },
        { chave: 'vendas', rotulo: 'Vendas', tipo: 'inteiro', somar: true },
        { chave: 'total', rotulo: 'Total vendido', tipo: 'moeda', somar: true },
        { chave: 'ticket_medio', rotulo: 'Ticket médio', tipo: 'moeda' },
      ],
      linhas: rows,
    };
  },

  'mais-vendidos': async ({ inicio, fim }) => {
    const { rows } = await query(
      `SELECT p.codigo, p.nome, SUM(i.quantidade) AS quantidade, SUM(i.subtotal) AS receita,
              SUM(i.subtotal - i.custo_unitario * i.quantidade) AS lucro
         FROM itens_venda i
         JOIN vendas v ON v.id = i.venda_id
         JOIN produtos p ON p.id = i.produto_id
        WHERE ${VENDA_NO_PERIODO}
        GROUP BY p.id ORDER BY quantidade DESC, receita DESC LIMIT 50`,
      [inicio, fim],
    );
    return {
      titulo: 'Produtos mais vendidos',
      periodo: { inicio, fim },
      colunas: [
        { chave: 'codigo', rotulo: 'Código', tipo: 'texto' },
        { chave: 'nome', rotulo: 'Produto', tipo: 'texto' },
        { chave: 'quantidade', rotulo: 'Unidades', tipo: 'inteiro', somar: true },
        { chave: 'receita', rotulo: 'Receita', tipo: 'moeda', somar: true },
        { chave: 'lucro', rotulo: 'Lucro bruto', tipo: 'moeda', somar: true },
      ],
      linhas: rows,
    };
  },

  estoque: async () => estoqueRelatorio(false),
  'estoque-baixo': async () => estoqueRelatorio(true),

  financeiro: async ({ inicio, fim }) => {
    const { rows } = await query(
      `SELECT to_char(data, 'DD/MM/YYYY') AS data, categoria, descricao,
              CASE WHEN tipo='entrada' THEN valor END AS entrada,
              CASE WHEN tipo='saida' THEN valor END AS saida
         FROM contas WHERE data BETWEEN $1 AND $2 ORDER BY contas.data, id`,
      [inicio, fim],
    );
    return {
      titulo: 'Relatório financeiro',
      periodo: { inicio, fim },
      colunas: [
        { chave: 'data', rotulo: 'Data', tipo: 'texto' },
        { chave: 'categoria', rotulo: 'Categoria', tipo: 'texto' },
        { chave: 'descricao', rotulo: 'Descrição', tipo: 'texto' },
        { chave: 'entrada', rotulo: 'Entradas', tipo: 'moeda', somar: true },
        { chave: 'saida', rotulo: 'Saídas', tipo: 'moeda', somar: true },
      ],
      linhas: rows,
    };
  },
};

async function estoqueRelatorio(apenasBaixos: boolean): Promise<Relatorio> {
  const { rows } = await query(
    `SELECT p.codigo, p.nome, COALESCE(c.nome,'—') AS categoria, p.estoque, p.estoque_minimo,
            p.custo, p.preco, p.estoque * p.custo AS valor_custo,
            CASE WHEN p.estoque = 0 THEN 'Zerado'
                 WHEN p.estoque <= p.estoque_minimo THEN 'Baixo' ELSE 'Normal' END AS situacao
       FROM produtos p LEFT JOIN categorias c ON c.id = p.categoria_id
      WHERE p.ativo ${apenasBaixos ? 'AND p.estoque <= p.estoque_minimo' : ''}
      ORDER BY ${apenasBaixos ? '(p.estoque - p.estoque_minimo),' : ''} p.nome`,
  );
  return {
    titulo: apenasBaixos ? 'Produtos com estoque baixo' : 'Relatório de estoque',
    colunas: [
      { chave: 'codigo', rotulo: 'Código', tipo: 'texto' },
      { chave: 'nome', rotulo: 'Produto', tipo: 'texto' },
      { chave: 'categoria', rotulo: 'Categoria', tipo: 'texto' },
      { chave: 'estoque', rotulo: 'Estoque', tipo: 'inteiro', somar: true },
      { chave: 'estoque_minimo', rotulo: 'Mínimo', tipo: 'inteiro' },
      { chave: 'custo', rotulo: 'Custo', tipo: 'moeda' },
      { chave: 'preco', rotulo: 'Preço', tipo: 'moeda' },
      { chave: 'valor_custo', rotulo: 'Valor em estoque', tipo: 'moeda', somar: true },
      { chave: 'situacao', rotulo: 'Situação', tipo: 'texto' },
    ],
    linhas: rows,
  };
}

export const listaDeRelatorios = [
  { id: 'vendas', titulo: 'Vendas', descricao: 'Todas as vendas concluídas no período', usaPeriodo: true },
  { id: 'vendas-por-dia', titulo: 'Vendas por período', descricao: 'Total vendido e ticket médio por dia', usaPeriodo: true },
  { id: 'mais-vendidos', titulo: 'Produtos mais vendidos', descricao: 'Ranking por unidades, com receita e lucro bruto', usaPeriodo: true },
  { id: 'estoque', titulo: 'Estoque', descricao: 'Posição atual e valor investido', usaPeriodo: false },
  { id: 'estoque-baixo', titulo: 'Estoque baixo', descricao: 'Produtos no mínimo ou abaixo dele', usaPeriodo: false },
  { id: 'financeiro', titulo: 'Financeiro', descricao: 'Entradas e saídas do período', usaPeriodo: true },
];

export function indice(_req: Request, res: Response) {
  res.json({ itens: listaDeRelatorios });
}

export async function gerar(req: Request, res: Response) {
  const tipo = String(req.params.tipo);
  const gerador = geradores[tipo];
  if (!gerador) throw new HttpError(404, 'Relatório não encontrado.');

  const f = validar(filtroSchema, req.query);
  const periodo = periodoPadrao(f.inicio, f.fim);
  const rel = await gerador(periodo);

  if (f.formato === 'csv') {
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="gestorpro-${tipo}.csv"`);
    return res.send(paraCsv(rel.colunas, rel.linhas));
  }

  const totais: Record<string, number> = {};
  for (const c of rel.colunas.filter((c) => c.somar)) {
    totais[c.chave] =
      Math.round(rel.linhas.reduce((s, l) => s + (Number(l[c.chave]) || 0), 0) * 100) / 100;
  }
  res.json({ ...rel, totais });
}
