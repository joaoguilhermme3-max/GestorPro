import { Request, Response } from 'express';
import { z } from 'zod';
import { query } from '../database/pool';
import { cancelarVenda, criarVenda, obterVenda } from '../services/vendas.service';
import { HttpError } from '../utils/errors';
import { dataISO, dinheiro, paginar, validar } from '../utils/validate';

const idSchema = z.coerce.number().int().positive();

const vendaSchema = z.object({
  cliente_id: z.number().int().positive().nullish(),
  forma_pagamento: z.enum(['dinheiro', 'pix', 'debito', 'credito']),
  desconto: dinheiro.default(0),
  itens: z
    .array(
      z.object({
        produto_id: z.number().int().positive(),
        quantidade: z.number().int('Use um número inteiro').min(1, 'Quantidade mínima: 1').max(100000),
      }),
    )
    .min(1, 'Adicione ao menos um produto')
    .max(200),
});

const filtroSchema = z.object({
  inicio: dataISO.optional(),
  fim: dataISO.optional(),
  cliente_id: z.coerce.number().int().positive().optional(),
  status: z.enum(['concluida', 'cancelada']).optional(),
});

export async function criar(req: Request, res: Response) {
  const d = validar(vendaSchema, req.body);
  const id = await criarVenda({
    clienteId: d.cliente_id,
    usuarioId: req.usuario!.id,
    formaPagamento: d.forma_pagamento,
    desconto: d.desconto,
    itens: d.itens.map((i) => ({ produtoId: i.produto_id, quantidade: i.quantidade })),
  });
  res.status(201).json(await obterVenda(id));
}

export async function listar(req: Request, res: Response) {
  const { page, limit, offset } = paginar(req.query);
  const f = validar(filtroSchema, req.query);

  const where: string[] = [];
  const params: unknown[] = [];
  if (f.inicio) {
    params.push(f.inicio);
    where.push(`v.data_venda >= $${params.length}::date`);
  }
  if (f.fim) {
    params.push(f.fim);
    where.push(`v.data_venda < ($${params.length}::date + 1)`);
  }
  if (f.cliente_id) {
    params.push(f.cliente_id);
    where.push(`v.cliente_id = $${params.length}`);
  }
  if (f.status) {
    params.push(f.status);
    where.push(`v.status = $${params.length}`);
  }
  const clausula = where.length ? `WHERE ${where.join(' AND ')}` : '';

  const totais = await query(
    `SELECT COUNT(*) AS total,
            COALESCE(SUM(v.valor_total) FILTER (WHERE v.status = 'concluida'), 0) AS soma
       FROM vendas v ${clausula}`,
    params,
  );
  const { rows } = await query(
    `SELECT v.id, v.data_venda, v.valor_total, v.desconto, v.forma_pagamento, v.status,
            c.nome AS cliente, u.nome AS vendedor,
            (SELECT COALESCE(SUM(quantidade),0) FROM itens_venda WHERE venda_id = v.id) AS qtd_itens
       FROM vendas v
       LEFT JOIN clientes c ON c.id = v.cliente_id
       JOIN usuarios u ON u.id = v.usuario_id
       ${clausula}
      ORDER BY v.data_venda DESC, v.id DESC
      LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
    [...params, limit, offset],
  );
  res.json({
    itens: rows,
    total: totais.rows[0].total,
    soma_concluidas: totais.rows[0].soma,
    page,
    limit,
  });
}

export async function obter(req: Request, res: Response) {
  const venda = await obterVenda(validar(idSchema, req.params.id));
  if (!venda) throw new HttpError(404, 'Venda não encontrada.');
  res.json(venda);
}

export async function cancelar(req: Request, res: Response) {
  const id = validar(idSchema, req.params.id);
  await cancelarVenda(id, req.usuario!.id);
  res.json(await obterVenda(id));
}
