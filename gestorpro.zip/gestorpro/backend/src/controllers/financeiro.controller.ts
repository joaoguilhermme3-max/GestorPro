import { Request, Response } from 'express';
import { z } from 'zod';
import { montarUpdate, query } from '../database/pool';
import { periodoPadrao } from '../utils/datas';
import { HttpError } from '../utils/errors';
import { dataISO, escapeLike, paginar, validar } from '../utils/validate';

export const CATEGORIAS = {
  entrada: ['Venda', 'Pagamento recebido', 'Outras receitas'],
  saida: [
    'Compra de mercadoria',
    'Energia',
    'Água',
    'Aluguel',
    'Salários',
    'Impostos',
    'Estorno',
    'Outras despesas',
  ],
} as const;

const todasCategorias = [...CATEGORIAS.entrada, ...CATEGORIAS.saida] as [string, ...string[]];
const idSchema = z.coerce.number().int().positive();

const contaSchema = z
  .object({
    tipo: z.enum(['entrada', 'saida']),
    categoria: z.enum(todasCategorias),
    descricao: z.string().trim().min(2, 'Descreva o lançamento').max(200),
    valor: z.number().positive('O valor precisa ser maior que zero').max(99999999.99)
      .transform((v) => Math.round(v * 100) / 100),
    data: dataISO.optional(),
  })
  .superRefine((d, ctx) => {
    if (!(CATEGORIAS[d.tipo] as readonly string[]).includes(d.categoria)) {
      ctx.addIssue({ code: 'custom', path: ['categoria'], message: 'Categoria incompatível com o tipo' });
    }
  });

const filtroSchema = z.object({
  tipo: z.enum(['entrada', 'saida']).optional(),
  inicio: dataISO.optional(),
  fim: dataISO.optional(),
  q: z.string().trim().max(80).optional(),
});

export function categorias(_req: Request, res: Response) {
  // "Estorno" é lançado pelo sistema ao cancelar uma venda; não aparece para escolha manual.
  res.json({
    entrada: CATEGORIAS.entrada,
    saida: CATEGORIAS.saida.filter((c) => c !== 'Estorno'),
  });
}

export async function listar(req: Request, res: Response) {
  const { page, limit, offset } = paginar(req.query);
  const f = validar(filtroSchema, req.query);
  const { inicio, fim } = periodoPadrao(f.inicio, f.fim);

  const params: unknown[] = [inicio, fim];
  const where = ['c.data BETWEEN $1 AND $2'];
  if (f.tipo) {
    params.push(f.tipo);
    where.push(`c.tipo = $${params.length}`);
  }
  if (f.q) {
    params.push(`%${escapeLike(f.q)}%`);
    where.push(`(c.descricao ILIKE $${params.length} OR c.categoria ILIKE $${params.length})`);
  }
  const clausula = where.join(' AND ');

  const totais = await query(
    `SELECT COUNT(*) AS total,
            COALESCE(SUM(valor) FILTER (WHERE tipo='entrada'),0) AS entradas,
            COALESCE(SUM(valor) FILTER (WHERE tipo='saida'),0) AS saidas
       FROM contas c WHERE ${clausula}`,
    params,
  );
  const { rows } = await query(
    `SELECT c.id, c.tipo, c.categoria, c.descricao, c.valor, c.data, c.venda_id, u.nome AS usuario
       FROM contas c LEFT JOIN usuarios u ON u.id = c.usuario_id
      WHERE ${clausula}
      ORDER BY c.data DESC, c.id DESC
      LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
    [...params, limit, offset],
  );
  const t = totais.rows[0];
  res.json({
    itens: rows,
    total: t.total,
    page,
    limit,
    periodo: { inicio, fim },
    totais: { entradas: t.entradas, saidas: t.saidas, saldo: Math.round((t.entradas - t.saidas) * 100) / 100 },
  });
}

export async function criar(req: Request, res: Response) {
  const d = validar(contaSchema, req.body);
  const { rows } = await query(
    `INSERT INTO contas (tipo, categoria, descricao, valor, data, usuario_id)
     VALUES ($1,$2,$3,$4,COALESCE($5::date, CURRENT_DATE),$6)
     RETURNING id, tipo, categoria, descricao, valor, data, venda_id`,
    [d.tipo, d.categoria, d.descricao, d.valor, d.data ?? null, req.usuario!.id],
  );
  res.status(201).json(rows[0]);
}

async function garantirManual(id: number) {
  const { rows } = await query('SELECT venda_id FROM contas WHERE id = $1', [id]);
  if (!rows[0]) throw new HttpError(404, 'Lançamento não encontrado.');
  if (rows[0].venda_id) {
    throw new HttpError(409, 'Lançamentos de vendas não podem ser alterados. Cancele a venda, se necessário.');
  }
}

export async function atualizar(req: Request, res: Response) {
  const id = validar(idSchema, req.params.id);
  const d = validar(contaSchema, req.body);
  await garantirManual(id);
  const up = montarUpdate({ tipo: d.tipo, categoria: d.categoria, descricao: d.descricao, valor: d.valor, data: d.data });
  const { rows } = await query(
    `UPDATE contas SET ${up.set} WHERE id = $${up.valores.length + 1}
     RETURNING id, tipo, categoria, descricao, valor, data, venda_id`,
    [...up.valores, id],
  );
  res.json(rows[0]);
}

export async function remover(req: Request, res: Response) {
  const id = validar(idSchema, req.params.id);
  await garantirManual(id);
  await query('DELETE FROM contas WHERE id = $1', [id]);
  res.status(204).end();
}

export async function resumo(req: Request, res: Response) {
  const f = validar(filtroSchema.pick({ inicio: true, fim: true }), req.query);
  const { inicio, fim } = periodoPadrao(f.inicio, f.fim);

  const porCategoria = await query(
    `SELECT tipo, categoria, SUM(valor) AS total
       FROM contas WHERE data BETWEEN $1 AND $2
      GROUP BY tipo, categoria ORDER BY tipo, total DESC`,
    [inicio, fim],
  );
  const entradas = porCategoria.rows.filter((r) => r.tipo === 'entrada').reduce((s, r) => s + r.total, 0);
  const saidas = porCategoria.rows.filter((r) => r.tipo === 'saida').reduce((s, r) => s + r.total, 0);

  const porMes = await query(
    `SELECT to_char(m, 'YYYY-MM') AS mes,
            COALESCE(SUM(c.valor) FILTER (WHERE c.tipo='entrada'),0) AS entradas,
            COALESCE(SUM(c.valor) FILTER (WHERE c.tipo='saida'),0) AS saidas
       FROM generate_series(date_trunc('month', CURRENT_DATE) - interval '5 months',
                            date_trunc('month', CURRENT_DATE), interval '1 month') m
       LEFT JOIN contas c ON date_trunc('month', c.data) = m
      GROUP BY m ORDER BY m`,
  );

  res.json({
    periodo: { inicio, fim },
    entradas: Math.round(entradas * 100) / 100,
    saidas: Math.round(saidas * 100) / 100,
    saldo: Math.round((entradas - saidas) * 100) / 100,
    por_categoria: porCategoria.rows,
    ultimos_meses: porMes.rows,
  });
}
