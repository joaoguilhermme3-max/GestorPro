import { Request, Response } from 'express';
import { z } from 'zod';
import { montarUpdate, query, withTransaction } from '../database/pool';
import { movimentarEstoque } from '../services/estoque.service';
import { HttpError } from '../utils/errors';
import {
  boolQuery,
  dinheiro,
  escapeLike,
  inteiroNaoNegativo,
  paginar,
  textoOpcional,
  validar,
} from '../utils/validate';

const SELECT = `
  SELECT p.id, p.nome, p.codigo, p.descricao, p.preco, p.custo, p.estoque, p.estoque_minimo,
         p.categoria_id, c.nome AS categoria, p.ativo,
         (p.estoque <= p.estoque_minimo) AS estoque_baixo, p.criado_em
    FROM produtos p LEFT JOIN categorias c ON c.id = p.categoria_id`;

const idSchema = z.coerce.number().int().positive();

const baseSchema = z.object({
  nome: z.string().trim().min(2, 'Informe o nome').max(160),
  codigo: z.string().trim().min(1, 'Informe o código').max(40),
  descricao: textoOpcional(1000),
  preco: dinheiro,
  custo: dinheiro.default(0),
  estoque_minimo: inteiroNaoNegativo.default(0),
  categoria_id: z.number().int().positive().nullish(),
});
const criarSchema = baseSchema.extend({ estoque: inteiroNaoNegativo.default(0) });
const atualizarSchema = baseSchema.partial().extend({ ativo: z.boolean().optional() });

const filtroSchema = z.object({
  q: z.string().trim().max(80).optional(),
  categoria_id: z.coerce.number().int().positive().optional(),
  baixo: boolQuery,
  ativo: z.enum(['true', 'false']).default('true').transform((v) => v === 'true'),
});

/** Funcionário não enxerga o custo dos produtos. */
const filtrarCusto = (req: Request, p: any) => {
  if (req.usuario!.perfil !== 'admin') delete p.custo;
  return p;
};

export async function listar(req: Request, res: Response) {
  const { page, limit, offset } = paginar(req.query);
  const f = validar(filtroSchema, req.query);

  const params: unknown[] = [f.ativo];
  const where = ['p.ativo = $1'];
  if (f.q) {
    params.push(`%${escapeLike(f.q)}%`);
    where.push(`(p.nome ILIKE $${params.length} OR p.codigo ILIKE $${params.length})`);
  }
  if (f.categoria_id) {
    params.push(f.categoria_id);
    where.push(`p.categoria_id = $${params.length}`);
  }
  if (f.baixo) where.push('p.estoque <= p.estoque_minimo');
  const clausula = where.join(' AND ');

  const total = await query(`SELECT COUNT(*) AS total FROM produtos p WHERE ${clausula}`, params);
  const { rows } = await query(
    `${SELECT} WHERE ${clausula} ORDER BY p.nome LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
    [...params, limit, offset],
  );
  res.json({
    itens: rows.map((p) => filtrarCusto(req, p)),
    total: total.rows[0].total,
    page,
    limit,
  });
}

export async function obter(req: Request, res: Response) {
  const id = validar(idSchema, req.params.id);
  const { rows } = await query(`${SELECT} WHERE p.id = $1`, [id]);
  if (!rows[0]) throw new HttpError(404, 'Produto não encontrado.');
  res.json(filtrarCusto(req, rows[0]));
}

export async function criar(req: Request, res: Response) {
  const d = validar(criarSchema, req.body);
  const custo = req.usuario!.perfil === 'admin' ? d.custo : 0;

  const id = await withTransaction(async (client) => {
    const { rows } = await client.query(
      `INSERT INTO produtos (nome, codigo, descricao, preco, custo, estoque, estoque_minimo, categoria_id)
       VALUES ($1,$2,$3,$4,$5,0,$6,$7) RETURNING id`,
      [d.nome, d.codigo, d.descricao ?? null, d.preco, custo, d.estoque_minimo, d.categoria_id ?? null],
    );
    if (d.estoque > 0) {
      await movimentarEstoque(client, {
        produtoId: rows[0].id,
        delta: d.estoque,
        tipo: 'entrada',
        motivo: 'Estoque inicial',
        usuarioId: req.usuario!.id,
      });
    }
    return rows[0].id as number;
  });

  const { rows } = await query(`${SELECT} WHERE p.id = $1`, [id]);
  res.status(201).json(filtrarCusto(req, rows[0]));
}

export async function atualizar(req: Request, res: Response) {
  const id = validar(idSchema, req.params.id);
  const d = validar(atualizarSchema, req.body);
  if (req.usuario!.perfil !== 'admin') delete d.custo;

  const up = montarUpdate({ ...d, atualizado_em: new Date() });
  const { rowCount } = await query(
    `UPDATE produtos SET ${up.set} WHERE id = $${up.valores.length + 1}`,
    [...up.valores, id],
  );
  if (!rowCount) throw new HttpError(404, 'Produto não encontrado.');

  const { rows } = await query(`${SELECT} WHERE p.id = $1`, [id]);
  res.json(filtrarCusto(req, rows[0]));
}

/** Produtos com histórico de vendas não podem sumir: são apenas desativados. */
export async function remover(req: Request, res: Response) {
  const id = validar(idSchema, req.params.id);
  const r = await query('UPDATE produtos SET ativo = FALSE, atualizado_em = NOW() WHERE id = $1', [id]);
  if (!r.rowCount) throw new HttpError(404, 'Produto não encontrado.');
  res.status(204).end();
}
