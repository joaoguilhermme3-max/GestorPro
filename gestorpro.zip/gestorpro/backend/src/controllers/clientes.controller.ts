import { Request, Response } from 'express';
import { z } from 'zod';
import { montarUpdate, query } from '../database/pool';
import { normalizarCpf } from '../utils/cpf';
import { HttpError } from '../utils/errors';
import { emailSchema, escapeLike, paginar, textoOpcional, validar } from '../utils/validate';

const idSchema = z.coerce.number().int().positive();

const cpfSchema = z
  .string()
  .trim()
  .nullish()
  .transform((v, ctx) => {
    if (v === undefined) return undefined;
    if (v === null || v === '') return null;
    const cpf = normalizarCpf(v);
    if (!cpf) {
      ctx.addIssue({ code: 'custom', message: 'CPF inválido' });
      return z.NEVER;
    }
    return cpf;
  });

const emailOpcional = z
  .union([emailSchema, z.literal('').transform(() => null), z.null()])
  .optional();

const baseSchema = z.object({
  nome: z.string().trim().min(2, 'Informe o nome').max(160),
  cpf: cpfSchema,
  telefone: textoOpcional(20),
  email: emailOpcional,
  endereco: textoOpcional(300),
});
const atualizarSchema = baseSchema.partial();

const ESTATISTICAS = `
  SELECT c.id, c.nome, c.cpf, c.telefone, c.email, c.endereco, c.criado_em,
         COALESCE(s.compras, 0) AS compras,
         COALESCE(s.total_gasto, 0) AS total_gasto,
         s.ultima_compra
    FROM clientes c
    LEFT JOIN (
      SELECT cliente_id, COUNT(*) AS compras, SUM(valor_total) AS total_gasto, MAX(data_venda) AS ultima_compra
        FROM vendas WHERE status = 'concluida' GROUP BY cliente_id
    ) s ON s.cliente_id = c.id`;

export async function listar(req: Request, res: Response) {
  const { page, limit, offset } = paginar(req.query);
  const q = validar(z.object({ q: z.string().trim().max(80).optional() }), req.query).q;

  const params: unknown[] = [];
  let where = 'c.ativo';
  if (q) {
    params.push(`%${escapeLike(q)}%`);
    where += ` AND (c.nome ILIKE $1 OR c.cpf ILIKE $1 OR c.telefone ILIKE $1 OR c.email ILIKE $1)`;
  }
  const total = await query(`SELECT COUNT(*) AS total FROM clientes c WHERE ${where}`, params);
  const { rows } = await query(
    `${ESTATISTICAS} WHERE ${where} ORDER BY c.nome LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
    [...params, limit, offset],
  );
  res.json({ itens: rows, total: total.rows[0].total, page, limit });
}

export async function obter(req: Request, res: Response) {
  const id = validar(idSchema, req.params.id);
  const { rows } = await query(`${ESTATISTICAS} WHERE c.id = $1 AND c.ativo`, [id]);
  if (!rows[0]) throw new HttpError(404, 'Cliente não encontrado.');

  const vendas = await query(
    `SELECT id, data_venda, valor_total, forma_pagamento, status
       FROM vendas WHERE cliente_id = $1 ORDER BY data_venda DESC LIMIT 10`,
    [id],
  );
  res.json({ ...rows[0], ultimas_vendas: vendas.rows });
}

export async function criar(req: Request, res: Response) {
  const d = validar(baseSchema, req.body);
  const { rows } = await query(
    `INSERT INTO clientes (nome, cpf, telefone, email, endereco) VALUES ($1,$2,$3,$4,$5) RETURNING id`,
    [d.nome, d.cpf ?? null, d.telefone ?? null, d.email ?? null, d.endereco ?? null],
  );
  const novo = await query(`${ESTATISTICAS} WHERE c.id = $1`, [rows[0].id]);
  res.status(201).json(novo.rows[0]);
}

export async function atualizar(req: Request, res: Response) {
  const id = validar(idSchema, req.params.id);
  const d = validar(atualizarSchema, req.body);
  const up = montarUpdate(d);
  if (up.vazio) throw new HttpError(400, 'Nenhum campo para atualizar.');

  const { rowCount } = await query(
    `UPDATE clientes SET ${up.set} WHERE id = $${up.valores.length + 1} AND ativo`,
    [...up.valores, id],
  );
  if (!rowCount) throw new HttpError(404, 'Cliente não encontrado.');
  const { rows } = await query(`${ESTATISTICAS} WHERE c.id = $1`, [id]);
  res.json(rows[0]);
}

/** Clientes com compras não são apagados: apenas ocultados. */
export async function remover(req: Request, res: Response) {
  const id = validar(idSchema, req.params.id);
  const r = await query('UPDATE clientes SET ativo = FALSE WHERE id = $1 AND ativo', [id]);
  if (!r.rowCount) throw new HttpError(404, 'Cliente não encontrado.');
  res.status(204).end();
}
