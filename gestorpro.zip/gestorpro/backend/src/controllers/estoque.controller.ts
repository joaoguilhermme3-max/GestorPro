import { Request, Response } from 'express';
import { z } from 'zod';
import { query, withTransaction } from '../database/pool';
import { movimentarEstoque } from '../services/estoque.service';
import { HttpError } from '../utils/errors';
import { dinheiro, paginar, textoOpcional, validar } from '../utils/validate';

const filtroSchema = z.object({
  produto_id: z.coerce.number().int().positive().optional(),
  tipo: z.enum(['entrada', 'venda', 'ajuste', 'cancelamento']).optional(),
});

export async function listarMovimentacoes(req: Request, res: Response) {
  const { page, limit, offset } = paginar(req.query);
  const f = validar(filtroSchema, req.query);

  const where: string[] = [];
  const params: unknown[] = [];
  if (f.produto_id) {
    params.push(f.produto_id);
    where.push(`m.produto_id = $${params.length}`);
  }
  if (f.tipo) {
    params.push(f.tipo);
    where.push(`m.tipo = $${params.length}`);
  }
  const clausula = where.length ? `WHERE ${where.join(' AND ')}` : '';

  const total = await query(`SELECT COUNT(*) AS total FROM movimentacoes_estoque m ${clausula}`, params);
  const { rows } = await query(
    `SELECT m.id, m.produto_id, p.nome AS produto, p.codigo, m.tipo, m.quantidade, m.saldo_apos,
            m.motivo, m.venda_id, u.nome AS usuario, m.criado_em
       FROM movimentacoes_estoque m
       JOIN produtos p ON p.id = m.produto_id
       LEFT JOIN usuarios u ON u.id = m.usuario_id
       ${clausula}
      ORDER BY m.criado_em DESC, m.id DESC
      LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
    [...params, limit, offset],
  );
  res.json({ itens: rows, total: total.rows[0].total, page, limit });
}

const movimentoSchema = z
  .object({
    produto_id: z.number().int().positive(),
    tipo: z.enum(['entrada', 'ajuste']),
    quantidade: z.number().int('Use um número inteiro').min(-1_000_000).max(1_000_000),
    motivo: textoOpcional(200),
    // Só para entradas: se informado, lança a compra como despesa no financeiro.
    valor_compra: dinheiro.optional(),
  })
  .superRefine((d, ctx) => {
    if (d.quantidade === 0) {
      ctx.addIssue({ code: 'custom', path: ['quantidade'], message: 'Informe uma quantidade diferente de zero' });
    }
    if (d.tipo === 'entrada' && d.quantidade < 0) {
      ctx.addIssue({ code: 'custom', path: ['quantidade'], message: 'Na entrada, use uma quantidade positiva' });
    }
    if (d.tipo === 'ajuste' && !d.motivo) {
      ctx.addIssue({ code: 'custom', path: ['motivo'], message: 'Explique o motivo do ajuste' });
    }
  });

export async function registrarMovimentacao(req: Request, res: Response) {
  const d = validar(movimentoSchema, req.body);
  const usuarioId = req.usuario!.id;

  const resultado = await withTransaction(async (client) => {
    const saldo = await movimentarEstoque(client, {
      produtoId: d.produto_id,
      delta: d.quantidade,
      tipo: d.tipo,
      motivo: d.motivo,
      usuarioId,
    });

    if (d.tipo === 'entrada' && d.valor_compra && d.valor_compra > 0) {
      const p = await client.query('SELECT nome FROM produtos WHERE id = $1', [d.produto_id]);
      await client.query(
        `INSERT INTO contas (tipo, categoria, descricao, valor, data, usuario_id)
         VALUES ('saida','Compra de mercadoria',$1,$2,CURRENT_DATE,$3)`,
        [`Entrada de ${d.quantidade}× ${p.rows[0].nome}`.slice(0, 200), d.valor_compra, usuarioId],
      );
    }
    return saldo;
  });

  res.status(201).json({ produto_id: d.produto_id, estoque_atual: resultado });
}

export async function alertas(_req: Request, res: Response) {
  const { rows } = await query(
    `SELECT p.id, p.nome, p.codigo, p.estoque, p.estoque_minimo, c.nome AS categoria
       FROM produtos p LEFT JOIN categorias c ON c.id = p.categoria_id
      WHERE p.ativo AND p.estoque <= p.estoque_minimo
      ORDER BY (p.estoque - p.estoque_minimo), p.nome`,
  );
  res.json({ itens: rows, total: rows.length });
}

export async function resumo(_req: Request, res: Response) {
  const { rows } = await query(
    `SELECT COUNT(*) AS produtos,
            COALESCE(SUM(estoque),0) AS unidades,
            COALESCE(SUM(estoque * custo),0) AS valor_custo,
            COALESCE(SUM(estoque * preco),0) AS valor_venda,
            COUNT(*) FILTER (WHERE estoque = 0) AS zerados,
            COUNT(*) FILTER (WHERE estoque <= estoque_minimo) AS baixos
       FROM produtos WHERE ativo`,
  );
  res.json(rows[0]);
}
