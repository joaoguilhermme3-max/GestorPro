import { Request, Response } from 'express';
import { query } from '../database/pool';

export async function dashboard(req: Request, res: Response) {
  const admin = req.usuario!.perfil === 'admin';

  const [hoje, mes, contagens, dias, ultimas, alertas, maisVendidos, financeiro] = await Promise.all([
    query(
      `SELECT COALESCE(SUM(valor_total),0) AS total, COUNT(*) AS quantidade FROM vendas
        WHERE status='concluida' AND data_venda >= CURRENT_DATE AND data_venda < CURRENT_DATE + 1`,
    ),
    query(
      `SELECT COALESCE(SUM(valor_total),0) AS total, COUNT(*) AS quantidade FROM vendas
        WHERE status='concluida' AND data_venda >= date_trunc('month', CURRENT_DATE)`,
    ),
    query(
      `SELECT (SELECT COUNT(*) FROM produtos WHERE ativo) AS produtos,
              (SELECT COUNT(*) FROM clientes WHERE ativo) AS clientes,
              (SELECT COUNT(*) FROM produtos WHERE ativo AND estoque <= estoque_minimo) AS estoque_baixo`,
    ),
    query(
      `SELECT d::date AS data, COALESCE(SUM(v.valor_total),0) AS total, COUNT(v.id) AS quantidade
         FROM generate_series((CURRENT_DATE - 6)::timestamp, CURRENT_DATE::timestamp, interval '1 day') d
         LEFT JOIN vendas v ON v.status='concluida' AND v.data_venda >= d AND v.data_venda < d + interval '1 day'
        GROUP BY d ORDER BY d`,
    ),
    query(
      `SELECT v.id, v.data_venda, v.valor_total, v.forma_pagamento, COALESCE(c.nome,'Consumidor') AS cliente
         FROM vendas v LEFT JOIN clientes c ON c.id = v.cliente_id
        WHERE v.status='concluida' ORDER BY v.data_venda DESC, v.id DESC LIMIT 6`,
    ),
    query(
      `SELECT id, nome, codigo, estoque, estoque_minimo FROM produtos
        WHERE ativo AND estoque <= estoque_minimo
        ORDER BY (estoque - estoque_minimo), nome LIMIT 6`,
    ),
    query(
      `SELECT p.id, p.nome, SUM(i.quantidade) AS quantidade, SUM(i.subtotal) AS receita
         FROM itens_venda i
         JOIN vendas v ON v.id = i.venda_id AND v.status='concluida'
              AND v.data_venda >= date_trunc('month', CURRENT_DATE)
         JOIN produtos p ON p.id = i.produto_id
        GROUP BY p.id ORDER BY quantidade DESC, receita DESC LIMIT 5`,
    ),
    admin
      ? query(
          `SELECT COALESCE(SUM(valor) FILTER (WHERE tipo='entrada'),0) AS entradas,
                  COALESCE(SUM(valor) FILTER (WHERE tipo='saida'),0) AS saidas
             FROM contas WHERE data >= date_trunc('month', CURRENT_DATE)::date`,
        )
      : Promise.resolve(null),
  ]);

  const c = contagens.rows[0];
  res.json({
    vendas_hoje: hoje.rows[0],
    vendas_mes: mes.rows[0],
    produtos: c.produtos,
    clientes: c.clientes,
    estoque_baixo: c.estoque_baixo,
    vendas_7_dias: dias.rows,
    ultimas_vendas: ultimas.rows,
    alertas: alertas.rows,
    mais_vendidos_mes: maisVendidos.rows,
    financeiro_mes: financeiro
      ? {
          entradas: financeiro.rows[0].entradas,
          saidas: financeiro.rows[0].saidas,
          saldo: Math.round((financeiro.rows[0].entradas - financeiro.rows[0].saidas) * 100) / 100,
        }
      : null,
  });
}
