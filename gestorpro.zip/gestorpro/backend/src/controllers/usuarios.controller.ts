import bcrypt from 'bcryptjs';
import { Request, Response } from 'express';
import { z } from 'zod';
import { montarUpdate, query } from '../database/pool';
import { HttpError } from '../utils/errors';
import { emailSchema, validar } from '../utils/validate';

const COLUNAS = 'id, nome, email, perfil, ativo, criado_em';

const criarSchema = z.object({
  nome: z.string().trim().min(2, 'Informe o nome').max(120),
  email: emailSchema,
  senha: z.string().min(6, 'A senha precisa ter ao menos 6 caracteres').max(100),
  perfil: z.enum(['admin', 'funcionario']),
});

const atualizarSchema = z.object({
  nome: z.string().trim().min(2).max(120).optional(),
  email: emailSchema.optional(),
  senha: z.string().min(6, 'A senha precisa ter ao menos 6 caracteres').max(100).optional(),
  perfil: z.enum(['admin', 'funcionario']).optional(),
  ativo: z.boolean().optional(),
});

const idSchema = z.coerce.number().int().positive();

export async function listar(_req: Request, res: Response) {
  const { rows } = await query(`SELECT ${COLUNAS} FROM usuarios ORDER BY nome`);
  res.json({ itens: rows });
}

export async function criar(req: Request, res: Response) {
  const d = validar(criarSchema, req.body);
  const { rows } = await query(
    `INSERT INTO usuarios (nome, email, senha_hash, perfil) VALUES ($1,$2,$3,$4) RETURNING ${COLUNAS}`,
    [d.nome, d.email, await bcrypt.hash(d.senha, 10), d.perfil],
  );
  res.status(201).json(rows[0]);
}

export async function atualizar(req: Request, res: Response) {
  const id = validar(idSchema, req.params.id);
  const { senha, ...resto } = validar(atualizarSchema, req.body);

  if (id === req.usuario!.id && (resto.perfil === 'funcionario' || resto.ativo === false)) {
    throw new HttpError(400, 'Você não pode remover o seu próprio acesso de administrador.');
  }

  const campos: Record<string, unknown> = { ...resto };
  if (senha) campos.senha_hash = await bcrypt.hash(senha, 10);
  const up = montarUpdate(campos);
  if (up.vazio) throw new HttpError(400, 'Nenhum campo para atualizar.');

  const { rows } = await query(
    `UPDATE usuarios SET ${up.set} WHERE id = $${up.valores.length + 1} RETURNING ${COLUNAS}`,
    [...up.valores, id],
  );
  if (!rows[0]) throw new HttpError(404, 'Usuário não encontrado.');
  res.json(rows[0]);
}
