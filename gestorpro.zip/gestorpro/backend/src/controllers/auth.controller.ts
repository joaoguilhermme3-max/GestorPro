import bcrypt from 'bcryptjs';
import { Request, Response } from 'express';
import { z } from 'zod';
import { gerarToken } from '../middlewares/auth';
import { query } from '../database/pool';
import { HttpError } from '../utils/errors';
import { emailSchema, validar } from '../utils/validate';

// Hash de mentira: a comparação roda mesmo quando o e-mail não existe (evita revelar contas).
const HASH_FALSO = bcrypt.hashSync('gestorpro-hash-falso', 10);

export async function login(req: Request, res: Response) {
  const { email, senha } = validar(
    z.object({ email: emailSchema, senha: z.string().min(1, 'Informe a senha') }),
    req.body,
  );

  const { rows } = await query(
    'SELECT id, nome, email, perfil, senha_hash, ativo FROM usuarios WHERE email = $1',
    [email],
  );
  const u = rows[0];
  const senhaOk = await bcrypt.compare(senha, u?.senha_hash ?? HASH_FALSO);
  if (!u || !u.ativo || !senhaOk) throw new HttpError(401, 'E-mail ou senha incorretos.');

  const usuario = { id: u.id, nome: u.nome, email: u.email, perfil: u.perfil };
  res.json({ token: gerarToken(usuario), usuario });
}

export async function me(req: Request, res: Response) {
  res.json({ usuario: req.usuario });
}

export async function alterarSenha(req: Request, res: Response) {
  const { senha_atual, nova_senha } = validar(
    z.object({
      senha_atual: z.string().min(1),
      nova_senha: z.string().min(6, 'A nova senha precisa ter ao menos 6 caracteres').max(100),
    }),
    req.body,
  );
  const { rows } = await query('SELECT senha_hash FROM usuarios WHERE id = $1', [req.usuario!.id]);
  if (!(await bcrypt.compare(senha_atual, rows[0].senha_hash))) {
    throw new HttpError(400, 'A senha atual está incorreta.');
  }
  await query('UPDATE usuarios SET senha_hash = $1 WHERE id = $2', [
    await bcrypt.hash(nova_senha, 10),
    req.usuario!.id,
  ]);
  res.json({ mensagem: 'Senha alterada com sucesso.' });
}
