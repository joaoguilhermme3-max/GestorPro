import { Request, Response } from 'express';
import { z } from 'zod';
import { query } from '../database/pool';
import { HttpError } from '../utils/errors';
import { validar } from '../utils/validate';

const schema = z.object({ nome: z.string().trim().min(2, 'Informe o nome').max(80) });
const idSchema = z.coerce.number().int().positive();

export async function listar(_req: Request, res: Response) {
  const { rows } = await query(
    `SELECT c.id, c.nome, COUNT(p.id) FILTER (WHERE p.ativo) AS produtos
       FROM categorias c LEFT JOIN produtos p ON p.categoria_id = c.id
      GROUP BY c.id ORDER BY c.nome`,
  );
  res.json({ itens: rows });
}

export async function criar(req: Request, res: Response) {
  const { nome } = validar(schema, req.body);
  const { rows } = await query('INSERT INTO categorias (nome) VALUES ($1) RETURNING id, nome', [nome]);
  res.status(201).json({ ...rows[0], produtos: 0 });
}

export async function atualizar(req: Request, res: Response) {
  const id = validar(idSchema, req.params.id);
  const { nome } = validar(schema, req.body);
  const { rows } = await query('UPDATE categorias SET nome = $1 WHERE id = $2 RETURNING id, nome', [nome, id]);
  if (!rows[0]) throw new HttpError(404, 'Categoria não encontrada.');
  res.json(rows[0]);
}

export async function remover(req: Request, res: Response) {
  const id = validar(idSchema, req.params.id);
  const r = await query('DELETE FROM categorias WHERE id = $1', [id]);
  if (!r.rowCount) throw new HttpError(404, 'Categoria não encontrada.');
  res.status(204).end();
}
