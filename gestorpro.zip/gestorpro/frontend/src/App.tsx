import { ReactNode } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Carregando } from './components/ui';
import { useAuth } from './contexts/AuthContext';
import Clientes from './pages/Clientes';
import Dashboard from './pages/Dashboard';
import Estoque from './pages/Estoque';
import Financeiro from './pages/Financeiro';
import Login from './pages/Login';
import NovaVenda from './pages/NovaVenda';
import Produtos from './pages/Produtos';
import Relatorios from './pages/Relatorios';
import Usuarios from './pages/Usuarios';
import Vendas from './pages/Vendas';

function Protegida({ children }: { children: ReactNode }) {
  const { usuario, carregando } = useAuth();
  if (carregando) return <Carregando texto="Abrindo o GestorPro…" />;
  if (!usuario) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

function SomenteAdmin({ children }: { children: ReactNode }) {
  const { ehAdmin } = useAuth();
  if (!ehAdmin) {
    return (
      <div className="folha mx-auto mt-10 max-w-md p-8 text-center">
        <h1 className="text-xl font-extrabold">Área do administrador</h1>
        <p className="mt-2 text-sm text-mudo">Seu perfil não tem acesso a esta página. Peça a um administrador, se precisar.</p>
      </div>
    );
  }
  return <>{children}</>;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route
        element={
          <Protegida>
            <Layout />
          </Protegida>
        }
      >
        <Route index element={<Dashboard />} />
        <Route path="vendas" element={<Vendas />} />
        <Route path="vendas/nova" element={<NovaVenda />} />
        <Route path="produtos" element={<Produtos />} />
        <Route path="clientes" element={<Clientes />} />
        <Route path="estoque" element={<SomenteAdmin><Estoque /></SomenteAdmin>} />
        <Route path="financeiro" element={<SomenteAdmin><Financeiro /></SomenteAdmin>} />
        <Route path="relatorios" element={<SomenteAdmin><Relatorios /></SomenteAdmin>} />
        <Route path="usuarios" element={<SomenteAdmin><Usuarios /></SomenteAdmin>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}
