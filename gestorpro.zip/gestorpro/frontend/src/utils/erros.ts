import { ApiError } from '../services/api';

export const mensagemDe = (err: unknown) => (err instanceof ApiError ? err.message : 'Algo deu errado. Tente novamente.');

/** Erros de validação da API → { campo: mensagem } para mostrar junto de cada campo. */
export function errosPorCampo(err: unknown): Record<string, string> {
  if (err instanceof ApiError && err.detalhes) {
    return Object.fromEntries(err.detalhes.filter((d) => d.campo).map((d) => [d.campo, d.mensagem]));
  }
  return {};
}
