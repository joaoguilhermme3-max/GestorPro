export type Perfil = 'admin' | 'funcionario';
export type FormaPagamento = 'dinheiro' | 'pix' | 'debito' | 'credito';

export interface Usuario {
  id: number;
  nome: string;
  email: string;
  perfil: Perfil;
  ativo?: boolean;
  criado_em?: string;
}

export interface Pagina<T> {
  itens: T[];
  total: number;
  page: number;
  limit: number;
}

export interface Categoria {
  id: number;
  nome: string;
  produtos: number;
}

export interface Produto {
  id: number;
  nome: string;
  codigo: string;
  descricao: string | null;
  preco: number;
  custo?: number; // só o administrador recebe
  estoque: number;
  estoque_minimo: number;
  categoria_id: number | null;
  categoria: string | null;
  ativo: boolean;
  estoque_baixo: boolean;
}

export interface Cliente {
  id: number;
  nome: string;
  cpf: string | null;
  telefone: string | null;
  email: string | null;
  endereco: string | null;
  compras: number;
  total_gasto: number;
  ultima_compra: string | null;
  ultimas_vendas?: { id: number; data_venda: string; valor_total: number; forma_pagamento: FormaPagamento; status: string }[];
}

export interface VendaResumo {
  id: number;
  data_venda: string;
  valor_total: number;
  desconto: number;
  forma_pagamento: FormaPagamento;
  status: 'concluida' | 'cancelada';
  cliente: string | null;
  vendedor: string;
  qtd_itens: number;
}

export interface VendaDetalhe {
  id: number;
  cliente: string | null;
  vendedor: string;
  subtotal: number;
  desconto: number;
  valor_total: number;
  forma_pagamento: FormaPagamento;
  status: 'concluida' | 'cancelada';
  data_venda: string;
  itens: { id: number; produto_id: number; produto: string; codigo: string; quantidade: number; preco_unitario: number; subtotal: number }[];
}

export interface Movimentacao {
  id: number;
  produto_id: number;
  produto: string;
  codigo: string;
  tipo: 'entrada' | 'venda' | 'ajuste' | 'cancelamento';
  quantidade: number;
  saldo_apos: number;
  motivo: string | null;
  usuario: string | null;
  criado_em: string;
}

export interface Conta {
  id: number;
  tipo: 'entrada' | 'saida';
  categoria: string;
  descricao: string;
  valor: number;
  data: string;
  venda_id: number | null;
  usuario?: string | null;
}

export interface Dashboard {
  vendas_hoje: { total: number; quantidade: number };
  vendas_mes: { total: number; quantidade: number };
  produtos: number;
  clientes: number;
  estoque_baixo: number;
  vendas_7_dias: { data: string; total: number; quantidade: number }[];
  ultimas_vendas: { id: number; data_venda: string; valor_total: number; forma_pagamento: FormaPagamento; cliente: string }[];
  alertas: { id: number; nome: string; codigo: string; estoque: number; estoque_minimo: number }[];
  mais_vendidos_mes: { id: number; nome: string; quantidade: number; receita: number }[];
  financeiro_mes: { entradas: number; saidas: number; saldo: number } | null;
}

export interface ColunaRelatorio {
  chave: string;
  rotulo: string;
  tipo: 'texto' | 'moeda' | 'inteiro';
  somar?: boolean;
}

export interface Relatorio {
  titulo: string;
  periodo?: { inicio: string; fim: string };
  colunas: ColunaRelatorio[];
  linhas: Record<string, string | number | null>[];
  totais: Record<string, number>;
}
