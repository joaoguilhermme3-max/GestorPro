import { createContext, ReactNode, useCallback, useContext, useMemo, useState } from 'react';

interface Aviso {
  id: number;
  texto: string;
  tipo: 'ok' | 'erro';
}
interface ToastCtx {
  ok: (texto: string) => void;
  erro: (texto: string) => void;
}
const Ctx = createContext<ToastCtx | null>(null);
let seq = 0;

export function ToastProvider({ children }: { children: ReactNode }) {
  const [avisos, setAvisos] = useState<Aviso[]>([]);

  const mostrar = useCallback((texto: string, tipo: Aviso['tipo']) => {
    const id = ++seq;
    setAvisos((a) => [...a, { id, texto, tipo }]);
    setTimeout(() => setAvisos((a) => a.filter((x) => x.id !== id)), tipo === 'erro' ? 7000 : 3500);
  }, []);

  const valor = useMemo(() => ({ ok: (t: string) => mostrar(t, 'ok'), erro: (t: string) => mostrar(t, 'erro') }), [mostrar]);

  return (
    <Ctx.Provider value={valor}>
      {children}
      <div className="no-print fixed inset-x-0 bottom-4 z-[60] flex flex-col items-center gap-2 px-4" aria-live="polite">
        {avisos.map((a) => (
          <div
            key={a.id}
            role={a.tipo === 'erro' ? 'alert' : 'status'}
            className={`max-w-md rounded-md px-4 py-3 text-sm font-medium shadow-lg ${
              a.tipo === 'erro' ? 'bg-negativo text-white' : 'bg-tinta text-white'
            }`}
          >
            {a.texto}
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}

export function useToast() {
  const c = useContext(Ctx);
  if (!c) throw new Error('useToast precisa estar dentro de <ToastProvider>');
  return c;
}
