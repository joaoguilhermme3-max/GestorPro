import { createContext, ReactNode, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { api, definirAoExpirar, tokenStore } from '../services/api';
import type { Usuario } from '../types';

interface AuthCtx {
  usuario: Usuario | null;
  carregando: boolean;
  ehAdmin: boolean;
  entrar: (email: string, senha: string) => Promise<void>;
  sair: () => void;
}

const Ctx = createContext<AuthCtx | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [usuario, setUsuario] = useState<Usuario | null>(null);
  const [carregando, setCarregando] = useState(!!tokenStore.get());

  const sair = useCallback(() => {
    tokenStore.clear();
    setUsuario(null);
  }, []);

  useEffect(() => {
    definirAoExpirar(sair);
    if (!tokenStore.get()) return;
    api
      .get<{ usuario: Usuario }>('/me')
      .then((r) => setUsuario(r.usuario))
      .catch(() => tokenStore.clear())
      .finally(() => setCarregando(false));
  }, [sair]);

  const entrar = useCallback(async (email: string, senha: string) => {
    const r = await api.post<{ token: string; usuario: Usuario }>('/login', { email, senha });
    tokenStore.set(r.token);
    setUsuario(r.usuario);
  }, []);

  const valor = useMemo(
    () => ({ usuario, carregando, ehAdmin: usuario?.perfil === 'admin', entrar, sair }),
    [usuario, carregando, entrar, sair],
  );
  return <Ctx.Provider value={valor}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const c = useContext(Ctx);
  if (!c) throw new Error('useAuth precisa estar dentro de <AuthProvider>');
  return c;
}
