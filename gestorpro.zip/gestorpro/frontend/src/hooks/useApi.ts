import { DependencyList, useCallback, useEffect, useRef, useState } from 'react';
import { ApiError } from '../services/api';

/** Busca dados ao montar e sempre que as dependências mudam. Ignora respostas velhas. */
export function useApi<T>(buscar: () => Promise<T>, deps: DependencyList) {
  const [dados, setDados] = useState<T | null>(null);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState<string | null>(null);
  const contador = useRef(0);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const executar = useCallback(buscar, deps);

  const recarregar = useCallback(() => {
    const id = ++contador.current;
    setCarregando(true);
    executar()
      .then((d) => {
        if (id !== contador.current) return;
        setDados(d);
        setErro(null);
      })
      .catch((e) => {
        if (id !== contador.current) return;
        setErro(e instanceof ApiError ? e.message : 'Erro inesperado.');
      })
      .finally(() => {
        if (id === contador.current) setCarregando(false);
      });
  }, [executar]);

  useEffect(() => {
    recarregar();
    return () => {
      contador.current++;
    };
  }, [recarregar]);

  return { dados, carregando, erro, recarregar };
}
