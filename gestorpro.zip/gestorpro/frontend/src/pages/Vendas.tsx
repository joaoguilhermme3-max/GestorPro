import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Cupom } from '../components/Cupom';
import { Icone } from '../components/Icone';
import { Confirmar, Modal } from '../components/Modal';
import { Campo, Carregando, ErroBloco, Etiqueta, PageHeader, Paginacao, Vazio } from '../components/ui';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { useApi } from '../hooks/useApi';
import { api } from '../services/api';
import type { VendaDetalhe, VendaResumo } from '../types';
import { mensagemDe } from '../utils/erros';
import { dataHora, FORMAS_PAGAMENTO, inteiro, moeda } from '../utils/format';

const POR_PAGINA = 15;
type Resposta = { itens: VendaResumo[]; total: number; page: number; limit: number; soma_concluidas: number };

export default function Vendas() {
  const [inicio, setInicio] = useState('');
  const [fim, setFim] = useState('');
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const [aberta, setAberta] = useState<number | null>(null);

  useEffect(() => setPage(1), [inicio, fim, status]);

  const lista = useApi(() => api.get<Resposta>('/vendas', { inicio, fim, status, page, limit: POR_PAGINA }), [inicio, fim, status, page]);

  return (
    <div>
      <PageHeader
        titulo="Vendas"
        subtitulo="Histórico de vendas. Clique em uma venda para ver os itens."
        acoes={<Link to="/vendas/nova" className="btn-action">Nova venda</Link>}
      />

      <div className="mb-4 grid gap-3 sm:grid-cols-3">
        <Campo rotulo="De">
          <input className="input" type="date" value={inicio} max={fim || undefined} onChange={(e) => setInicio(e.target.value)} />
        </Campo>
        <Campo rotulo="Até">
          <input className="input" type="date" value={fim} min={inicio || undefined} onChange={(e) => setFim(e.target.value)} />
        </Campo>
        <Campo rotulo="Situação">
          <select className="input" value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">Todas</option>
            <option value="concluida">Concluídas</option>
            <option value="cancelada">Canceladas</option>
          </select>
        </Campo>
      </div>

      {lista.dados && (
        <p className="mb-2 text-sm text-mudo">
          {inteiro(lista.dados.total)} {lista.dados.total === 1 ? 'venda' : 'vendas'} · <b className="text-tinta">{moeda(lista.dados.soma_concluidas)}</b> em vendas concluídas
        </p>
      )}
      {lista.erro && <ErroBloco texto={lista.erro} aoTentar={lista.recarregar} />}

      <div className="folha overflow-x-auto">
        <table className="ledger">
          <thead>
            <tr>
              <th>Nº</th>
              <th>Data</th>
              <th>Cliente</th>
              <th>Vendedor</th>
              <th>Pagamento</th>
              <th className="num">Itens</th>
              <th className="num">Total</th>
              <th>Situação</th>
            </tr>
          </thead>
          <tbody>
            {lista.carregando && !lista.dados && <tr><td colSpan={8}><Carregando /></td></tr>}
            {lista.dados?.itens.map((v) => (
              <tr key={v.id} onClick={() => setAberta(v.id)} className="cursor-pointer">
                <td className="font-semibold">
                  <button className="btn-link" onClick={() => setAberta(v.id)}>#{v.id}</button>
                </td>
                <td className="whitespace-nowrap">{dataHora(v.data_venda)}</td>
                <td>{v.cliente ?? <span className="text-mudo">Consumidor final</span>}</td>
                <td>{v.vendedor}</td>
                <td>{FORMAS_PAGAMENTO[v.forma_pagamento]}</td>
                <td className="num">{inteiro(v.qtd_itens)}</td>
                <td className={`num whitespace-nowrap font-semibold ${v.status === 'cancelada' ? 'text-mudo line-through' : ''}`}>{moeda(v.valor_total)}</td>
                <td>{v.status === 'cancelada' ? <Etiqueta tom="ruim">Cancelada</Etiqueta> : <Etiqueta tom="bom">Concluída</Etiqueta>}</td>
              </tr>
            ))}
            {lista.dados && lista.dados.itens.length === 0 && (
              <tr>
                <td colSpan={8}>
                  <Vazio titulo="Nenhuma venda encontrada" texto="Ajuste o período ou registre uma nova venda." />
                </td>
              </tr>
            )}
          </tbody>
        </table>
        {lista.dados && <Paginacao page={page} limit={POR_PAGINA} total={lista.dados.total} aoMudar={setPage} />}
      </div>

      <DetalheVenda id={aberta} aoFechar={() => setAberta(null)} aoAlterar={lista.recarregar} />
    </div>
  );
}

function DetalheVenda({ id, aoFechar, aoAlterar }: { id: number | null; aoFechar: () => void; aoAlterar: () => void }) {
  const { ehAdmin } = useAuth();
  const toast = useToast();
  const [venda, setVenda] = useState<VendaDetalhe | null>(null);
  const [erro, setErro] = useState('');
  const [confirmando, setConfirmando] = useState(false);
  const [cancelando, setCancelando] = useState(false);

  useEffect(() => {
    setVenda(null);
    setErro('');
    if (id === null) return;
    api.get<VendaDetalhe>(`/vendas/${id}`).then(setVenda).catch((e) => setErro(mensagemDe(e)));
  }, [id]);

  async function cancelar() {
    if (!venda) return;
    setCancelando(true);
    try {
      setVenda(await api.post<VendaDetalhe>(`/vendas/${venda.id}/cancelar`));
      toast.ok(`Venda #${venda.id} cancelada. Os itens voltaram ao estoque.`);
      setConfirmando(false);
      aoAlterar();
    } catch (e) {
      toast.erro(mensagemDe(e));
    } finally {
      setCancelando(false);
    }
  }

  return (
    <Modal aberto={id !== null} aoFechar={aoFechar} titulo={id ? `Venda #${id}` : 'Venda'} largura="sm">
      {erro && <ErroBloco texto={erro} />}
      {!venda && !erro && <Carregando />}
      {venda && (
        <div>
          {venda.status === 'cancelada' && (
            <p className="mb-3 rounded bg-negativo-suave px-3 py-2 text-sm font-semibold text-negativo">Venda cancelada. Estoque devolvido e valor estornado.</p>
          )}
          <Cupom
            titulo={`Vendedor: ${venda.vendedor}`}
            data={venda.data_venda}
            linhas={venda.itens.map((i) => ({ chave: i.id, quantidade: i.quantidade, nome: i.produto, subtotal: i.subtotal }))}
            subtotal={venda.subtotal}
            desconto={venda.desconto}
            total={venda.valor_total}
            formaPagamento={venda.forma_pagamento}
            cliente={venda.cliente}
          />
          <div className="no-print mt-8 flex flex-wrap justify-end gap-2">
            <button className="btn-quiet" onClick={() => window.print()}>
              <Icone nome="imprimir" className="h-4 w-4" /> Imprimir
            </button>
            {ehAdmin && venda.status === 'concluida' && (
              <button className="btn-danger" onClick={() => setConfirmando(true)}>Cancelar venda</button>
            )}
          </div>
        </div>
      )}
      <Confirmar
        aberto={confirmando}
        titulo="Cancelar esta venda?"
        texto="Os produtos voltam ao estoque e o valor é estornado no financeiro. Essa ação não pode ser desfeita."
        rotuloConfirmar="Cancelar venda"
        carregando={cancelando}
        aoConfirmar={cancelar}
        aoCancelar={() => setConfirmando(false)}
      />
    </Modal>
  );
}
