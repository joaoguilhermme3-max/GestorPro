import { FormEvent, useEffect, useState } from 'react';
import { Combobox } from '../components/Combobox';
import { Modal } from '../components/Modal';
import { Campo, Carregando, ErroBloco, Etiqueta, Indicadores, PageHeader, Paginacao, Vazio } from '../components/ui';
import { useToast } from '../contexts/ToastContext';
import { useApi } from '../hooks/useApi';
import { api } from '../services/api';
import type { Movimentacao, Pagina, Produto } from '../types';
import { mensagemDe } from '../utils/erros';
import { dataHora, inteiro, moeda, numero } from '../utils/format';

const POR_PAGINA = 20;
const ROTULOS_TIPO: Record<string, string> = { entrada: 'Entrada', venda: 'Venda', ajuste: 'Ajuste', cancelamento: 'Cancelamento' };

interface Resumo {
  produtos: number;
  unidades: number;
  valor_custo: number;
  valor_venda: number;
  zerados: number;
  baixos: number;
}

export default function Estoque() {
  const toast = useToast();
  const [page, setPage] = useState(1);
  const [tipo, setTipo] = useState('');
  const [registrando, setRegistrando] = useState(false);

  const resumo = useApi(() => api.get<Resumo>('/estoque/resumo'), []);
  const movs = useApi(() => api.get<Pagina<Movimentacao>>('/estoque/movimentacoes', { tipo, page, limit: POR_PAGINA }), [tipo, page]);
  const alertas = useApi(() => api.get<{ itens: Produto[] }>('/estoque/alertas'), []);

  function aoRegistrar() {
    setRegistrando(false);
    resumo.recarregar();
    movs.recarregar();
    alertas.recarregar();
    toast.ok('Movimentação registrada.');
  }

  return (
    <div>
      <PageHeader titulo="Estoque" subtitulo="Registre entradas de mercadoria e ajustes de contagem." acoes={<button className="btn-action" onClick={() => setRegistrando(true)}>Registrar movimentação</button>} />

      {resumo.dados && (
        <div className="mb-8">
          <Indicadores
            itens={[
              { rotulo: 'Produtos ativos', valor: inteiro(resumo.dados.produtos) },
              { rotulo: 'Unidades em estoque', valor: inteiro(resumo.dados.unidades) },
              { rotulo: 'Valor investido (custo)', valor: moeda(resumo.dados.valor_custo) },
              { rotulo: 'Valor de venda', valor: moeda(resumo.dados.valor_venda) },
              { rotulo: 'Abaixo do mínimo', valor: inteiro(resumo.dados.baixos), tom: resumo.dados.baixos > 0 ? 'ruim' : undefined },
            ]}
          />
        </div>
      )}

      {alertas.dados && alertas.dados.itens.length > 0 && (
        <section className="mb-8">
          <h2 className="mb-3 text-lg font-bold">Precisa repor</h2>
          <ul className="folha divide-y divide-linha">
            {alertas.dados.itens.map((p) => (
              <li key={p.id} className="flex items-center justify-between gap-3 px-4 py-3">
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold">{p.nome}</p>
                  <p className="text-xs text-mudo">{p.codigo} · mínimo {p.estoque_minimo}</p>
                </div>
                <span className="marca-texto shrink-0 text-sm font-extrabold">{p.estoque === 0 ? 'Zerado' : `${p.estoque} un.`}</span>
              </li>
            ))}
          </ul>
        </section>
      )}

      <section>
        <div className="mb-3 flex flex-wrap items-end justify-between gap-3">
          <h2 className="text-lg font-bold">Histórico de movimentações</h2>
          <Campo rotulo="Tipo" className="w-44">
            <select className="input" value={tipo} onChange={(e) => { setTipo(e.target.value); setPage(1); }}>
              <option value="">Todos</option>
              <option value="entrada">Entradas</option>
              <option value="venda">Vendas</option>
              <option value="ajuste">Ajustes</option>
              <option value="cancelamento">Cancelamentos</option>
            </select>
          </Campo>
        </div>

        {movs.erro && <ErroBloco texto={movs.erro} aoTentar={movs.recarregar} />}

        <div className="folha overflow-x-auto">
          <table className="ledger">
            <thead>
              <tr>
                <th>Quando</th>
                <th>Produto</th>
                <th>Tipo</th>
                <th className="num">Quantidade</th>
                <th className="num">Saldo após</th>
                <th>Motivo / responsável</th>
              </tr>
            </thead>
            <tbody>
              {movs.carregando && !movs.dados && <tr><td colSpan={6}><Carregando /></td></tr>}
              {movs.dados?.itens.map((m) => (
                <tr key={m.id}>
                  <td className="whitespace-nowrap">{dataHora(m.criado_em)}</td>
                  <td><p className="font-semibold">{m.produto}</p><p className="text-xs text-mudo">{m.codigo}</p></td>
                  <td><Etiqueta tom={m.quantidade >= 0 ? 'bom' : 'ruim'}>{ROTULOS_TIPO[m.tipo]}</Etiqueta></td>
                  <td className={`num font-semibold ${m.quantidade >= 0 ? 'text-positivo' : 'text-negativo'}`}>{m.quantidade > 0 ? '+' : ''}{inteiro(m.quantidade)}</td>
                  <td className="num">{inteiro(m.saldo_apos)}</td>
                  <td className="text-mudo">{m.motivo ?? '—'}{m.usuario ? ` · ${m.usuario}` : ''}</td>
                </tr>
              ))}
              {movs.dados && movs.dados.itens.length === 0 && <tr><td colSpan={6}><Vazio titulo="Nenhuma movimentação encontrada" /></td></tr>}
            </tbody>
          </table>
          {movs.dados && <Paginacao page={page} limit={POR_PAGINA} total={movs.dados.total} aoMudar={setPage} />}
        </div>
      </section>

      <FormularioMovimentacao aberto={registrando} aoFechar={() => setRegistrando(false)} aoRegistrar={aoRegistrar} />
    </div>
  );
}

function FormularioMovimentacao({ aberto, aoFechar, aoRegistrar }: { aberto: boolean; aoFechar: () => void; aoRegistrar: () => void }) {
  const [produto, setProduto] = useState<Produto | null>(null);
  const [tipo, setTipo] = useState<'entrada' | 'ajuste'>('entrada');
  const [quantidade, setQuantidade] = useState('');
  const [valorCompra, setValorCompra] = useState('');
  const [motivo, setMotivo] = useState('');
  const [erro, setErro] = useState('');
  const [salvando, setSalvando] = useState(false);

  useEffect(() => {
    if (aberto) {
      setProduto(null);
      setTipo('entrada');
      setQuantidade('');
      setValorCompra('');
      setMotivo('');
      setErro('');
    }
  }, [aberto]);

  async function enviar(e: FormEvent) {
    e.preventDefault();
    if (!produto) return setErro('Escolha um produto.');
    const qtd = numero(quantidade);
    if (!qtd) return setErro('Informe uma quantidade.');
    setSalvando(true);
    setErro('');
    try {
      await api.post('/estoque/movimentacoes', {
        produto_id: produto.id,
        tipo,
        quantidade: tipo === 'ajuste' ? qtd : Math.abs(qtd),
        motivo: motivo || undefined,
        valor_compra: tipo === 'entrada' ? numero(valorCompra) : undefined,
      });
      aoRegistrar();
    } catch (err) {
      setErro(mensagemDe(err));
    } finally {
      setSalvando(false);
    }
  }

  return (
    <Modal aberto={aberto} aoFechar={aoFechar} titulo="Registrar movimentação" largura="sm">
      <form onSubmit={enviar} className="space-y-4">
        <div>
          <span className="label">Produto</span>
          {produto ? (
            <div className="folha flex items-center justify-between px-3 py-2">
              <span className="text-sm"><b>{produto.nome}</b> <span className="text-mudo">· estoque atual: {produto.estoque}</span></span>
              <button type="button" className="btn-link" onClick={() => setProduto(null)}>Trocar</button>
            </div>
          ) : (
            <Combobox<Produto>
              autoFocus
              rotuloAria="Buscar produto"
              placeholder="Buscar produto"
              buscar={(q) => api.get<Pagina<Produto>>('/produtos', { q, limit: 8 }).then((r) => r.itens)}
              aoEscolher={setProduto}
              chave={(p) => p.id}
              renderizar={(p) => (
                <span><b>{p.nome}</b> <span className="text-mudo">· {p.codigo} · estoque: {p.estoque}</span></span>
              )}
            />
          )}
        </div>

        <fieldset>
          <legend className="label">Tipo</legend>
          <div className="grid grid-cols-2 gap-2">
            <label className={`flex min-h-10 cursor-pointer items-center justify-center rounded-md border text-sm font-semibold ${tipo === 'entrada' ? 'border-tinta bg-tinta text-white' : 'border-linha-forte bg-white'}`}>
              <input type="radio" className="sr-only" checked={tipo === 'entrada'} onChange={() => setTipo('entrada')} /> Entrada de mercadoria
            </label>
            <label className={`flex min-h-10 cursor-pointer items-center justify-center rounded-md border text-sm font-semibold ${tipo === 'ajuste' ? 'border-tinta bg-tinta text-white' : 'border-linha-forte bg-white'}`}>
              <input type="radio" className="sr-only" checked={tipo === 'ajuste'} onChange={() => setTipo('ajuste')} /> Ajuste de contagem
            </label>
          </div>
        </fieldset>

        <Campo rotulo="Quantidade" dica={tipo === 'ajuste' ? 'Use negativo para tirar do estoque (ex.: -3)' : undefined}>
          <input className="input" type="number" step="1" required value={quantidade} onChange={(e) => setQuantidade(e.target.value)} />
        </Campo>

        {tipo === 'entrada' && (
          <Campo rotulo="Valor pago na compra (opcional)" dica="Lança automaticamente uma despesa no financeiro">
            <input className="input" type="number" step="0.01" min="0" value={valorCompra} onChange={(e) => setValorCompra(e.target.value)} />
          </Campo>
        )}
        <Campo rotulo={tipo === 'ajuste' ? 'Motivo do ajuste' : 'Motivo (opcional)'}>
          <input className="input" required={tipo === 'ajuste'} value={motivo} onChange={(e) => setMotivo(e.target.value)} placeholder={tipo === 'ajuste' ? 'Ex.: contagem física, avaria' : 'Ex.: reposição do fornecedor'} />
        </Campo>

        {erro && <p className="field-error" role="alert">{erro}</p>}
        <div className="flex justify-end gap-2">
          <button type="button" className="btn-quiet" onClick={aoFechar}>Cancelar</button>
          <button className="btn-action" disabled={salvando}>{salvando ? 'Salvando…' : 'Registrar'}</button>
        </div>
      </form>
    </Modal>
  );
}
