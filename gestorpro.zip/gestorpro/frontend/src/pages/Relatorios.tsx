import { useState } from 'react';
import { Icone } from '../components/Icone';
import { Campo, Carregando, ErroBloco, PageHeader, Vazio } from '../components/ui';
import { useApi } from '../hooks/useApi';
import { api } from '../services/api';
import type { Relatorio } from '../types';
import { hojeISO, inicioDoMesISO, inteiro, moeda } from '../utils/format';

interface ItemLista { id: string; titulo: string; descricao: string; usaPeriodo: boolean }

export default function Relatorios() {
  const [selecionado, setSelecionado] = useState<ItemLista | null>(null);
  const indice = useApi(() => api.get<{ itens: ItemLista[] }>('/relatorios'), []);

  return (
    <div>
      <PageHeader titulo="Relatórios" subtitulo="Escolha um relatório para ver na tela, baixar em Excel (CSV) ou imprimir." />

      {indice.carregando && <Carregando />}
      {indice.erro && <ErroBloco texto={indice.erro} aoTentar={indice.recarregar} />}

      {!selecionado && indice.dados && (
        <ul className="folha divide-y divide-linha">
          {indice.dados.itens.map((r) => (
            <li key={r.id}>
              <button className="flex w-full items-center justify-between gap-3 px-4 py-4 text-left hover:bg-papel-2" onClick={() => setSelecionado(r)}>
                <span>
                  <span className="block font-bold">{r.titulo}</span>
                  <span className="text-sm text-mudo">{r.descricao}</span>
                </span>
                <Icone nome="relatorios" className="h-5 w-5 shrink-0 text-mudo" />
              </button>
            </li>
          ))}
        </ul>
      )}

      {selecionado && (
        <div>
          <button className="btn-link mb-4" onClick={() => setSelecionado(null)}>← Voltar para a lista</button>
          <VisaoRelatorio item={selecionado} />
        </div>
      )}
    </div>
  );
}

function VisaoRelatorio({ item }: { item: ItemLista }) {
  const [inicio, setInicio] = useState(inicioDoMesISO());
  const [fim, setFim] = useState(hojeISO());
  const [baixando, setBaixando] = useState(false);
  const params = item.usaPeriodo ? { inicio, fim } : {};

  const rel = useApi(() => api.get<Relatorio>(`/relatorios/${item.id}`, params), [item.id, inicio, fim]);

  async function baixarCsv() {
    setBaixando(true);
    try {
      await api.baixar(`/relatorios/${item.id}`, { ...params, formato: 'csv' }, `gestorpro-${item.id}.csv`);
    } finally {
      setBaixando(false);
    }
  }

  const formatar = (v: string | number | null, tipo: string) => {
    if (v === null || v === undefined || v === '') return '—';
    if (tipo === 'moeda') return moeda(Number(v));
    if (tipo === 'inteiro') return inteiro(Number(v));
    return String(v);
  };

  return (
    <div>
      <div className="no-print mb-4 flex flex-wrap items-end justify-between gap-3">
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <h2 className="text-xl font-extrabold">{item.titulo}</h2>
            <p className="text-sm text-mudo">{item.descricao}</p>
          </div>
        </div>
        <div className="flex flex-wrap items-end gap-2">
          {item.usaPeriodo && (
            <>
              <Campo rotulo="De"><input className="input" type="date" value={inicio} max={fim} onChange={(e) => setInicio(e.target.value)} /></Campo>
              <Campo rotulo="Até"><input className="input" type="date" value={fim} min={inicio} onChange={(e) => setFim(e.target.value)} /></Campo>
            </>
          )}
          <button className="btn-quiet" onClick={baixarCsv} disabled={baixando}>
            <Icone nome="baixar" className="h-4 w-4" /> {baixando ? 'Gerando…' : 'Baixar Excel (CSV)'}
          </button>
          <button className="btn-quiet" onClick={() => window.print()}>
            <Icone nome="imprimir" className="h-4 w-4" /> Imprimir
          </button>
        </div>
      </div>

      {rel.erro && <ErroBloco texto={rel.erro} aoTentar={rel.recarregar} />}
      {rel.carregando && !rel.dados && <Carregando />}

      {rel.dados && (
        <div className="print-area">
          <div className="mb-2 hidden print:block">
            <h2 className="text-xl font-extrabold">GestorPro · {rel.dados.titulo}</h2>
            {rel.dados.periodo && <p className="text-sm text-mudo">Período: {rel.dados.periodo.inicio.split('-').reverse().join('/')} a {rel.dados.periodo.fim.split('-').reverse().join('/')}</p>}
          </div>
          <div className="folha overflow-x-auto">
            <table className="ledger">
              <thead>
                <tr>{rel.dados.colunas.map((c) => <th key={c.chave} className={c.tipo !== 'texto' ? 'num' : ''}>{c.rotulo}</th>)}</tr>
              </thead>
              <tbody>
                {rel.dados.linhas.length === 0 && (
                  <tr><td colSpan={rel.dados.colunas.length}><Vazio titulo="Nada para mostrar" texto="Não há dados para os filtros escolhidos." /></td></tr>
                )}
                {rel.dados.linhas.map((linha, i) => (
                  <tr key={i}>
                    {rel.dados!.colunas.map((c) => (
                      <td key={c.chave} className={c.tipo !== 'texto' ? 'num whitespace-nowrap' : ''}>{formatar(linha[c.chave], c.tipo)}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
              {rel.dados.linhas.length > 0 && Object.keys(rel.dados.totais).length > 0 && (
                <tfoot>
                  <tr>
                    {rel.dados.colunas.map((c, i) => (
                      <td key={c.chave} className={c.tipo !== 'texto' ? 'num' : ''}>
                        {i === 0 && !(c.chave in rel.dados!.totais) ? 'Total' : c.chave in rel.dados!.totais ? formatar(rel.dados!.totais[c.chave], c.tipo) : ''}
                      </td>
                    ))}
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
