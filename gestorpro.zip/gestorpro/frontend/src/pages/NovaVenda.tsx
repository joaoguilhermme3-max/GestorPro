import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Combobox } from '../components/Combobox';
import { Cupom } from '../components/Cupom';
import { Icone } from '../components/Icone';
import { Etiqueta, PageHeader } from '../components/ui';
import { useToast } from '../contexts/ToastContext';
import { api } from '../services/api';
import type { Cliente, FormaPagamento, Pagina, Produto, VendaDetalhe } from '../types';
import { mensagemDe } from '../utils/erros';
import { FORMAS_PAGAMENTO, moeda, numero } from '../utils/format';

interface ItemCarrinho {
  produto: Produto;
  quantidade: number;
}

const FORMAS: FormaPagamento[] = ['pix', 'dinheiro', 'debito', 'credito'];
const arredondar = (v: number) => Math.round(v * 100) / 100;

export default function NovaVenda() {
  const toast = useToast();
  const [itens, setItens] = useState<ItemCarrinho[]>([]);
  const [cliente, setCliente] = useState<Cliente | null>(null);
  const [forma, setForma] = useState<FormaPagamento>('pix');
  const [descontoTexto, setDescontoTexto] = useState('');
  const [enviando, setEnviando] = useState(false);
  const [erro, setErro] = useState('');
  const [concluida, setConcluida] = useState<VendaDetalhe | null>(null);

  const subtotal = useMemo(() => arredondar(itens.reduce((s, i) => s + i.produto.preco * i.quantidade, 0)), [itens]);
  const desconto = numero(descontoTexto) ?? 0;
  const total = arredondar(subtotal - desconto);
  const semEstoque = itens.filter((i) => i.quantidade > i.produto.estoque);
  const descontoInvalido = desconto < 0 || desconto > subtotal;
  const podeFinalizar = itens.length > 0 && semEstoque.length === 0 && !descontoInvalido && !enviando;

  function adicionar(p: Produto) {
    if (p.estoque <= 0) {
      toast.erro(`"${p.nome}" está sem estoque.`);
      return;
    }
    setErro('');
    setItens((atual) => {
      const existente = atual.find((i) => i.produto.id === p.id);
      if (existente) return atual.map((i) => (i.produto.id === p.id ? { ...i, quantidade: i.quantidade + 1 } : i));
      return [...atual, { produto: p, quantidade: 1 }];
    });
  }

  const mudarQuantidade = (id: number, q: number) =>
    setItens((atual) => atual.map((i) => (i.produto.id === id ? { ...i, quantidade: Math.min(Math.max(q || 1, 1), 99999) } : i)));
  const remover = (id: number) => setItens((atual) => atual.filter((i) => i.produto.id !== id));

  async function finalizar() {
    setEnviando(true);
    setErro('');
    try {
      const venda = await api.post<VendaDetalhe>('/vendas', {
        cliente_id: cliente?.id ?? null,
        forma_pagamento: forma,
        desconto,
        itens: itens.map((i) => ({ produto_id: i.produto.id, quantidade: i.quantidade })),
      });
      setConcluida(venda);
    } catch (e) {
      setErro(mensagemDe(e));
    } finally {
      setEnviando(false);
    }
  }

  function novaVenda() {
    setItens([]);
    setCliente(null);
    setForma('pix');
    setDescontoTexto('');
    setErro('');
    setConcluida(null);
  }

  if (concluida) {
    return (
      <div className="mx-auto max-w-sm">
        <div className="no-print mb-6 text-center">
          <h1 className="text-2xl font-extrabold">Venda #{concluida.id} registrada</h1>
          <p className="mt-1 text-sm text-mudo">O estoque foi atualizado e o valor entrou no financeiro.</p>
        </div>
        <Cupom
          titulo={`Venda #${concluida.id}`}
          data={concluida.data_venda}
          linhas={concluida.itens.map((i) => ({ chave: i.id, quantidade: i.quantidade, nome: i.produto, subtotal: i.subtotal }))}
          subtotal={concluida.subtotal}
          desconto={concluida.desconto}
          total={concluida.valor_total}
          formaPagamento={concluida.forma_pagamento}
          cliente={concluida.cliente}
        />
        <div className="no-print mt-10 flex flex-wrap justify-center gap-2">
          <button className="btn-action" onClick={novaVenda}>Nova venda</button>
          <button className="btn-quiet" onClick={() => window.print()}>
            <Icone nome="imprimir" className="h-4 w-4" /> Imprimir cupom
          </button>
          <Link to="/vendas" className="btn-quiet">Ver vendas</Link>
        </div>
      </div>
    );
  }

  return (
    <div>
      <PageHeader titulo="Nova venda" subtitulo="Busque o produto pelo nome ou código e aperte Enter para adicionar." />

      <div className="grid items-start gap-8 lg:grid-cols-[1fr_21rem]">
        <div className="min-w-0 space-y-6">
          <Combobox<Produto>
            autoFocus
            rotuloAria="Buscar produto"
            placeholder="Buscar produto por nome ou código"
            buscar={(q) => api.get<Pagina<Produto>>('/produtos', { q, limit: 8 }).then((r) => r.itens)}
            aoEscolher={adicionar}
            chave={(p) => p.id}
            renderizar={(p) => (
              <div className="flex items-center justify-between gap-3">
                <span className="min-w-0">
                  <span className="block truncate font-semibold">{p.nome}</span>
                  <span className="text-xs text-mudo">{p.codigo}</span>
                </span>
                <span className="shrink-0 text-right">
                  <span className="block font-semibold">{moeda(p.preco)}</span>
                  {p.estoque <= 0 ? <Etiqueta tom="ruim">Sem estoque</Etiqueta> : <span className="text-xs text-mudo">{p.estoque} em estoque</span>}
                </span>
              </div>
            )}
          />

          <div className="folha overflow-x-auto">
            <table className="ledger">
              <thead>
                <tr>
                  <th>Produto</th>
                  <th className="num">Preço</th>
                  <th className="text-center">Quantidade</th>
                  <th className="num">Subtotal</th>
                  <th className="w-px"><span className="sr-only">Remover</span></th>
                </tr>
              </thead>
              <tbody>
                {itens.length === 0 && (
                  <tr>
                    <td colSpan={5} className="py-10 text-center text-mudo">Nenhum produto na venda ainda.</td>
                  </tr>
                )}
                {itens.map(({ produto: p, quantidade }) => (
                  <tr key={p.id}>
                    <td>
                      <p className="font-semibold">{p.nome}</p>
                      {quantidade > p.estoque ? (
                        <p className="text-xs font-semibold text-negativo">Só há {p.estoque} em estoque</p>
                      ) : (
                        <p className="text-xs text-mudo">{p.codigo}</p>
                      )}
                    </td>
                    <td className="num whitespace-nowrap">{moeda(p.preco)}</td>
                    <td>
                      <div className="mx-auto flex w-32 items-center">
                        <button className="btn-quiet min-h-9 rounded-r-none px-2" onClick={() => mudarQuantidade(p.id, quantidade - 1)} aria-label={`Diminuir ${p.nome}`}>
                          <Icone nome="menos" className="h-4 w-4" />
                        </button>
                        <input
                          className="input min-h-9 rounded-none border-x-0 px-1 text-center"
                          type="number"
                          min={1}
                          value={quantidade}
                          aria-label={`Quantidade de ${p.nome}`}
                          onChange={(e) => mudarQuantidade(p.id, Number(e.target.value))}
                        />
                        <button className="btn-quiet min-h-9 rounded-l-none px-2" onClick={() => mudarQuantidade(p.id, quantidade + 1)} aria-label={`Aumentar ${p.nome}`}>
                          <Icone nome="mais" className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                    <td className="num whitespace-nowrap font-semibold">{moeda(p.preco * quantidade)}</td>
                    <td>
                      <button className="rounded p-1.5 text-mudo hover:bg-negativo-suave hover:text-negativo" onClick={() => remover(p.id)} aria-label={`Remover ${p.nome}`}>
                        <Icone nome="lixo" className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <section aria-labelledby="t-fechamento" className="space-y-5">
            <h2 id="t-fechamento" className="text-lg font-bold">Fechamento</h2>

            <div>
              <span className="label">Cliente (opcional)</span>
              {cliente ? (
                <div className="folha flex items-center justify-between gap-3 px-3 py-2">
                  <span className="text-sm">
                    <b>{cliente.nome}</b>
                    {cliente.telefone && <span className="text-mudo"> · {cliente.telefone}</span>}
                  </span>
                  <button className="btn-link" onClick={() => setCliente(null)}>Trocar</button>
                </div>
              ) : (
                <Combobox<Cliente>
                  rotuloAria="Buscar cliente"
                  placeholder="Buscar cliente por nome, CPF ou telefone"
                  buscar={(q) => api.get<Pagina<Cliente>>('/clientes', { q, limit: 8 }).then((r) => r.itens)}
                  aoEscolher={setCliente}
                  chave={(c) => c.id}
                  renderizar={(c) => (
                    <span>
                      <b>{c.nome}</b> <span className="text-mudo">{c.telefone ?? c.cpf ?? ''}</span>
                    </span>
                  )}
                />
              )}
              <p className="hint">Sem cliente, a venda é registrada como consumidor final.</p>
            </div>

            <fieldset>
              <legend className="label">Forma de pagamento</legend>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                {FORMAS.map((f) => (
                  <label
                    key={f}
                    className={`flex min-h-11 cursor-pointer items-center justify-center rounded-md border px-2 text-center text-sm font-semibold has-[:focus-visible]:outline-3 has-[:focus-visible]:outline-caneta ${
                      forma === f ? 'border-tinta bg-tinta text-white' : 'border-linha-forte bg-white hover:bg-papel-2'
                    }`}
                  >
                    <input type="radio" name="forma" className="sr-only" checked={forma === f} onChange={() => setForma(f)} />
                    {FORMAS_PAGAMENTO[f]}
                  </label>
                ))}
              </div>
            </fieldset>

            <label className="block max-w-xs">
              <span className="label">Desconto (R$)</span>
              <input className="input" type="number" min="0" step="0.01" placeholder="0,00" value={descontoTexto} onChange={(e) => setDescontoTexto(e.target.value)} />
              {descontoInvalido && <span className="field-error block">O desconto não pode passar do subtotal.</span>}
            </label>
          </section>
        </div>

        <aside className="lg:sticky lg:top-6">
          <Cupom
            titulo="Venda em andamento"
            linhas={itens.map((i) => ({ chave: i.produto.id, quantidade: i.quantidade, nome: i.produto.nome, subtotal: arredondar(i.produto.preco * i.quantidade) }))}
            subtotal={subtotal}
            desconto={descontoInvalido ? 0 : desconto}
            total={descontoInvalido ? subtotal : total}
            formaPagamento={forma}
            cliente={cliente?.nome}
            vazio="Os itens aparecem aqui."
            rodape={
              <div className="space-y-2">
                {erro && <p className="rounded bg-negativo-suave px-3 py-2 text-xs font-medium text-negativo" role="alert">{erro}</p>}
                {semEstoque.length > 0 && <p className="text-xs font-semibold text-negativo">Ajuste as quantidades acima do estoque para finalizar.</p>}
                <button className="btn-action w-full" disabled={!podeFinalizar} onClick={finalizar}>
                  {enviando ? 'Registrando…' : 'Finalizar venda'}
                </button>
              </div>
            }
          />
        </aside>
      </div>
    </div>
  );
}
