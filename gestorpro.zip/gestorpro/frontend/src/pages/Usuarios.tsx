import { FormEvent, useEffect, useState } from 'react';
import { Modal } from '../components/Modal';
import { Campo, Carregando, Etiqueta, PageHeader } from '../components/ui';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { useApi } from '../hooks/useApi';
import { api } from '../services/api';
import type { Perfil, Usuario } from '../types';
import { errosPorCampo, mensagemDe } from '../utils/erros';

export default function Usuarios() {
  const { usuario: eu } = useAuth();
  const toast = useToast();
  const [editando, setEditando] = useState<Usuario | 'novo' | null>(null);
  const lista = useApi(() => api.get<{ itens: Usuario[] }>('/usuarios'), []);

  async function alternarAtivo(u: Usuario) {
    try {
      await api.put(`/usuarios/${u.id}`, { ativo: !u.ativo });
      toast.ok(u.ativo ? `${u.nome} foi desativado.` : `${u.nome} foi reativado.`);
      lista.recarregar();
    } catch (e) {
      toast.erro(mensagemDe(e));
    }
  }

  return (
    <div>
      <PageHeader titulo="Usuários" subtitulo="Quem pode acessar o sistema e com qual perfil." acoes={<button className="btn-action" onClick={() => setEditando('novo')}>Novo usuário</button>} />

      {lista.carregando && !lista.dados && <Carregando />}
      {lista.dados && (
        <div className="folha overflow-x-auto">
          <table className="ledger">
            <thead>
              <tr><th>Nome</th><th>E-mail</th><th>Perfil</th><th>Situação</th><th className="w-px"><span className="sr-only">Ações</span></th></tr>
            </thead>
            <tbody>
              {lista.dados.itens.map((u) => (
                <tr key={u.id}>
                  <td className="font-semibold">{u.nome}{u.id === eu?.id && <span className="ml-2 text-xs font-normal text-mudo">(você)</span>}</td>
                  <td className="text-mudo">{u.email}</td>
                  <td>{u.perfil === 'admin' ? 'Administrador' : 'Funcionário'}</td>
                  <td>{u.ativo ? <Etiqueta tom="bom">Ativo</Etiqueta> : <Etiqueta tom="ruim">Inativo</Etiqueta>}</td>
                  <td className="whitespace-nowrap text-right">
                    <button className="btn-link" onClick={() => setEditando(u)}>Editar</button>
                    {u.id !== eu?.id && (
                      <button className={u.ativo ? 'btn-link-danger ml-2' : 'btn-link ml-2'} onClick={() => alternarAtivo(u)}>
                        {u.ativo ? 'Desativar' : 'Reativar'}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <FormularioUsuario usuario={editando} aoFechar={() => setEditando(null)} aoSalvar={() => { setEditando(null); lista.recarregar(); }} />
    </div>
  );
}

function FormularioUsuario({ usuario, aoFechar, aoSalvar }: { usuario: Usuario | 'novo' | null; aoFechar: () => void; aoSalvar: () => void }) {
  const toast = useToast();
  const novo = usuario === 'novo';
  const [f, setF] = useState({ nome: '', email: '', senha: '', perfil: 'funcionario' as Perfil });
  const [erros, setErros] = useState<Record<string, string>>({});
  const [erroGeral, setErroGeral] = useState('');
  const [salvando, setSalvando] = useState(false);

  useEffect(() => {
    if (!usuario) return;
    setErros({});
    setErroGeral('');
    if (usuario === 'novo') setF({ nome: '', email: '', senha: '', perfil: 'funcionario' });
    else setF({ nome: usuario.nome, email: usuario.email, senha: '', perfil: usuario.perfil });
  }, [usuario]);

  async function enviar(e: FormEvent) {
    e.preventDefault();
    setErros({});
    setErroGeral('');
    setSalvando(true);
    try {
      if (novo) {
        await api.post('/usuarios', f);
      } else {
        const corpo: Record<string, unknown> = { nome: f.nome, email: f.email, perfil: f.perfil };
        if (f.senha) corpo.senha = f.senha;
        await api.put(`/usuarios/${(usuario as Usuario).id}`, corpo);
      }
      toast.ok(novo ? 'Usuário criado.' : 'Usuário atualizado.');
      aoSalvar();
    } catch (err) {
      setErros(errosPorCampo(err));
      setErroGeral(mensagemDe(err));
    } finally {
      setSalvando(false);
    }
  }

  return (
    <Modal aberto={!!usuario} aoFechar={aoFechar} titulo={novo ? 'Novo usuário' : 'Editar usuário'} largura="sm">
      <form onSubmit={enviar} className="space-y-4">
        <Campo rotulo="Nome" erro={erros.nome}>
          <input className="input" required autoFocus value={f.nome} onChange={(e) => setF({ ...f, nome: e.target.value })} />
        </Campo>
        <Campo rotulo="E-mail" erro={erros.email}>
          <input className="input" type="email" required value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />
        </Campo>
        <Campo rotulo={novo ? 'Senha' : 'Nova senha (opcional)'} erro={erros.senha} dica="Mínimo de 6 caracteres">
          <input className="input" type="password" required={novo} minLength={6} value={f.senha} onChange={(e) => setF({ ...f, senha: e.target.value })} placeholder={novo ? '' : 'Deixe em branco para manter a atual'} />
        </Campo>
        <fieldset>
          <legend className="label">Perfil</legend>
          <div className="grid grid-cols-2 gap-2">
            <label className={`flex min-h-10 cursor-pointer items-center justify-center rounded-md border text-sm font-semibold ${f.perfil === 'funcionario' ? 'border-tinta bg-tinta text-white' : 'border-linha-forte bg-white'}`}>
              <input type="radio" className="sr-only" checked={f.perfil === 'funcionario'} onChange={() => setF({ ...f, perfil: 'funcionario' })} /> Funcionário
            </label>
            <label className={`flex min-h-10 cursor-pointer items-center justify-center rounded-md border text-sm font-semibold ${f.perfil === 'admin' ? 'border-tinta bg-tinta text-white' : 'border-linha-forte bg-white'}`}>
              <input type="radio" className="sr-only" checked={f.perfil === 'admin'} onChange={() => setF({ ...f, perfil: 'admin' })} /> Administrador
            </label>
          </div>
          <p className="hint">Administradores veem custos, estoque, financeiro, relatórios e cancelam vendas.</p>
        </fieldset>
        {erroGeral && <p className="field-error" role="alert">{erroGeral}</p>}
        <div className="flex justify-end gap-2">
          <button type="button" className="btn-quiet" onClick={aoFechar}>Cancelar</button>
          <button className="btn-action" disabled={salvando}>{salvando ? 'Salvando…' : 'Salvar usuário'}</button>
        </div>
      </form>
    </Modal>
  );
}
