import { FormEvent, useEffect, useState } from 'react';
import { Confirmar, Modal } from '../components/Modal';
import { Campo, Carregando, ErroBloco, PageHeader, Paginacao, Vazio } from '../components/ui';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { useApi } from '../hooks/useApi';
import { useDebounce } from '../hooks/useDebounce';
import { api } from '../services/api';
import type { Cliente, Pagina } from '../types';
import { errosPorCampo, mensagemDe } from '../utils/erros';
import { dataCurta, mascaraCpf, mascaraTelefone, moeda } from '../utils/format';

const POR_PAGINA = 15;

export default function Clientes() {
  const { ehAdmin } = useAuth();
  const toast = useToast();
  const [busca, setBusca] = useState('');
  const [page, setPage] = useState(1);
  const q = useDebounce(busca, 300);
  const [editando, setEditando] = useState<Cliente | 'novo' | null>(null);
  const [detalhe, setDetalhe] = useState<Cliente | null>(null);
  const [removendo, setRemovendo] = useState<Cliente | null>(null);
  const [removendoCarregando, setRemovendoCarregando] = useState(false);

  useEffect(() => setPage(1), [q]);
  const lista = useApi(() => api.get<Pagina<Cliente>>('/clientes', { q, page, limit: POR_PAGINA }), [q, page]);

  async function abrirDetalhe(c: Cliente) {
    setDetalhe(c);
    try {
      setDetalhe(await api.get<Cliente>(`/clientes/${c.id}`));
    } catch (e) {
      toast.erro(mensagemDe(e));
      setDetalhe(null);
    }
  }

  async function desativar() {
    if (!removendo) return;
    setRemovendoCarregando(true);
    try {
      await api.delete(`/clientes/${removendo.id}`);
      toast.ok(`"${removendo.nome}" foi removido.`);
      setRemovendo(null);
      lista.recarregar();
    } catch (e) {
      toast.erro(mensagemDe(e));
    } finally {
      setRemovendoCarregando(false);
    }
  }

  return (
    <div>
      <PageHeader titulo="Clientes" subtitulo="Cadastre para acompanhar o histórico e o total gasto de cada um." acoes={<button className="btn-action" onClick={() => setEditando('novo')}>Novo cliente</button>} />

      <Campo rotulo="Buscar" className="mb-4 max-w-sm">
        <input className="input" type="search" placeholder="Nome, CPF, telefone ou e-mail" value={busca} onChange={(e) => setBusca(e.target.value)} />
      </Campo>

      {lista.erro && <ErroBloco texto={lista.erro} aoTentar={lista.recarregar} />}

      <div className="folha overflow-x-auto">
        <table className="ledger">
          <thead>
            <tr>
              <th>Nome</th>
              <th>Contato</th>
              <th className="num">Compras</th>
              <th className="num">Total gasto</th>
              <th>Última compra</th>
              <th className="w-px"><span className="sr-only">Ações</span></th>
            </tr>
          </thead>
          <tbody>
            {lista.carregando && !lista.dados && <tr><td colSpan={6}><Carregando /></td></tr>}
            {lista.dados?.itens.map((c) => (
              <tr key={c.id} className="cursor-pointer" onClick={() => abrirDetalhe(c)}>
                <td className="font-semibold">{c.nome}</td>
                <td className="text-mudo">{c.telefone ?? c.email ?? '—'}</td>
                <td className="num">{c.compras}</td>
                <td className="num font-semibold">{moeda(c.total_gasto)}</td>
                <td>{dataCurta(c.ultima_compra)}</td>
                <td className="whitespace-nowrap text-right">
                  <button className="btn-link" onClick={(e) => { e.stopPropagation(); setEditando(c); }}>Editar</button>
                  {ehAdmin && <button className="btn-link-danger ml-2" onClick={(e) => { e.stopPropagation(); setRemovendo(c); }}>Remover</button>}
                </td>
              </tr>
            ))}
            {lista.dados && lista.dados.itens.length === 0 && (
              <tr><td colSpan={6}><Vazio titulo={q ? 'Nenhum cliente encontrado' : 'Nenhum cliente cadastrado'} acao={!q ? <button className="btn-action" onClick={() => setEditando('novo')}>Cadastrar cliente</button> : undefined} /></td></tr>
            )}
          </tbody>
        </table>
        {lista.dados && <Paginacao page={page} limit={POR_PAGINA} total={lista.dados.total} aoMudar={setPage} />}
      </div>

      <FormularioCliente cliente={editando} aoFechar={() => setEditando(null)} aoSalvar={() => { setEditando(null); lista.recarregar(); }} />
      <DetalheCliente cliente={detalhe} aoFechar={() => setDetalhe(null)} />
      <Confirmar
        aberto={!!removendo}
        titulo="Remover cliente"
        texto={<>O histórico de vendas de <b>{removendo?.nome}</b> é mantido, mas o cliente deixa de aparecer nas buscas.</>}
        rotuloConfirmar="Remover"
        carregando={removendoCarregando}
        aoConfirmar={desativar}
        aoCancelar={() => setRemovendo(null)}
      />
    </div>
  );
}

function DetalheCliente({ cliente, aoFechar }: { cliente: Cliente | null; aoFechar: () => void }) {
  return (
    <Modal aberto={!!cliente} aoFechar={aoFechar} titulo={cliente?.nome ?? ''} largura="sm">
      {cliente && (
        <div className="space-y-4">
          <dl className="grid grid-cols-2 gap-3 text-sm">
            <div><dt className="text-mudo">Telefone</dt><dd className="font-medium">{cliente.telefone ?? '—'}</dd></div>
            <div><dt className="text-mudo">E-mail</dt><dd className="font-medium">{cliente.email ?? '—'}</dd></div>
            <div><dt className="text-mudo">CPF</dt><dd className="font-medium">{cliente.cpf ?? '—'}</dd></div>
            <div><dt className="text-mudo">Total gasto</dt><dd className="font-medium">{moeda(cliente.total_gasto)}</dd></div>
          </dl>
          {cliente.endereco && <p className="text-sm"><span className="text-mudo">Endereço: </span>{cliente.endereco}</p>}
          <div>
            <h3 className="mb-2 text-sm font-bold">Últimas compras</h3>
            {!cliente.ultimas_vendas || cliente.ultimas_vendas.length === 0 ? (
              <p className="text-sm text-mudo">Ainda não fez nenhuma compra.</p>
            ) : (
              <ul className="divide-y divide-linha border-y border-linha text-sm">
                {cliente.ultimas_vendas.map((v) => (
                  <li key={v.id} className="flex justify-between py-2">
                    <span>{dataCurta(v.data_venda)} {v.status === 'cancelada' && <span className="text-mudo">(cancelada)</span>}</span>
                    <span className={`font-semibold ${v.status === 'cancelada' ? 'text-mudo line-through' : ''}`}>{moeda(v.valor_total)}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      )}
    </Modal>
  );
}

function FormularioCliente({ cliente, aoFechar, aoSalvar }: { cliente: Cliente | 'novo' | null; aoFechar: () => void; aoSalvar: () => void }) {
  const toast = useToast();
  const novo = cliente === 'novo';
  const [f, setF] = useState({ nome: '', cpf: '', telefone: '', email: '', endereco: '' });
  const [erros, setErros] = useState<Record<string, string>>({});
  const [erroGeral, setErroGeral] = useState('');
  const [salvando, setSalvando] = useState(false);

  useEffect(() => {
    if (!cliente) return;
    setErros({});
    setErroGeral('');
    if (cliente === 'novo') setF({ nome: '', cpf: '', telefone: '', email: '', endereco: '' });
    else setF({ nome: cliente.nome, cpf: cliente.cpf ?? '', telefone: cliente.telefone ?? '', email: cliente.email ?? '', endereco: cliente.endereco ?? '' });
  }, [cliente]);

  async function enviar(e: FormEvent) {
    e.preventDefault();
    setErros({});
    setErroGeral('');
    setSalvando(true);
    try {
      const corpo = { ...f, cpf: f.cpf || null, telefone: f.telefone || null, email: f.email || null, endereco: f.endereco || null };
      if (novo) await api.post('/clientes', corpo);
      else await api.put(`/clientes/${(cliente as Cliente).id}`, corpo);
      toast.ok(novo ? 'Cliente cadastrado.' : 'Cliente atualizado.');
      aoSalvar();
    } catch (err) {
      setErros(errosPorCampo(err));
      setErroGeral(mensagemDe(err));
    } finally {
      setSalvando(false);
    }
  }

  return (
    <Modal aberto={!!cliente} aoFechar={aoFechar} titulo={novo ? 'Novo cliente' : 'Editar cliente'} largura="sm">
      <form onSubmit={enviar} className="space-y-4">
        <Campo rotulo="Nome" erro={erros.nome}>
          <input className="input" required autoFocus value={f.nome} onChange={(e) => setF({ ...f, nome: e.target.value })} />
        </Campo>
        <Campo rotulo="CPF (opcional)" erro={erros.cpf}>
          <input className="input" inputMode="numeric" value={f.cpf} onChange={(e) => setF({ ...f, cpf: mascaraCpf(e.target.value) })} placeholder="000.000.000-00" />
        </Campo>
        <Campo rotulo="Telefone (opcional)" erro={erros.telefone}>
          <input className="input" inputMode="numeric" value={f.telefone} onChange={(e) => setF({ ...f, telefone: mascaraTelefone(e.target.value) })} placeholder="(00) 00000-0000" />
        </Campo>
        <Campo rotulo="E-mail (opcional)" erro={erros.email}>
          <input className="input" type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />
        </Campo>
        <Campo rotulo="Endereço (opcional)" erro={erros.endereco}>
          <textarea className="input" rows={2} value={f.endereco} onChange={(e) => setF({ ...f, endereco: e.target.value })} />
        </Campo>
        {erroGeral && <p className="field-error" role="alert">{erroGeral}</p>}
        <div className="flex justify-end gap-2">
          <button type="button" className="btn-quiet" onClick={aoFechar}>Cancelar</button>
          <button className="btn-action" disabled={salvando}>{salvando ? 'Salvando…' : 'Salvar cliente'}</button>
        </div>
      </form>
    </Modal>
  );
}
