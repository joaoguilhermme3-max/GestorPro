import { FormEvent, useEffect, useState } from 'react';
import { Modal } from '../components/Modal';
import { Campo, Carregando, ErroBloco, Etiqueta, Indicadores, PageHeader, Paginacao, Vazio } from '../components/ui';
import { useToast } from '../contexts/ToastContext';
import { useApi } from '../hooks/useApi';
import { api } from '../services/api';
import type { Conta, Pagina } from '../types';
import { mensagemDe } from '../utils/erros';
import { dataCurta, hojeISO, inicioDoMesISO, moeda, numero } from '../utils/format';

const POR_PAGINA = 20;

interface Resposta extends Pagina<Conta> {
  totais: { entradas: number; saidas: number; saldo: number };
  periodo: { inicio: string; fim: string };
}

export default function Financeiro() {
  const toast = useToast();
  const [inicio, setInicio] = useState(inicioDoMesISO());
  const [fim, setFim] = useState(hojeISO());
  const [tipo, setTipo] = useState('');
  const [q, setQ] = useState('');
  const [page, setPage] = useState(1);
  const [lancando, setLancando] = useState(false);
  const [removendo, setRemovendo] = useState<Conta | null>(null);

  useEffect(() => setPage(1), [inicio, fim, tipo, q]);
  const lista = useApi(() => api.get<Resposta>('/financeiro/contas', { inicio, fim, tipo, q, page, limit: POR_PAGINA }), [inicio, fim, tipo, q, page]);

  async function remover() {
    if (!removendo) return;
    try {
      await api.delete(`/financeiro/contas/${removendo.id}`);
      toast.ok('Lançamento removido.');
      setRemovendo(null);
      lista.recarregar();
    } catch (e) {
      toast.erro(mensagemDe(e));
    }
  }

  return (
    <div>
      <PageHeader titulo="Financeiro" subtitulo="Entradas e saídas da loja. As vendas entram aqui automaticamente." acoes={<button className="btn-action" onClick={() => setLancando(true)}>Novo lançamento</button>} />

      {lista.dados && (
        <div className="mb-6">
          <Indicadores
            itens={[
              { rotulo: 'Entradas no período', valor: moeda(lista.dados.totais.entradas) },
              { rotulo: 'Saídas no período', valor: moeda(lista.dados.totais.saidas) },
              { rotulo: 'Saldo', valor: moeda(lista.dados.totais.saldo), tom: lista.dados.totais.saldo >= 0 ? 'bom' : 'ruim' },
            ]}
          />
        </div>
      )}

      <div className="mb-4 grid gap-3 sm:grid-cols-[8rem_8rem_9rem_1fr]">
        <Campo rotulo="De"><input className="input" type="date" value={inicio} max={fim} onChange={(e) => setInicio(e.target.value)} /></Campo>
        <Campo rotulo="Até"><input className="input" type="date" value={fim} min={inicio} onChange={(e) => setFim(e.target.value)} /></Campo>
        <Campo rotulo="Tipo">
          <select className="input" value={tipo} onChange={(e) => setTipo(e.target.value)}>
            <option value="">Todos</option>
            <option value="entrada">Entradas</option>
            <option value="saida">Saídas</option>
          </select>
        </Campo>
        <Campo rotulo="Buscar"><input className="input" type="search" placeholder="Descrição ou categoria" value={q} onChange={(e) => setQ(e.target.value)} /></Campo>
      </div>

      {lista.erro && <ErroBloco texto={lista.erro} aoTentar={lista.recarregar} />}

      <div className="folha overflow-x-auto">
        <table className="ledger">
          <thead>
            <tr>
              <th>Data</th>
              <th>Categoria</th>
              <th>Descrição</th>
              <th className="num">Entrada</th>
              <th className="num">Saída</th>
              <th className="w-px"><span className="sr-only">Ações</span></th>
            </tr>
          </thead>
          <tbody>
            {lista.carregando && !lista.dados && <tr><td colSpan={6}><Carregando /></td></tr>}
            {lista.dados?.itens.map((c) => (
              <tr key={c.id}>
                <td className="whitespace-nowrap">{dataCurta(c.data)}</td>
                <td><Etiqueta>{c.categoria}</Etiqueta></td>
                <td>{c.descricao}</td>
                <td className="num font-semibold text-positivo">{c.tipo === 'entrada' ? moeda(c.valor) : ''}</td>
                <td className="num font-semibold text-negativo">{c.tipo === 'saida' ? moeda(c.valor) : ''}</td>
                <td className="whitespace-nowrap text-right">
                  {c.venda_id ? <span className="text-xs text-mudo">Venda #{c.venda_id}</span> : <button className="btn-link-danger" onClick={() => setRemovendo(c)}>Remover</button>}
                </td>
              </tr>
            ))}
            {lista.dados && lista.dados.itens.length === 0 && <tr><td colSpan={6}><Vazio titulo="Nenhum lançamento no período" /></td></tr>}
          </tbody>
          {lista.dados && lista.dados.itens.length > 0 && (
            <tfoot>
              <tr>
                <td colSpan={3}>Total do período</td>
                <td className="num text-positivo">{moeda(lista.dados.totais.entradas)}</td>
                <td className="num text-negativo">{moeda(lista.dados.totais.saidas)}</td>
                <td />
              </tr>
            </tfoot>
          )}
        </table>
        {lista.dados && <Paginacao page={page} limit={POR_PAGINA} total={lista.dados.total} aoMudar={setPage} />}
      </div>

      <FormularioLancamento aberto={lancando} aoFechar={() => setLancando(false)} aoSalvar={() => { setLancando(false); lista.recarregar(); }} />

      <Modal aberto={!!removendo} aoFechar={() => setRemovendo(null)} titulo="Remover lançamento" largura="sm">
        <p className="text-sm text-tinta-2">Remover "{removendo?.descricao}" no valor de {moeda(removendo?.valor)}?</p>
        <div className="mt-5 flex justify-end gap-2">
          <button className="btn-quiet" onClick={() => setRemovendo(null)}>Voltar</button>
          <button className="btn-danger" onClick={remover}>Remover</button>
        </div>
      </Modal>
    </div>
  );
}

function FormularioLancamento({ aberto, aoFechar, aoSalvar }: { aberto: boolean; aoFechar: () => void; aoSalvar: () => void }) {
  const toast = useToast();
  const categorias = useApi(() => api.get<{ entrada: string[]; saida: string[] }>('/financeiro/categorias'), []);
  const [tipo, setTipo] = useState<'entrada' | 'saida'>('saida');
  const [categoria, setCategoria] = useState('');
  const [descricao, setDescricao] = useState('');
  const [valor, setValor] = useState('');
  const [data, setData] = useState(hojeISO());
  const [erro, setErro] = useState('');
  const [salvando, setSalvando] = useState(false);

  const opcoes = tipo === 'entrada' ? categorias.dados?.entrada : categorias.dados?.saida;

  useEffect(() => {
    if (aberto) {
      setTipo('saida');
      setDescricao('');
      setValor('');
      setData(hojeISO());
      setErro('');
    }
  }, [aberto]);
  useEffect(() => setCategoria(opcoes?.[0] ?? ''), [tipo, categorias.dados]); // eslint-disable-line react-hooks/exhaustive-deps

  async function enviar(e: FormEvent) {
    e.preventDefault();
    const v = numero(valor);
    if (!v || v <= 0) return setErro('Informe um valor maior que zero.');
    if (!categoria) return setErro('Escolha uma categoria.');
    setSalvando(true);
    setErro('');
    try {
      await api.post('/financeiro/contas', { tipo, categoria, descricao, valor: v, data });
      toast.ok('Lançamento registrado.');
      aoSalvar();
    } catch (err) {
      setErro(mensagemDe(err));
    } finally {
      setSalvando(false);
    }
  }

  return (
    <Modal aberto={aberto} aoFechar={aoFechar} titulo="Novo lançamento" largura="sm">
      <form onSubmit={enviar} className="space-y-4">
        <fieldset>
          <legend className="label">Tipo</legend>
          <div className="grid grid-cols-2 gap-2">
            <label className={`flex min-h-10 cursor-pointer items-center justify-center rounded-md border text-sm font-semibold ${tipo === 'entrada' ? 'border-positivo bg-positivo text-white' : 'border-linha-forte bg-white'}`}>
              <input type="radio" className="sr-only" checked={tipo === 'entrada'} onChange={() => setTipo('entrada')} /> Entrada
            </label>
            <label className={`flex min-h-10 cursor-pointer items-center justify-center rounded-md border text-sm font-semibold ${tipo === 'saida' ? 'border-negativo bg-negativo text-white' : 'border-linha-forte bg-white'}`}>
              <input type="radio" className="sr-only" checked={tipo === 'saida'} onChange={() => setTipo('saida')} /> Saída
            </label>
          </div>
        </fieldset>
        <Campo rotulo="Categoria">
          <select className="input" required value={categoria} onChange={(e) => setCategoria(e.target.value)}>
            {(opcoes ?? []).map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </Campo>
        <Campo rotulo="Descrição">
          <input className="input" required autoFocus value={descricao} onChange={(e) => setDescricao(e.target.value)} />
        </Campo>
        <div className="grid grid-cols-2 gap-3">
          <Campo rotulo="Valor (R$)"><input className="input" type="number" step="0.01" min="0.01" required value={valor} onChange={(e) => setValor(e.target.value)} /></Campo>
          <Campo rotulo="Data"><input className="input" type="date" required max={hojeISO()} value={data} onChange={(e) => setData(e.target.value)} /></Campo>
        </div>
        {erro && <p className="field-error" role="alert">{erro}</p>}
        <div className="flex justify-end gap-2">
          <button type="button" className="btn-quiet" onClick={aoFechar}>Cancelar</button>
          <button className="btn-action" disabled={salvando}>{salvando ? 'Salvando…' : 'Registrar'}</button>
        </div>
      </form>
    </Modal>
  );
}
