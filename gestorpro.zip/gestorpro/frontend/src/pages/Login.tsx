import { FormEvent, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { Campo } from '../components/ui';
import { useAuth } from '../contexts/AuthContext';
import { ApiError } from '../services/api';

export default function Login() {
  const { usuario, entrar } = useAuth();
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [erro, setErro] = useState('');
  const [enviando, setEnviando] = useState(false);

  if (usuario) return <Navigate to="/" replace />;

  async function enviar(e: FormEvent) {
    e.preventDefault();
    setErro('');
    setEnviando(true);
    try {
      await entrar(email.trim(), senha);
    } catch (err) {
      setErro(err instanceof ApiError ? err.message : 'Não foi possível entrar.');
    } finally {
      setEnviando(false);
    }
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-[minmax(22rem,2fr)_3fr]">
      <section className="flex flex-col justify-between bg-tinta px-8 py-10 text-white lg:px-12">
        <p className="text-2xl font-extrabold tracking-tight">GestorPro</p>
        <div className="my-14 max-w-sm">
          <h1 className="text-3xl font-extrabold leading-tight sm:text-4xl">
            O caixa, o estoque e as contas da sua loja em um só lugar.
          </h1>
          <p className="mt-4 text-white/70">
            Registre a venda e o estoque baixa sozinho. No fim do dia, o saldo já está no financeiro.
          </p>
        </div>
        <p className="text-sm text-white/50">Acesso restrito a usuários cadastrados.</p>
      </section>

      <section className="flex items-center justify-center px-6 py-12">
        <form onSubmit={enviar} className="w-full max-w-sm space-y-5" noValidate>
          <div>
            <h2 className="text-2xl font-extrabold">Entrar</h2>
            <p className="mt-1 text-sm text-mudo">Use o e-mail e a senha que o administrador cadastrou.</p>
          </div>
          <Campo rotulo="E-mail">
            <input className="input" type="email" autoComplete="username" autoFocus required value={email} onChange={(e) => setEmail(e.target.value)} />
          </Campo>
          <Campo rotulo="Senha">
            <input className="input" type="password" autoComplete="current-password" required value={senha} onChange={(e) => setSenha(e.target.value)} />
          </Campo>
          {erro && (
            <p className="rounded-md bg-negativo-suave px-3 py-2 text-sm font-medium text-negativo" role="alert">
              {erro}
            </p>
          )}
          <button className="btn-primary w-full" disabled={enviando}>
            {enviando ? 'Entrando…' : 'Entrar'}
          </button>
          {import.meta.env.DEV && (
            <p className="rounded-md border border-dashed border-linha-forte px-3 py-2 text-xs text-mudo">
              Ambiente de desenvolvimento — dados de demonstração: <b>admin@gestorpro.com</b> / <b>admin123</b> (administrador) ou{' '}
              <b>funcionario@gestorpro.com</b> / <b>func123</b>.
            </p>
          )}
        </form>
      </section>
    </div>
  );
}
