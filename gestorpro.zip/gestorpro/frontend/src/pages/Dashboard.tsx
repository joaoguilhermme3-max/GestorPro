import { Link } from 'react-router-dom';
import { Carregando, ErroBloco, Etiqueta, Indicadores } from '../components/ui';
import { useAuth } from '../contexts/AuthContext';
import { useApi } from '../hooks/useApi';
import { api } from '../services/api';
import type { Dashboard as Dados } from '../types';
import { dataHora, diaSemana, FORMAS_PAGAMENTO, inteiro, moeda } from '../utils/format';

const hojeExtenso = new Intl.DateTimeFormat('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });

function saudacao() {
  const h = new Date().getHours();
  return h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite';
}

export default function Dashboard() {
  const { usuario, ehAdmin } = useAuth();
  const { dados, carregando, erro, recarregar } = useApi(() => api.get<Dados>('/dashboard'), []);

  if (carregando && !dados) return <Carregando />;
  if (erro || !dados) return <ErroBloco texto={erro ?? 'Não foi possível carregar o painel.'} aoTentar={recarregar} />;

  const ticket = dados.vendas_mes.quantidade ? dados.vendas_mes.total / dados.vendas_mes.quantidade : 0;
  const maximo = Math.max(...dados.vendas_7_dias.map((d) => d.total), 1);
  const total7 = dados.vendas_7_dias.reduce((s, d) => s + d.total, 0);
  const linkAlertas = ehAdmin ? '/estoque' : '/produtos?baixo=true';

  return (
    <div className="space-y-8">
      <header>
        <p className="text-sm capitalize text-mudo">{hojeExtenso.format(new Date())}</p>
        <h1 className="text-2xl font-extrabold sm:text-3xl">
          {saudacao()}, {usuario?.nome.split(' ')[0]}.
        </h1>
        <p className="mt-3 text-lg sm:text-xl">
          {dados.vendas_hoje.quantidade === 0 ? (
            <>Ainda não houve vendas hoje.</>
          ) : (
            <>
              Hoje a loja vendeu <strong className="font-extrabold">{moeda(dados.vendas_hoje.total)}</strong> em{' '}
              {inteiro(dados.vendas_hoje.quantidade)} {dados.vendas_hoje.quantidade === 1 ? 'venda' : 'vendas'}.
            </>
          )}
        </p>
      </header>

      <Indicadores
        itens={[
          { rotulo: 'Vendido no mês', valor: moeda(dados.vendas_mes.total) },
          { rotulo: 'Ticket médio', valor: moeda(ticket) },
          { rotulo: 'Produtos ativos', valor: inteiro(dados.produtos) },
          { rotulo: 'Clientes', valor: inteiro(dados.clientes) },
          ...(dados.financeiro_mes
            ? [{ rotulo: 'Saldo do mês', valor: moeda(dados.financeiro_mes.saldo), tom: dados.financeiro_mes.saldo >= 0 ? ('bom' as const) : ('ruim' as const) }]
            : []),
        ]}
      />

      <div className="grid gap-8 lg:grid-cols-[3fr_2fr]">
        <section aria-labelledby="t-7dias">
          <div className="mb-3 flex items-baseline justify-between">
            <h2 id="t-7dias" className="text-lg font-bold">Vendas nos últimos 7 dias</h2>
            <span className="text-sm text-mudo">{moeda(total7)} no total</span>
          </div>
          <div
            className="folha flex h-64 items-end gap-2 px-3 pb-3 pt-8 sm:gap-4 sm:px-6"
            role="img"
            aria-label={`Vendas por dia: ${dados.vendas_7_dias.map((d) => `${diaSemana(d.data)} ${moeda(d.total)}`).join(', ')}`}
          >
            {dados.vendas_7_dias.map((d, i) => {
              const ehHoje = i === dados.vendas_7_dias.length - 1;
              const altura = d.total > 0 ? Math.max((d.total / maximo) * 100, 3) : 0;
              return (
                <div key={d.data} className="flex h-full min-w-0 flex-1 flex-col justify-end">
                  <span className="mb-1 truncate text-center text-[11px] font-semibold text-tinta-3">
                    {d.total > 0 ? Math.round(d.total).toLocaleString('pt-BR') : ''}
                  </span>
                  <div className="flex flex-1 items-end">
                    <div
                      className={`w-full rounded-t ${ehHoje ? 'bg-tinta' : 'bg-caneta/75'}`}
                      style={{ height: `${altura}%`, minHeight: d.total > 0 ? undefined : 2, background: d.total === 0 ? 'var(--color-linha)' : undefined }}
                      title={`${moeda(d.total)} · ${d.quantidade} vendas`}
                    />
                  </div>
                  <span className={`mt-2 text-center text-xs capitalize ${ehHoje ? 'font-extrabold' : 'text-mudo'}`}>
                    {ehHoje ? 'hoje' : diaSemana(d.data)}
                  </span>
                </div>
              );
            })}
          </div>
        </section>

        <section aria-labelledby="t-alertas">
          <div className="mb-3 flex items-baseline justify-between">
            <h2 id="t-alertas" className="text-lg font-bold">Estoque baixo</h2>
            {dados.estoque_baixo > 0 && (
              <Link to={linkAlertas} className="btn-link">Ver {dados.estoque_baixo === 1 ? 'o produto' : `os ${dados.estoque_baixo}`}</Link>
            )}
          </div>
          {dados.alertas.length === 0 ? (
            <p className="folha px-4 py-6 text-sm text-mudo">Nenhum produto abaixo do mínimo. Bom trabalho.</p>
          ) : (
            <ul className="folha divide-y divide-linha">
              {dados.alertas.map((p) => (
                <li key={p.id} className="flex items-center justify-between gap-3 px-4 py-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold">{p.nome}</p>
                    <p className="text-xs text-mudo">Mínimo: {p.estoque_minimo}</p>
                  </div>
                  <span className="marca-texto shrink-0 text-sm font-extrabold">
                    {p.estoque === 0 ? 'Zerado' : `${p.estoque} un.`}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      <div className="grid gap-8 lg:grid-cols-[3fr_2fr]">
        <section aria-labelledby="t-ultimas">
          <div className="mb-3 flex items-baseline justify-between">
            <h2 id="t-ultimas" className="text-lg font-bold">Últimas vendas</h2>
            <Link to="/vendas" className="btn-link">Ver todas</Link>
          </div>
          <div className="folha overflow-x-auto">
            <table className="ledger">
              <thead>
                <tr>
                  <th>Nº</th>
                  <th>Quando</th>
                  <th>Cliente</th>
                  <th>Pagamento</th>
                  <th className="num">Total</th>
                </tr>
              </thead>
              <tbody>
                {dados.ultimas_vendas.length === 0 && (
                  <tr><td colSpan={5} className="py-6 text-center text-mudo">Nenhuma venda registrada ainda.</td></tr>
                )}
                {dados.ultimas_vendas.map((v) => (
                  <tr key={v.id}>
                    <td className="font-semibold">#{v.id}</td>
                    <td className="whitespace-nowrap">{dataHora(v.data_venda)}</td>
                    <td>{v.cliente}</td>
                    <td>{FORMAS_PAGAMENTO[v.forma_pagamento]}</td>
                    <td className="num font-semibold">{moeda(v.valor_total)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section aria-labelledby="t-top">
          <h2 id="t-top" className="mb-3 text-lg font-bold">Mais vendidos no mês</h2>
          {dados.mais_vendidos_mes.length === 0 ? (
            <p className="folha px-4 py-6 text-sm text-mudo">As vendas do mês vão aparecer aqui.</p>
          ) : (
            <ol className="folha divide-y divide-linha">
              {dados.mais_vendidos_mes.map((p) => (
                <li key={p.id} className="flex items-center justify-between gap-3 px-4 py-3">
                  <span className="min-w-0 truncate text-sm font-semibold">{p.nome}</span>
                  <span className="shrink-0 text-right text-sm">
                    <b>{inteiro(p.quantidade)}</b> <span className="text-mudo">un.</span>
                    <span className="ml-2"><Etiqueta>{moeda(p.receita)}</Etiqueta></span>
                  </span>
                </li>
              ))}
            </ol>
          )}
        </section>
      </div>
    </div>
  );
}
