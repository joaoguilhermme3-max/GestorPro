import { FormEvent, useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Confirmar, Modal } from '../components/Modal';
import { Campo, Carregando, ErroBloco, Etiqueta, PageHeader, Paginacao, Vazio } from '../components/ui';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { useApi } from '../hooks/useApi';
import { useDebounce } from '../hooks/useDebounce';
import { api } from '../services/api';
import type { Categoria, Pagina, Produto } from '../types';
import { errosPorCampo, mensagemDe } from '../utils/erros';
import { inteiro, moeda, numero } from '../utils/format';

const POR_PAGINA = 15;

export default function Produtos() {
  const { ehAdmin } = useAuth();
  const toast = useToast();
  const [params] = useSearchParams();
  const [busca, setBusca] = useState('');
  const [categoria, setCategoria] = useState('');
  const [soBaixo, setSoBaixo] = useState(params.get('baixo') === 'true');
  const [page, setPage] = useState(1);
  const q = useDebounce(busca, 300);

  const [editando, setEditando] = useState<Produto | 'novo' | null>(null);
  const [removendo, setRemovendo] = useState<Produto | null>(null);
  const [removendoCarregando, setRemovendoCarregando] = useState(false);
  const [categoriasAbertas, setCategoriasAbertas] = useState(false);

  useEffect(() => setPage(1), [q, categoria, soBaixo]);

  const lista = useApi(
    () => api.get<Pagina<Produto>>('/produtos', { q, categoria_id: categoria, baixo: soBaixo ? 'true' : undefined, page, limit: POR_PAGINA }),
    [q, categoria, soBaixo, page],
  );
  const cats = useApi(() => api.get<{ itens: Categoria[] }>('/categorias'), []);

  async function desativar() {
    if (!removendo) return;
    setRemovendoCarregando(true);
    try {
      await api.delete(`/produtos/${removendo.id}`);
      toast.ok(`"${removendo.nome}" foi desativado.`);
      setRemovendo(null);
      lista.recarregar();
    } catch (e) {
      toast.erro(mensagemDe(e));
    } finally {
      setRemovendoCarregando(false);
    }
  }

  return (
    <div>
      <PageHeader
        titulo="Produtos"
        subtitulo="Cadastre o que você vende, com preço e estoque mínimo para receber avisos de reposição."
        acoes={
          <>
            <button className="btn-quiet" onClick={() => setCategoriasAbertas(true)}>Categorias</button>
            <button className="btn-action" onClick={() => setEditando('novo')}>Novo produto</button>
          </>
        }
      />

      <div className="mb-4 grid gap-3 sm:grid-cols-[1fr_14rem_auto] sm:items-end">
        <Campo rotulo="Buscar">
          <input className="input" type="search" placeholder="Nome ou código" value={busca} onChange={(e) => setBusca(e.target.value)} />
        </Campo>
        <Campo rotulo="Categoria">
          <select className="input" value={categoria} onChange={(e) => setCategoria(e.target.value)}>
            <option value="">Todas</option>
            {cats.dados?.itens.map((c) => (
              <option key={c.id} value={c.id}>{c.nome}</option>
            ))}
          </select>
        </Campo>
        <label className="flex min-h-10 items-center gap-2 text-sm font-semibold">
          <input type="checkbox" className="h-4 w-4 accent-caneta" checked={soBaixo} onChange={(e) => setSoBaixo(e.target.checked)} />
          Só estoque baixo
        </label>
      </div>

      {lista.erro && <ErroBloco texto={lista.erro} aoTentar={lista.recarregar} />}

      <div className="folha overflow-x-auto">
        <table className="ledger">
          <thead>
            <tr>
              <th>Código</th>
              <th>Produto</th>
              <th className="num">Preço</th>
              <th className="num">Estoque</th>
              <th className="w-px"><span className="sr-only">Ações</span></th>
            </tr>
          </thead>
          <tbody>
            {lista.carregando && !lista.dados && (
              <tr><td colSpan={5}><Carregando /></td></tr>
            )}
            {lista.dados?.itens.map((p) => (
              <tr key={p.id} className={p.estoque_baixo ? 'bg-marca-suave/40' : ''}>
                <td className="whitespace-nowrap font-semibold">{p.codigo}</td>
                <td>
                  <p className="font-semibold">{p.nome}</p>
                  <p className="text-xs text-mudo">{p.categoria ?? 'Sem categoria'}</p>
                </td>
                <td className="num whitespace-nowrap">{moeda(p.preco)}</td>
                <td className="num whitespace-nowrap">
                  <span className={p.estoque_baixo ? 'marca-texto font-extrabold' : 'font-semibold'}>{inteiro(p.estoque)}</span>
                  <span className="ml-1 text-xs text-mudo">/ mín. {p.estoque_minimo}</span>
                  {p.estoque === 0 && <span className="ml-2"><Etiqueta tom="ruim">Zerado</Etiqueta></span>}
                </td>
                <td className="whitespace-nowrap text-right">
                  <button className="btn-link" onClick={() => setEditando(p)}>Editar</button>
                  {ehAdmin && (
                    <button className="btn-link-danger ml-2" onClick={() => setRemovendo(p)}>Desativar</button>
                  )}
                </td>
              </tr>
            ))}
            {lista.dados && lista.dados.itens.length === 0 && (
              <tr>
                <td colSpan={5}>
                  <Vazio
                    titulo={q || categoria || soBaixo ? 'Nenhum produto com esses filtros' : 'Nenhum produto cadastrado'}
                    texto={q || categoria || soBaixo ? 'Tente outra busca ou limpe os filtros.' : 'Comece cadastrando o primeiro produto da loja.'}
                    acao={!q && !categoria && !soBaixo ? <button className="btn-action" onClick={() => setEditando('novo')}>Cadastrar produto</button> : undefined}
                  />
                </td>
              </tr>
            )}
          </tbody>
        </table>
        {lista.dados && <Paginacao page={page} limit={POR_PAGINA} total={lista.dados.total} aoMudar={setPage} />}
      </div>

      <FormularioProduto
        produto={editando}
        categorias={cats.dados?.itens ?? []}
        aoFechar={() => setEditando(null)}
        aoSalvar={() => {
          setEditando(null);
          lista.recarregar();
        }}
      />

      <Confirmar
        aberto={!!removendo}
        titulo="Desativar produto"
        texto={
          <>
            <b>{removendo?.nome}</b> deixa de aparecer nas vendas e na lista. O histórico de vendas e de estoque é mantido.
          </>
        }
        rotuloConfirmar="Desativar"
        carregando={removendoCarregando}
        aoConfirmar={desativar}
        aoCancelar={() => setRemovendo(null)}
      />

      <GerenciarCategorias
        aberto={categoriasAbertas}
        aoFechar={() => setCategoriasAbertas(false)}
        categorias={cats.dados?.itens ?? []}
        aoAlterar={() => {
          cats.recarregar();
          lista.recarregar();
        }}
      />
    </div>
  );
}

function FormularioProduto({
  produto,
  categorias,
  aoFechar,
  aoSalvar,
}: {
  produto: Produto | 'novo' | null;
  categorias: Categoria[];
  aoFechar: () => void;
  aoSalvar: () => void;
}) {
  const { ehAdmin } = useAuth();
  const toast = useToast();
  const novo = produto === 'novo';
  const [f, setF] = useState({ nome: '', codigo: '', categoria_id: '', preco: '', custo: '', estoque: '', estoque_minimo: '', descricao: '' });
  const [erros, setErros] = useState<Record<string, string>>({});
  const [erroGeral, setErroGeral] = useState('');
  const [salvando, setSalvando] = useState(false);

  useEffect(() => {
    if (!produto) return;
    setErros({});
    setErroGeral('');
    if (produto === 'novo') {
      setF({ nome: '', codigo: '', categoria_id: '', preco: '', custo: '', estoque: '0', estoque_minimo: '0', descricao: '' });
    } else {
      setF({
        nome: produto.nome,
        codigo: produto.codigo,
        categoria_id: produto.categoria_id ? String(produto.categoria_id) : '',
        preco: String(produto.preco),
        custo: produto.custo !== undefined ? String(produto.custo) : '',
        estoque: String(produto.estoque),
        estoque_minimo: String(produto.estoque_minimo),
        descricao: produto.descricao ?? '',
      });
    }
  }, [produto]);

  const set = (campo: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setF((x) => ({ ...x, [campo]: e.target.value }));

  async function enviar(e: FormEvent) {
    e.preventDefault();
    setErros({});
    setErroGeral('');
    const corpo: Record<string, unknown> = {
      nome: f.nome,
      codigo: f.codigo,
      descricao: f.descricao,
      preco: numero(f.preco),
      estoque_minimo: numero(f.estoque_minimo) ?? 0,
      categoria_id: f.categoria_id ? Number(f.categoria_id) : null,
    };
    if (ehAdmin) corpo.custo = numero(f.custo) ?? 0;
    if (novo) corpo.estoque = numero(f.estoque) ?? 0;

    setSalvando(true);
    try {
      if (novo) await api.post('/produtos', corpo);
      else await api.put(`/produtos/${(produto as Produto).id}`, corpo);
      toast.ok(novo ? 'Produto cadastrado.' : 'Produto atualizado.');
      aoSalvar();
    } catch (err) {
      setErros(errosPorCampo(err));
      setErroGeral(mensagemDe(err));
    } finally {
      setSalvando(false);
    }
  }

  return (
    <Modal aberto={!!produto} aoFechar={aoFechar} titulo={novo ? 'Novo produto' : 'Editar produto'} largura="md">
      <form onSubmit={enviar} className="grid gap-4 sm:grid-cols-2">
        <Campo rotulo="Nome" erro={erros.nome} className="sm:col-span-2">
          <input className="input" required autoFocus value={f.nome} onChange={set('nome')} />
        </Campo>
        <Campo rotulo="Código" erro={erros.codigo}>
          <input className="input" required value={f.codigo} onChange={set('codigo')} placeholder="Ex.: VEN001" />
        </Campo>
        <Campo rotulo="Categoria">
          <select className="input" value={f.categoria_id} onChange={set('categoria_id')}>
            <option value="">Sem categoria</option>
            {categorias.map((c) => (
              <option key={c.id} value={c.id}>{c.nome}</option>
            ))}
          </select>
        </Campo>
        <Campo rotulo="Preço de venda (R$)" erro={erros.preco}>
          <input className="input" type="number" step="0.01" min="0" required value={f.preco} onChange={set('preco')} />
        </Campo>
        {ehAdmin ? (
          <Campo rotulo="Custo (R$)" erro={erros.custo} dica="Usado no lucro bruto dos relatórios">
            <input className="input" type="number" step="0.01" min="0" value={f.custo} onChange={set('custo')} />
          </Campo>
        ) : (
          <div />
        )}
        <Campo
          rotulo={novo ? 'Estoque inicial' : 'Estoque atual'}
          erro={erros.estoque}
          dica={novo ? undefined : 'Para alterar, use Estoque › Registrar movimentação'}
        >
          <input className="input" type="number" min="0" step="1" disabled={!novo} value={f.estoque} onChange={set('estoque')} />
        </Campo>
        <Campo rotulo="Estoque mínimo" erro={erros.estoque_minimo} dica="Abaixo disso o produto entra na lista de reposição">
          <input className="input" type="number" min="0" step="1" value={f.estoque_minimo} onChange={set('estoque_minimo')} />
        </Campo>
        <Campo rotulo="Descrição (opcional)" className="sm:col-span-2">
          <textarea className="input" rows={2} value={f.descricao} onChange={set('descricao')} />
        </Campo>

        {erroGeral && <p className="field-error sm:col-span-2" role="alert">{erroGeral}</p>}
        <div className="flex justify-end gap-2 sm:col-span-2">
          <button type="button" className="btn-quiet" onClick={aoFechar}>Cancelar</button>
          <button className="btn-action" disabled={salvando}>{salvando ? 'Salvando…' : 'Salvar produto'}</button>
        </div>
      </form>
    </Modal>
  );
}

function GerenciarCategorias({
  aberto,
  aoFechar,
  categorias,
  aoAlterar,
}: {
  aberto: boolean;
  aoFechar: () => void;
  categorias: Categoria[];
  aoAlterar: () => void;
}) {
  const { ehAdmin } = useAuth();
  const toast = useToast();
  const [nome, setNome] = useState('');
  const [edicao, setEdicao] = useState<{ id: number; nome: string } | null>(null);

  async function executar(fn: () => Promise<unknown>, ok: string) {
    try {
      await fn();
      toast.ok(ok);
      aoAlterar();
    } catch (e) {
      toast.erro(mensagemDe(e));
    }
  }

  return (
    <Modal aberto={aberto} aoFechar={aoFechar} titulo="Categorias" largura="sm">
      <form
        className="mb-4 flex gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          if (!nome.trim()) return;
          executar(() => api.post('/categorias', { nome }), 'Categoria criada.').then(() => setNome(''));
        }}
      >
        <input className="input" placeholder="Nova categoria" aria-label="Nome da nova categoria" value={nome} onChange={(e) => setNome(e.target.value)} />
        <button className="btn-action">Adicionar</button>
      </form>

      {categorias.length === 0 ? (
        <p className="text-sm text-mudo">Nenhuma categoria ainda.</p>
      ) : (
        <ul className="divide-y divide-linha border-y border-linha">
          {categorias.map((c) => (
            <li key={c.id} className="flex items-center justify-between gap-2 py-2.5">
              {edicao?.id === c.id ? (
                <form
                  className="flex flex-1 gap-2"
                  onSubmit={(e) => {
                    e.preventDefault();
                    executar(() => api.put(`/categorias/${c.id}`, { nome: edicao.nome }), 'Categoria renomeada.').then(() => setEdicao(null));
                  }}
                >
                  <input className="input" aria-label="Novo nome" autoFocus value={edicao.nome} onChange={(e) => setEdicao({ id: c.id, nome: e.target.value })} />
                  <button className="btn-primary px-3">Salvar</button>
                </form>
              ) : (
                <>
                  <span className="text-sm">
                    <b>{c.nome}</b> <span className="text-mudo">· {c.produtos} {c.produtos === 1 ? 'produto' : 'produtos'}</span>
                  </span>
                  <span className="whitespace-nowrap">
                    <button className="btn-link" onClick={() => setEdicao({ id: c.id, nome: c.nome })}>Renomear</button>
                    {ehAdmin && (
                      <button
                        className="btn-link-danger ml-2"
                        onClick={() => executar(() => api.delete(`/categorias/${c.id}`), 'Categoria removida.')}
                      >
                        Excluir
                      </button>
                    )}
                  </span>
                </>
              )}
            </li>
          ))}
        </ul>
      )}
      <p className="hint">Ao excluir uma categoria, os produtos dela ficam sem categoria.</p>
    </Modal>
  );
}
