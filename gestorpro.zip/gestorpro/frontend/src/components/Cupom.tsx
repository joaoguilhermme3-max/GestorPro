import { ReactNode } from 'react';
import { FORMAS_PAGAMENTO, dataHora, moeda } from '../utils/format';

interface Linha {
  chave: string | number;
  quantidade: number;
  nome: string;
  subtotal: number;
}

/** Recibo de papel: linhas com pontilhado entre nome e valor, total em destaque. */
export function Cupom({
  titulo,
  data,
  linhas,
  subtotal,
  desconto,
  total,
  formaPagamento,
  cliente,
  rodape,
  vazio,
}: {
  titulo: string;
  data?: string | null;
  linhas: Linha[];
  subtotal: number;
  desconto: number;
  total: number;
  formaPagamento?: string;
  cliente?: string | null;
  rodape?: ReactNode;
  vazio?: string;
}) {
  return (
    <div className="cupom print-area px-5 pb-8 pt-5 text-sm">
      <p className="text-center text-base font-extrabold">GestorPro</p>
      <p className="text-center text-xs text-mudo">{titulo}</p>
      {data && <p className="text-center text-xs text-mudo">{dataHora(data)}</p>}

      <div className="my-4 border-y border-dashed border-linha-forte py-3">
        {linhas.length === 0 ? (
          <p className="py-4 text-center text-mudo">{vazio ?? 'Nenhum item.'}</p>
        ) : (
          <ul className="space-y-1.5">
            {linhas.map((l) => (
              <li key={l.chave} className="flex items-baseline gap-2">
                <span className="min-w-0 truncate">
                  {l.quantidade}× {l.nome}
                </span>
                <span className="pontilhado mb-1 h-0 flex-1" aria-hidden="true" />
                <span className="shrink-0 font-semibold">{moeda(l.subtotal)}</span>
              </li>
            ))}
          </ul>
        )}
      </div>

      <dl className="space-y-1">
        <div className="flex justify-between">
          <dt className="text-mudo">Subtotal</dt>
          <dd>{moeda(subtotal)}</dd>
        </div>
        {desconto > 0 && (
          <div className="flex justify-between">
            <dt className="text-mudo">Desconto</dt>
            <dd>− {moeda(desconto)}</dd>
          </div>
        )}
        <div className="flex items-baseline justify-between pt-2">
          <dt className="text-base font-bold">Total</dt>
          <dd className="text-3xl font-extrabold">{moeda(total)}</dd>
        </div>
      </dl>

      {(formaPagamento || cliente) && (
        <p className="mt-4 border-t border-dashed border-linha-forte pt-3 text-xs text-mudo">
          {formaPagamento && <>Pagamento: {FORMAS_PAGAMENTO[formaPagamento] ?? formaPagamento}</>}
          {formaPagamento && cliente && <br />}
          {cliente && <>Cliente: {cliente}</>}
        </p>
      )}
      {rodape && <div className="mt-4">{rodape}</div>}
    </div>
  );
}
