const CAMINHOS: Record<string, string> = {
  painel: 'M4 4h6v7H4zM14 4h6v4h-6zM14 12h6v8h-6zM4 15h6v5H4z',
  produtos: 'M21 8l-9-5-9 5v8l9 5 9-5V8zM3 8l9 5 9-5M12 13v8',
  estoque: 'M12 3l9 5-9 5-9-5 9-5zM3 12.5l9 5 9-5M3 17l9 5 9-5',
  vendas: 'M3 4h2l2.4 11h10.2L20 7H6M9 20h.01M17 20h.01',
  clientes: 'M16 20v-1a4 4 0 00-4-4H8a4 4 0 00-4 4v1M10 11a3.5 3.5 0 100-7 3.5 3.5 0 000 7zM20 20v-1a4 4 0 00-3-3.9M15 4.2a3.5 3.5 0 010 6.6',
  financeiro: 'M3 7h15a3 3 0 013 3v8a2 2 0 01-2 2H5a2 2 0 01-2-2V7zm0 0V6a2 2 0 012-2h11M16 14h2',
  relatorios: 'M4 20V4M4 20h16M8 16v-5M12 16V8M16 16v-3',
  usuarios: 'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z',
  menu: 'M4 6h16M4 12h16M4 18h16',
  fechar: 'M6 6l12 12M18 6L6 18',
  mais: 'M12 5v14M5 12h14',
  menos: 'M5 12h14',
  busca: 'M11 4a7 7 0 100 14 7 7 0 000-14zM20 20l-4-4',
  sair: 'M15 4h3a2 2 0 012 2v12a2 2 0 01-2 2h-3M10 8l-4 4 4 4M6 12h11',
  chave: 'M14 10a4 4 0 11-3.5 6L4 22v-3h3v-2h2l2-2A4 4 0 0114 10z',
  lixo: 'M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13',
  imprimir: 'M7 9V3h10v6M7 17H5a2 2 0 01-2-2v-4a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2h-2M7 14h10v7H7z',
  baixar: 'M12 4v11M7 11l5 5 5-5M4 20h16',
  alerta: 'M12 4l9 16H3L12 4zM12 10v4M12 17h.01',
};

export function Icone({ nome, className = 'h-5 w-5' }: { nome: keyof typeof CAMINHOS | string; className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <path d={CAMINHOS[nome] ?? ''} />
    </svg>
  );
}
