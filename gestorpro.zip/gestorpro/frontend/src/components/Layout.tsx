import { FormEvent, useEffect, useState } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { api, ApiError } from '../services/api';
import { Icone } from './Icone';
import { Modal } from './Modal';
import { Campo } from './ui';

const ITENS = [
  { para: '/', rotulo: 'Painel', icone: 'painel', admin: false, fim: true },
  { para: '/vendas', rotulo: 'Vendas', icone: 'vendas', admin: false },
  { para: '/produtos', rotulo: 'Produtos', icone: 'produtos', admin: false },
  { para: '/clientes', rotulo: 'Clientes', icone: 'clientes', admin: false },
  { para: '/estoque', rotulo: 'Estoque', icone: 'estoque', admin: true },
  { para: '/financeiro', rotulo: 'Financeiro', icone: 'financeiro', admin: true },
  { para: '/relatorios', rotulo: 'Relatórios', icone: 'relatorios', admin: true },
  { para: '/usuarios', rotulo: 'Usuários', icone: 'usuarios', admin: true },
];

export function Layout() {
  const { usuario, ehAdmin, sair } = useAuth();
  const [menuAberto, setMenuAberto] = useState(false);
  const [senhaAberta, setSenhaAberta] = useState(false);
  const local = useLocation();

  useEffect(() => setMenuAberto(false), [local.pathname]);

  const menu = (
    <nav className="flex h-full flex-col" aria-label="Principal">
      <div className="px-5 pb-4 pt-5">
        <Link to="/" className="text-xl font-extrabold tracking-tight text-white">
          GestorPro
        </Link>
      </div>

      <div className="px-3 pb-3">
        <Link
          to="/vendas/nova"
          className="flex min-h-11 items-center justify-center gap-2 rounded-md bg-marca px-3 text-sm font-bold text-tinta hover:brightness-95"
        >
          <Icone nome="mais" className="h-4 w-4" /> Nova venda
        </Link>
      </div>

      <ul className="flex-1 space-y-0.5 overflow-y-auto px-3 py-1">
        {ITENS.filter((i) => !i.admin || ehAdmin).map((i) => (
          <li key={i.para}>
            <NavLink
              to={i.para}
              end={i.fim}
              className={({ isActive }) =>
                `relative flex min-h-10 items-center gap-3 rounded-md px-3 text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-white/12 text-white before:absolute before:inset-y-2 before:left-0 before:w-[3px] before:rounded-r before:bg-marca'
                    : 'text-white/70 hover:bg-white/8 hover:text-white'
                }`
              }
            >
              <Icone nome={i.icone} className="h-[18px] w-[18px]" />
              {i.rotulo}
            </NavLink>
          </li>
        ))}
      </ul>

      <div className="border-t border-white/15 p-4">
        <p className="truncate text-sm font-semibold text-white">{usuario?.nome}</p>
        <p className="mb-3 text-xs text-white/60">{ehAdmin ? 'Administrador' : 'Funcionário'}</p>
        <div className="flex gap-2">
          <button
            onClick={() => setSenhaAberta(true)}
            className="flex min-h-9 flex-1 items-center justify-center gap-1.5 rounded-md border border-white/25 text-xs font-semibold text-white hover:bg-white/10"
          >
            <Icone nome="chave" className="h-4 w-4" /> Senha
          </button>
          <button
            onClick={sair}
            className="flex min-h-9 flex-1 items-center justify-center gap-1.5 rounded-md border border-white/25 text-xs font-semibold text-white hover:bg-white/10"
          >
            <Icone nome="sair" className="h-4 w-4" /> Sair
          </button>
        </div>
      </div>
    </nav>
  );

  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[15rem_1fr]">
      {/* barra superior (celular) */}
      <div className="no-print sticky top-0 z-40 flex items-center justify-between bg-tinta px-4 py-2.5 lg:hidden">
        <Link to="/" className="text-lg font-extrabold text-white">
          GestorPro
        </Link>
        <button onClick={() => setMenuAberto(true)} className="rounded p-2 text-white" aria-label="Abrir menu">
          <Icone nome="menu" />
        </button>
      </div>

      {/* menu lateral (computador) */}
      <aside className="no-print sticky top-0 hidden h-screen bg-tinta lg:block">{menu}</aside>

      {/* menu em gaveta (celular) */}
      {menuAberto && (
        <div className="no-print fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-tinta/60" onClick={() => setMenuAberto(false)} />
          <aside className="absolute inset-y-0 left-0 w-64 bg-tinta shadow-2xl">{menu}</aside>
        </div>
      )}

      <main className="min-w-0 px-4 py-6 sm:px-8 lg:py-8">
        <div className="mx-auto max-w-6xl">
          <Outlet />
        </div>
      </main>

      <TrocarSenha aberto={senhaAberta} aoFechar={() => setSenhaAberta(false)} />
    </div>
  );
}

function TrocarSenha({ aberto, aoFechar }: { aberto: boolean; aoFechar: () => void }) {
  const toast = useToast();
  const [atual, setAtual] = useState('');
  const [nova, setNova] = useState('');
  const [confirma, setConfirma] = useState('');
  const [erro, setErro] = useState('');
  const [salvando, setSalvando] = useState(false);

  useEffect(() => {
    if (aberto) {
      setAtual('');
      setNova('');
      setConfirma('');
      setErro('');
    }
  }, [aberto]);

  async function enviar(e: FormEvent) {
    e.preventDefault();
    if (nova !== confirma) return setErro('A confirmação não é igual à nova senha.');
    setSalvando(true);
    try {
      await api.put('/me/senha', { senha_atual: atual, nova_senha: nova });
      toast.ok('Senha alterada.');
      aoFechar();
    } catch (err) {
      setErro(err instanceof ApiError ? err.message : 'Não foi possível alterar a senha.');
    } finally {
      setSalvando(false);
    }
  }

  return (
    <Modal aberto={aberto} aoFechar={aoFechar} titulo="Alterar senha" largura="sm">
      <form onSubmit={enviar} className="space-y-4">
        <Campo rotulo="Senha atual">
          <input className="input" type="password" autoComplete="current-password" required value={atual} onChange={(e) => setAtual(e.target.value)} />
        </Campo>
        <Campo rotulo="Nova senha" dica="Mínimo de 6 caracteres">
          <input className="input" type="password" autoComplete="new-password" required minLength={6} value={nova} onChange={(e) => setNova(e.target.value)} />
        </Campo>
        <Campo rotulo="Repita a nova senha">
          <input className="input" type="password" autoComplete="new-password" required value={confirma} onChange={(e) => setConfirma(e.target.value)} />
        </Campo>
        {erro && <p className="field-error" role="alert">{erro}</p>}
        <div className="flex justify-end gap-2">
          <button type="button" className="btn-quiet" onClick={aoFechar}>Cancelar</button>
          <button className="btn-primary" disabled={salvando}>{salvando ? 'Salvando…' : 'Salvar senha'}</button>
        </div>
      </form>
    </Modal>
  );
}
