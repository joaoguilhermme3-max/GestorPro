import { ReactNode, useEffect, useRef } from 'react';
import { Icone } from './Icone';

interface Props {
  aberto: boolean;
  aoFechar: () => void;
  titulo: string;
  children: ReactNode;
  largura?: 'sm' | 'md' | 'lg';
}

const LARGURAS = { sm: 'max-w-md', md: 'max-w-xl', lg: 'max-w-3xl' };

/** Usa <dialog> nativo: foco preso dentro do modal e Esc fecham sem código extra. */
export function Modal({ aberto, aoFechar, titulo, children, largura = 'md' }: Props) {
  const ref = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (aberto && !d.open) d.showModal();
    if (!aberto && d.open) d.close();
  }, [aberto]);

  return (
    <dialog
      ref={ref}
      onClose={aoFechar}
      onMouseDown={(e) => {
        if (e.target === ref.current) aoFechar();
      }}
      className={`m-auto max-h-[92vh] w-[calc(100%-1.5rem)] ${LARGURAS[largura]} overflow-auto rounded-lg border border-linha bg-white p-0 text-tinta shadow-2xl backdrop:bg-tinta/55`}
    >
      {aberto && (
        <div>
          <div className="sticky top-0 z-10 flex items-center justify-between border-b border-linha bg-white px-5 py-3">
            <h2 className="text-lg font-bold">{titulo}</h2>
            <button onClick={aoFechar} className="rounded p-1.5 text-tinta-3 hover:bg-papel-2" aria-label="Fechar">
              <Icone nome="fechar" />
            </button>
          </div>
          <div className="p-5">{children}</div>
        </div>
      )}
    </dialog>
  );
}

export function Confirmar({
  aberto,
  titulo,
  texto,
  rotuloConfirmar,
  perigo = true,
  carregando,
  aoConfirmar,
  aoCancelar,
}: {
  aberto: boolean;
  titulo: string;
  texto: ReactNode;
  rotuloConfirmar: string;
  perigo?: boolean;
  carregando?: boolean;
  aoConfirmar: () => void;
  aoCancelar: () => void;
}) {
  return (
    <Modal aberto={aberto} aoFechar={aoCancelar} titulo={titulo} largura="sm">
      <p className="text-sm leading-relaxed text-tinta-2">{texto}</p>
      <div className="mt-5 flex justify-end gap-2">
        <button className="btn-quiet" onClick={aoCancelar}>
          Voltar
        </button>
        <button className={perigo ? 'btn-danger' : 'btn-primary'} onClick={aoConfirmar} disabled={carregando}>
          {carregando ? 'Aguarde…' : rotuloConfirmar}
        </button>
      </div>
    </Modal>
  );
}
