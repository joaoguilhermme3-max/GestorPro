import { ReactNode, useEffect, useId, useRef, useState } from 'react';
import { useDebounce } from '../hooks/useDebounce';
import { Icone } from './Icone';

interface Props<T> {
  buscar: (texto: string) => Promise<T[]>;
  aoEscolher: (item: T) => void;
  renderizar: (item: T) => ReactNode;
  chave: (item: T) => string | number;
  placeholder: string;
  rotuloAria: string;
  autoFocus?: boolean;
  /** Quando true, o campo esvazia depois de escolher (útil para adicionar vários itens). */
  limparAoEscolher?: boolean;
  textoDoItem?: (item: T) => string;
}

/** Campo de busca com lista de sugestões. Setas navegam, Enter escolhe, Esc fecha. */
export function Combobox<T>({
  buscar,
  aoEscolher,
  renderizar,
  chave,
  placeholder,
  rotuloAria,
  autoFocus,
  limparAoEscolher = true,
  textoDoItem,
}: Props<T>) {
  const [texto, setTexto] = useState('');
  const [aberto, setAberto] = useState(false);
  const [itens, setItens] = useState<T[]>([]);
  const [ativo, setAtivo] = useState(0);
  const [buscando, setBuscando] = useState(false);
  const debounced = useDebounce(texto, 220);
  const idLista = useId();
  const caixa = useRef<HTMLDivElement>(null);
  const seq = useRef(0);

  useEffect(() => {
    if (!aberto) return;
    const id = ++seq.current;
    setBuscando(true);
    buscar(debounced)
      .then((r) => {
        if (id !== seq.current) return;
        setItens(r);
        setAtivo(0);
      })
      .catch(() => id === seq.current && setItens([]))
      .finally(() => id === seq.current && setBuscando(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debounced, aberto]);

  useEffect(() => {
    const fora = (e: MouseEvent) => {
      if (caixa.current && !caixa.current.contains(e.target as Node)) setAberto(false);
    };
    document.addEventListener('mousedown', fora);
    return () => document.removeEventListener('mousedown', fora);
  }, []);

  function escolher(item: T) {
    aoEscolher(item);
    setAberto(false);
    setTexto(limparAoEscolher || !textoDoItem ? '' : textoDoItem(item));
  }

  function teclado(e: React.KeyboardEvent) {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setAberto(true);
      setAtivo((a) => Math.min(a + 1, itens.length - 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setAtivo((a) => Math.max(a - 1, 0));
    } else if (e.key === 'Enter' && aberto && itens[ativo]) {
      e.preventDefault();
      escolher(itens[ativo]);
    } else if (e.key === 'Escape') {
      setAberto(false);
    }
  }

  return (
    <div ref={caixa} className="relative">
      <div className="relative">
        <Icone nome="busca" className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-mudo" />
        <input
          className="input pl-9"
          role="combobox"
          aria-expanded={aberto}
          aria-controls={idLista}
          aria-label={rotuloAria}
          aria-autocomplete="list"
          autoComplete="off"
          autoFocus={autoFocus}
          placeholder={placeholder}
          value={texto}
          onChange={(e) => {
            setTexto(e.target.value);
            setAberto(true);
          }}
          onFocus={() => setAberto(true)}
          onKeyDown={teclado}
        />
      </div>
      {aberto && (
        <ul
          id={idLista}
          role="listbox"
          className="absolute z-30 mt-1 max-h-72 w-full overflow-auto rounded-md border border-linha-forte bg-white py-1 shadow-lg"
        >
          {buscando && itens.length === 0 && <li className="px-3 py-2 text-sm text-mudo">Buscando…</li>}
          {!buscando && itens.length === 0 && <li className="px-3 py-2 text-sm text-mudo">Nada encontrado.</li>}
          {itens.map((item, i) => (
            <li
              key={chave(item)}
              role="option"
              aria-selected={i === ativo}
              onMouseDown={(e) => {
                e.preventDefault();
                escolher(item);
              }}
              onMouseEnter={() => setAtivo(i)}
              className={`cursor-pointer px-3 py-2 text-sm ${i === ativo ? 'bg-marca-suave' : ''}`}
            >
              {renderizar(item)}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
