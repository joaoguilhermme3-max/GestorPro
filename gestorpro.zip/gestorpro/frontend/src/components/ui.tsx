import { ReactNode } from 'react';

export function PageHeader({ titulo, subtitulo, acoes }: { titulo: string; subtitulo?: string; acoes?: ReactNode }) {
  return (
    <header className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-2xl font-extrabold sm:text-3xl">{titulo}</h1>
        {subtitulo && <p className="mt-1 max-w-prose text-sm text-mudo">{subtitulo}</p>}
      </div>
      {acoes && <div className="no-print flex flex-wrap items-center gap-2">{acoes}</div>}
    </header>
  );
}

export function Campo({
  rotulo,
  erro,
  dica,
  children,
  className = '',
}: {
  rotulo: string;
  erro?: string;
  dica?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <label className={`block ${className}`}>
      <span className="label">{rotulo}</span>
      {children}
      {dica && !erro && <span className="hint block">{dica}</span>}
      {erro && <span className="field-error block">{erro}</span>}
    </label>
  );
}

export function Vazio({ titulo, texto, acao }: { titulo: string; texto?: string; acao?: ReactNode }) {
  return (
    <div className="px-4 py-12 text-center">
      <p className="font-bold">{titulo}</p>
      {texto && <p className="mx-auto mt-1 max-w-sm text-sm text-mudo">{texto}</p>}
      {acao && <div className="mt-4">{acao}</div>}
    </div>
  );
}

export function Carregando({ texto = 'Carregando…' }: { texto?: string }) {
  return (
    <p className="px-4 py-10 text-center text-sm text-mudo" role="status">
      {texto}
    </p>
  );
}

export function ErroBloco({ texto, aoTentar }: { texto: string; aoTentar?: () => void }) {
  return (
    <div className="rounded-md border border-negativo/30 bg-negativo-suave px-4 py-3 text-sm text-negativo" role="alert">
      {texto}
      {aoTentar && (
        <button className="btn-link-danger ml-2" onClick={aoTentar}>
          Tentar de novo
        </button>
      )}
    </div>
  );
}

export function Etiqueta({ children, tom = 'neutro' }: { children: ReactNode; tom?: 'neutro' | 'aviso' | 'ruim' | 'bom' }) {
  const tons = {
    neutro: 'bg-papel-2 text-tinta-2',
    aviso: 'bg-marca-suave text-tinta',
    ruim: 'bg-negativo-suave text-negativo',
    bom: 'bg-[#dcf1e5] text-positivo',
  };
  return <span className={`inline-block rounded px-2 py-0.5 text-xs font-semibold ${tons[tom]}`}>{children}</span>;
}

/** Números lado a lado separados por linhas verticais (em vez de cartões iguais). */
export function Indicadores({ itens }: { itens: { rotulo: string; valor: ReactNode; tom?: 'bom' | 'ruim' }[] }) {
  return (
    <dl className="grid grid-cols-2 border-y border-linha-forte sm:grid-cols-[repeat(auto-fit,minmax(9rem,1fr))]">
      {itens.map((i, idx) => (
        <div key={i.rotulo} className={`px-4 py-3 ${idx > 0 ? 'sm:border-l sm:border-linha' : ''} ${idx % 2 === 1 ? 'border-l border-linha sm:border-l' : ''}`}>
          <dt className="text-xs font-semibold text-mudo">{i.rotulo}</dt>
          <dd className={`mt-0.5 text-xl font-extrabold ${i.tom === 'bom' ? 'text-positivo' : i.tom === 'ruim' ? 'text-negativo' : ''}`}>{i.valor}</dd>
        </div>
      ))}
    </dl>
  );
}

export function Paginacao({ page, limit, total, aoMudar }: { page: number; limit: number; total: number; aoMudar: (p: number) => void }) {
  const paginas = Math.max(1, Math.ceil(total / limit));
  if (total <= limit) return null;
  return (
    <nav className="no-print flex items-center justify-between gap-3 border-t border-linha px-3 py-3 text-sm" aria-label="Paginação">
      <span className="text-mudo">
        {(page - 1) * limit + 1}–{Math.min(page * limit, total)} de {total}
      </span>
      <div className="flex items-center gap-2">
        <button className="btn-quiet min-h-9 px-3" disabled={page <= 1} onClick={() => aoMudar(page - 1)}>
          Anterior
        </button>
        <span className="text-mudo">
          {page}/{paginas}
        </span>
        <button className="btn-quiet min-h-9 px-3" disabled={page >= paginas} onClick={() => aoMudar(page + 1)}>
          Próxima
        </button>
      </div>
    </nav>
  );
}
