const BASE = (import.meta.env.VITE_API_URL ?? '').replace(/\/$/, '') + '/api';
const TOKEN_KEY = 'gestorpro.token';

export const tokenStore = {
  get: () => localStorage.getItem(TOKEN_KEY),
  set: (t: string) => localStorage.setItem(TOKEN_KEY, t),
  clear: () => localStorage.removeItem(TOKEN_KEY),
};

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public detalhes?: { campo: string; mensagem: string }[],
  ) {
    super(message);
  }
}

/** Chamado quando a API responde 401 numa sessão já aberta (token vencido). */
let aoExpirar: (() => void) | null = null;
export const definirAoExpirar = (fn: () => void) => {
  aoExpirar = fn;
};

type Params = Record<string, string | number | boolean | undefined | null>;

function montarUrl(caminho: string, params?: Params) {
  const qs = new URLSearchParams();
  for (const [k, v] of Object.entries(params ?? {})) {
    if (v !== undefined && v !== null && v !== '') qs.set(k, String(v));
  }
  const s = qs.toString();
  return `${BASE}${caminho}${s ? `?${s}` : ''}`;
}

async function requisitar<T>(metodo: string, caminho: string, opcoes: { corpo?: unknown; params?: Params } = {}): Promise<T> {
  const token = tokenStore.get();
  let resposta: Response;
  try {
    resposta = await fetch(montarUrl(caminho, opcoes.params), {
      method: metodo,
      headers: {
        ...(opcoes.corpo !== undefined ? { 'Content-Type': 'application/json' } : {}),
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: opcoes.corpo !== undefined ? JSON.stringify(opcoes.corpo) : undefined,
    });
  } catch {
    throw new ApiError(0, 'Não foi possível conectar ao servidor. Verifique sua internet e tente de novo.');
  }

  if (resposta.status === 204) return undefined as T;
  const dados = await resposta.json().catch(() => null);

  if (!resposta.ok) {
    if (resposta.status === 401 && token && caminho !== '/login') aoExpirar?.();
    throw new ApiError(resposta.status, dados?.erro ?? 'Algo deu errado. Tente novamente.', dados?.detalhes);
  }
  return dados as T;
}

export const api = {
  get: <T>(caminho: string, params?: Params) => requisitar<T>('GET', caminho, { params }),
  post: <T>(caminho: string, corpo?: unknown) => requisitar<T>('POST', caminho, { corpo: corpo ?? {} }),
  put: <T>(caminho: string, corpo: unknown) => requisitar<T>('PUT', caminho, { corpo }),
  delete: <T = void>(caminho: string) => requisitar<T>('DELETE', caminho),

  /** Baixa um arquivo (CSV) mantendo o token no cabeçalho. */
  async baixar(caminho: string, params: Params, nomeArquivo: string) {
    const token = tokenStore.get();
    const r = await fetch(montarUrl(caminho, params), { headers: token ? { Authorization: `Bearer ${token}` } : {} });
    if (!r.ok) throw new ApiError(r.status, 'Não foi possível gerar o arquivo.');
    const url = URL.createObjectURL(await r.blob());
    const a = document.createElement('a');
    a.href = url;
    a.download = nomeArquivo;
    a.click();
    URL.revokeObjectURL(url);
  },
};
