-- ============================================
-- GestorPro - Schema PostgreSQL
-- ============================================

CREATE TABLE IF NOT EXISTS usuarios (
  id            SERIAL PRIMARY KEY,
  nome          VARCHAR(120) NOT NULL,
  email         VARCHAR(160) UNIQUE NOT NULL,
  senha_hash    TEXT NOT NULL,
  perfil        VARCHAR(20) NOT NULL DEFAULT 'funcionario'
                  CHECK (perfil IN ('admin', 'funcionario')),
  ativo         BOOLEAN NOT NULL DEFAULT TRUE,
  criado_em     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS categorias (
  id            SERIAL PRIMARY KEY,
  nome          VARCHAR(80) NOT NULL UNIQUE,
  criado_em     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS produtos (
  id              SERIAL PRIMARY KEY,
  nome            VARCHAR(160) NOT NULL,
  codigo          VARCHAR(40) UNIQUE NOT NULL,
  descricao       TEXT,
  preco           NUMERIC(12,2) NOT NULL CHECK (preco >= 0),
  custo           NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (custo >= 0),
  estoque         INTEGER NOT NULL DEFAULT 0 CHECK (estoque >= 0),
  estoque_minimo  INTEGER NOT NULL DEFAULT 0 CHECK (estoque_minimo >= 0),
  categoria_id    INTEGER REFERENCES categorias(id) ON DELETE SET NULL,
  ativo           BOOLEAN NOT NULL DEFAULT TRUE,
  criado_em       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  atualizado_em   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS clientes (
  id            SERIAL PRIMARY KEY,
  nome          VARCHAR(160) NOT NULL,
  cpf           VARCHAR(14),
  telefone      VARCHAR(20),
  email         VARCHAR(160),
  endereco      TEXT,
  ativo         BOOLEAN NOT NULL DEFAULT TRUE,
  criado_em     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
-- CPF único apenas quando informado (permite vários clientes sem CPF)
CREATE UNIQUE INDEX IF NOT EXISTS uq_clientes_cpf ON clientes (cpf) WHERE (cpf IS NOT NULL);

CREATE TABLE IF NOT EXISTS vendas (
  id              SERIAL PRIMARY KEY,
  cliente_id      INTEGER REFERENCES clientes(id) ON DELETE SET NULL,
  usuario_id      INTEGER NOT NULL REFERENCES usuarios(id),
  subtotal        NUMERIC(12,2) NOT NULL CHECK (subtotal >= 0),
  desconto        NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (desconto >= 0),
  valor_total     NUMERIC(12,2) NOT NULL CHECK (valor_total >= 0),
  forma_pagamento VARCHAR(20) NOT NULL
                    CHECK (forma_pagamento IN ('dinheiro', 'pix', 'debito', 'credito')),
  status          VARCHAR(20) NOT NULL DEFAULT 'concluida'
                    CHECK (status IN ('concluida', 'cancelada')),
  data_venda      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS itens_venda (
  id              SERIAL PRIMARY KEY,
  venda_id        INTEGER NOT NULL REFERENCES vendas(id) ON DELETE CASCADE,
  produto_id      INTEGER NOT NULL REFERENCES produtos(id),
  quantidade      INTEGER NOT NULL CHECK (quantidade > 0),
  preco_unitario  NUMERIC(12,2) NOT NULL CHECK (preco_unitario >= 0),
  custo_unitario  NUMERIC(12,2) NOT NULL DEFAULT 0,
  subtotal        NUMERIC(12,2) NOT NULL CHECK (subtotal >= 0)
);

CREATE TABLE IF NOT EXISTS movimentacoes_estoque (
  id            SERIAL PRIMARY KEY,
  produto_id    INTEGER NOT NULL REFERENCES produtos(id),
  tipo          VARCHAR(20) NOT NULL
                  CHECK (tipo IN ('entrada', 'venda', 'ajuste', 'cancelamento')),
  -- positivo = entrou no estoque, negativo = saiu
  quantidade    INTEGER NOT NULL CHECK (quantidade <> 0),
  saldo_apos    INTEGER NOT NULL,
  motivo        TEXT,
  venda_id      INTEGER REFERENCES vendas(id) ON DELETE SET NULL,
  usuario_id    INTEGER REFERENCES usuarios(id),
  criado_em     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS contas (
  id            SERIAL PRIMARY KEY,
  tipo          VARCHAR(10) NOT NULL CHECK (tipo IN ('entrada', 'saida')),
  categoria     VARCHAR(40) NOT NULL,
  descricao     VARCHAR(200) NOT NULL,
  valor         NUMERIC(12,2) NOT NULL CHECK (valor > 0),
  data          DATE NOT NULL DEFAULT CURRENT_DATE,
  venda_id      INTEGER REFERENCES vendas(id) ON DELETE CASCADE,
  usuario_id    INTEGER REFERENCES usuarios(id),
  criado_em     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Índices
CREATE INDEX IF NOT EXISTS idx_produtos_categoria ON produtos(categoria_id);
CREATE INDEX IF NOT EXISTS idx_produtos_nome ON produtos (lower(nome));
CREATE INDEX IF NOT EXISTS idx_clientes_nome ON clientes (lower(nome));
CREATE INDEX IF NOT EXISTS idx_vendas_cliente ON vendas(cliente_id);
CREATE INDEX IF NOT EXISTS idx_vendas_data ON vendas(data_venda);
CREATE INDEX IF NOT EXISTS idx_itens_venda_venda ON itens_venda(venda_id);
CREATE INDEX IF NOT EXISTS idx_itens_venda_produto ON itens_venda(produto_id);
CREATE INDEX IF NOT EXISTS idx_mov_produto ON movimentacoes_estoque(produto_id, criado_em DESC);
CREATE INDEX IF NOT EXISTS idx_contas_data ON contas(data);
CREATE INDEX IF NOT EXISTS idx_contas_tipo ON contas(tipo);
